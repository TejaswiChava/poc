const express = require('express');
const GenericController = require('./controllers/GenericController');
const GetXMLStyleSheetController = require('./controllers/getXMLStyleSheetController.js');
const xml = new GetXMLStyleSheetController();

const router = express.Router();
const genericController = new GenericController();

/**  Common */
router.post(
  '/common/api/Common/ConnectUser',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/CheckPermission',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetFindCommands',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetFindProfiles',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetLinkedDropDownValue',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetReferenceCodesV2',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetFindControls',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetListviewProfileSettings',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetUserListviewSettings',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetUserReports',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/GetUserOptions',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/SetUserOptions',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/common/api/common/DisConnectUser',
  genericController.getResponseForRequest.bind(genericController),
);

router.post('/common/api/common/GetXMLStyleSheet', xml.getXMLStyleSheet.bind(xml));

/**  Provider/Contracts */
router.post(
  '/provider/contracts/api/Provider/Contracts/GetBenefitStructures',
  genericController.getResponseForRequest.bind(genericController),
);
router.post(
  '/provider/contracts/api/Provider/Contracts/GetContracts',
  genericController.getResponseForRequest.bind(genericController),
);

/** Provider/Providers */
router.post(
  '/provider/providers/api/Provider/Providers/GetOffices_V2',
  genericController.getResponseForRequest.bind(genericController),
);

module.exports = router;
