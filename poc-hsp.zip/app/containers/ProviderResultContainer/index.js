/* eslint-disable no-shadow */
import React, { Component } from 'react';
import _ from 'lodash';
import './style.scss';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getFormattedInput } from '../ProviderResultFilterForm/responseFormatter';
// TODO: Replace Json DATA with API Data
import inputData from '../ProviderResultFilterForm/mockData/Contract_Find_Form_Parameters.json';
import officeInputData from '../ProviderResultFilterForm/mockData/Office_Find_Form_Parameters.json';
import { DynamicForm } from '../ProviderResultFilterForm';
import Table from '../../components/Table/Table';
import { getContracts, getOffices, commandType, getListViewProfileSettings } from './selectors';
import { getCommandData, getSessionId } from '../../components/Header/selectors';
import {
  mockContractsRequestParam,
  mockgetListViewProfileSettingsRequestData,
  mockOfficesRequestParam,
  mockgetListViewProfileSettingsRequestData2,
} from '../HomePage/mockData';

import {
  getContractsRequest,
  getOfficesRequest,
  getListViewProfileSettingsRequest,
  getUserListViewSettingsRequest,
} from '../HomePage/actions';
class ProviderResultContainer extends Component {
  state = {
    formData: {},
    isColHidden: false,
    leftColSize: 3,
  };

  getCommandType = () => {
    const history = _.get(this.props, 'history', null);
    if (_.get(history, 'location.pathname', '') === '/results/contracts') {
      return 'Contract';
    }
    if (_.get(history, 'location.pathname', '') === '/results/office') {
      return 'Office';
    }
    return '';
  };

  handleSubmit = value => {
    // TODO: POST API CALL for Form Submit with State Values
    this.setState({ formData: value });
  };

  sliderAction = action => {
    if (action === 'openSlider') {
      this.setState({ leftColSize: 3, isColHidden: false });
    } else {
      this.setState({ leftColSize: 0, isColHidden: true });
    }
  };

  handleOnClick = (path, item) => {
    const history = _.get(this.props, 'history', null);
    if (history) {
      history.push(path, { post: item });
    }
  };

  // Getting the data back from Form on click of Find Button

  /**
   * =================
   * For Office 
   * {
  "sessionID": "string",
  "usage": "string",
  "resultCount": "string",
  "officeId": 0,
  "officeNumber": "string",
  "npi": "",
  "officeName": "string",
  "address1": "string",
  "contactPhone": "string",
  "zip": "string",
  "distance": "string",
  "region": "string",
  "city": "string",
  "county": "string",
  "state": "string",
  "countryCode": "string",
  "language": "string",
  "additionalService": "string",
  "wheelchairAccess": "string"
}
===============

For Contract
{
  "sessionID": "string",
  "contractID": "string",
  "usage": "string",
  "flag": "string",
  "contractName": "string",
  "contractNumber": "string",
  "contractType": "string",
  "feeScheduleId": "string",
  "providerId": "string",
  "officeId": "string",
  "vendorId": "string",
  "networkCode": "string",
  "asOfDate": "string",
  "capitationOnly": "string",
  "resultCount": "string",
  "reimbursementID": "string"
}
=============
   */
  getFormData = formData => {
    console.log('formdata', formData);
    const commandType = this.getCommandType();
    const sessionId = _.get(this.props, 'sessionId', '');
    const commandData = _.get(this.props, 'commandData', null);

    console.log('commandData', commandData);
    const getContractsRequest = _.get(this.props, 'getContractsRequest', null);
    const getOfficesRequest = _.get(this.props, 'getOfficesRequest', null);
    const getListViewProfileSettingsRequest = _.get(this.props, 'getListViewProfileSettingsRequest', null);
    // const getUserListViewSettings = _.get(this.props, "getUserListViewSettings", null)

    if (commandType === 'Contract' && getContractsRequest) {
      getContractsRequest(mockContractsRequestParam);
      getListViewProfileSettingsRequest(mockgetListViewProfileSettingsRequestData);
    } else if (commandType === 'Office' && getOfficesRequest) {
      getOfficesRequest(mockOfficesRequestParam);
      getListViewProfileSettingsRequest(mockgetListViewProfileSettingsRequestData2);
    }
  };

  getTable = () => {
    const contracts = _.get(this.props, 'getContracts', []);
    const offices = _.get(this.props, 'getOffices', []);
    const listViewProfileSettings = _.get(this.props, 'getListViewProfileSettings', {});
    const commandType = _.get(this.props, 'commandType', '');

    if (!_.isEmpty(contracts) && !_.isEmpty(listViewProfileSettings) && _.isEqual(commandType, 'Contract')) {
      return <Table listViewData={contracts} coloumsData={listViewProfileSettings} />;
    }
    if (!_.isEmpty(offices) && !_.isEmpty(listViewProfileSettings) && _.isEqual(commandType, 'Office')) {
      return <Table listViewData={offices} coloumsData={listViewProfileSettings} />;
    }

    return null;
  };

  render() {
    return (
      <>
        <div className="ms-Grid" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">{/* Provider Sub header container */}</div>
          </div>

          <div className="ms-Grid-row section-rl-blocks" style={{ borderTop: '1px solid lightgrey' }}>
            <div
              className={`ms-Grid-col left-menu-aside ms-sm${this.state.leftColSize}`}
              hidden={this.state.isColHidden}
            >
              <DynamicForm
                commandType={this.getCommandType()}
                handleSubmit={this.handleSubmit}
                collapseHandle={action => this.sliderAction(action)}
                formData={this.getFormData}
              />
            </div>

            <div
              className={`ms-Grid-col right-table-content ms-sm${12 - this.state.leftColSize}`}
              style={{ padding: '3px 16px' }}
            >
              {this.state.isColHidden && (
                <button
                  type="button"
                  className="openbtn"
                  style={{
                    top: 0,
                    marginLeft: -17,
                    fontSize: 20,
                    padding: 2,
                    height: 62,
                    color: 'white',
                    border: 'none',
                    backgroundColor: '#004578',
                    position: 'absolute',
                  }}
                  onClick={() => this.sliderAction('openSlider')}
                >
                  »
                </button>
              )}
              {/* <h5>{JSON.stringify(this.state.formData, null, 1)}</h5> */}

              {this.getTable()}
            </div>
          </div>
        </div>
      </>
    );
  }
}

ProviderResultContainer.propTypes = {
  commandType: PropTypes.string,
  getContracts: PropTypes.array,
  getOffices: PropTypes.array,
  getListViewProfileSettings: PropTypes.object,
  getUserListViewSettings: PropTypes.func,
  sessionId: PropTypes.string,
  commandData: PropTypes.func,
  getContractsRequest: PropTypes.func,
  getOfficesRequest: PropTypes.func,
  getListViewProfileSettingsRequest: PropTypes.func,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state.connectUser),
  commandData: getCommandData(state),
  getContracts: getContracts(state),
  getOffices: getOffices(state),
  commandType: commandType(state),
  getListViewProfileSettings: getListViewProfileSettings(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    getContractsRequest: requestParams => dispatch(getContractsRequest(requestParams)),
    getOfficesRequest: requestParams => dispatch(getOfficesRequest(requestParams)),
    getListViewProfileSettingsRequest: requestParams =>
      dispatch(getListViewProfileSettingsRequest(requestParams)),
    getUserListViewSettings: requestParams => dispatch(getUserListViewSettingsRequest(requestParams)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ProviderResultContainer);
