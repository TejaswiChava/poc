/* eslint-disable no-shadow */
import React, { Component } from 'react';
import _ from 'lodash';
import './style.scss';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import LoadingIndicator from 'components/LoadingIndicator';
import { DynamicForm } from '../ProviderResultFilterForm';
import Table from '../../components/Table/Table';
import {
  getContracts,
  getOffices,
  commandType,
  getListViewProfileSettings,
  getUserListViewSettings,
} from './selectors';
import { getCommandData, getSessionId } from '../../components/Header/selectors';
import {
  mockContractsRequestParam,
  mockgetListViewProfileSettingsRequestData,
  mockOfficesRequestParam,
  mockgetListViewProfileSettingsRequestData2,
  mockgetUserListViewSettingsRequestData,
  mockgetUserListViewSettingsRequestData2,
} from '../HomePage/mockData';

import {
  getContractsRequest,
  getOfficesRequest,
  getListViewProfileSettingsRequest,
  getUserListViewSettingsRequest,
} from '../HomePage/actions';
import ListTitle from '../../components/ListTitle/ListTitle';
import { NO_RESULT_FOUND } from '../App/constants';

class ProviderResultContainer extends Component {
  state = {
    formData: {},
    isColHidden: false,
    leftColSize: 3,
  };

  getCommandType = () => {
    const history = _.get(this.props, 'history', null);
    if (_.get(history, 'location.pathname', '') === '/results/contracts') {
      return 'Contract';
    }
    if (_.get(history, 'location.pathname', '') === '/results/office') {
      return 'Office';
    }
    return '';
  };

  handleSubmit = value => {
    // TODO: POST API CALL for Form Submit with State Values
    this.setState({ formData: value });
  };

  sliderAction = action => {
    if (action === 'openSlider') {
      this.setState({ leftColSize: 3, isColHidden: false });
    } else {
      this.setState({ leftColSize: 0, isColHidden: true });
    }
  };

  handleOnClick = (path, item) => {
    const history = _.get(this.props, 'history', null);
    if (history) {
      history.push(path, { post: item });
    }
  };

  // Getting the data back from Form on click of Find Button

  /**
   * =================
   * For Office 
   * {
  "sessionID": "string",
  "usage": "string",
  "resultCount": "string",
  "officeId": 0,
  "officeNumber": "string",
  "npi": "",
  "officeName": "string",
  "address1": "string",
  "contactPhone": "string",
  "zip": "string",
  "distance": "string",
  "region": "string",
  "city": "string",
  "county": "string",
  "state": "string",
  "countryCode": "string",
  "language": "string",
  "additionalService": "string",
  "wheelchairAccess": "string"
}
===============

For Contract
{
  "sessionID": "string",
  "contractID": "string",
  "usage": "string",
  "flag": "string",
  "contractName": "string",
  "contractNumber": "string",
  "contractType": "string",
  "feeScheduleId": "string",
  "providerId": "string",
  "officeId": "string",
  "vendorId": "string",
  "networkCode": "string",
  "asOfDate": "string",
  "capitationOnly": "string",
  "resultCount": "string",
  "reimbursementID": "string"
}
=============
   */
  // getFormData()
  getFormData = (formData, getProfileId) => {
    const commandType = this.getCommandType();
    const sessionId = _.get(this.props, 'sessionId', '');
    const commandData = _.get(this.props, 'commandData', null);

    const getContractsRequest = _.get(this.props, 'getContractsRequest', null);
    const getOfficesRequest = _.get(this.props, 'getOfficesRequest', null);
    const getListViewProfileSettingsRequest = _.get(this.props, 'getListViewProfileSettingsRequest', null);
    const getUserListViewSettingsRequest = _.get(this.props, 'getUserListViewSettingsRequest', null);

    if (commandType === 'Contract' && getContractsRequest) {
      const contractRequestBody = {
        sessionId: this.props.sessionId,
        contractId: '',
        usage: commandData ? commandData.findUsage : '',
        flag: '',
        contractName: formData.ContractName,
        contractNumber: formData.ContractNumber,
        contractType: '',
        feeScheduleId: '',
        providerId: '',
        officeId: '',
        vendorId: '',
        networkCode: '',
        asOfDate: formData.AsOfDate,
        capitationOnly: '',
        resultCount: formData.ResultCount,
        reimbursementID: formData.ReimbursementID,
      };
      const contractListViewSettingsRequestBody = {
        sessionId: this.props.sessionId,
        listviewName: commandType,
        listviewProfileId: getProfileId,
        usage: '|ForListview|',
      };
      const contarctUserListVeiwSettingsRequstBody = {
        sessionId: this.props.sessionId,
        formName: 'FindForm',
        listView: 'lvwResult',
        storedProcedure: 'ee_GetContracts',
      };
      getContractsRequest(contractRequestBody);
      getListViewProfileSettingsRequest(contractListViewSettingsRequestBody);
      getUserListViewSettingsRequest(contarctUserListVeiwSettingsRequstBody);
    } else if (commandType === 'Office' && getOfficesRequest) {
      const officeRequestBody = {
        sessionId: this.props.sessionId,
        usage: commandData ? commandData.findUsage : '',
        resultCount: formData.ResultCount,
        // officeId: 0,
        officeNumber: formData.OfficeNumber,
        npi: formData.NPI,
        officeName: formData.OfficeName,
        address1: formData.Address1,
        contactPhone: formData.ContactPhone,
        zip: formData.Zip,
        distance: formData.Distance,
        region: formData.Region,
        city: formData.City,
        county: formData.County,
        state: formData.State,
        countryCode: '',
        // language: formData.Language,
        additionalService: formData.AdditionalService,
        wheelchairAccess: formData.WheelchairAccess,
      };
      const officeListViewSettingsRequestBody = {
        sessionId: this.props.sessionId,
        listviewName: commandType,
        listviewProfileId: getProfileId,
        usage: '|ForListview|',
      };
      const officeUserListVeiwSettingsRequstBody = {
        sessionId: this.props.sessionId,
        formName: 'FindForm',
        listView: 'lvwResult',
        storedProcedure: 'ee_GetOffices_v2',
      };
      getOfficesRequest(officeRequestBody);
      getListViewProfileSettingsRequest(officeListViewSettingsRequestBody);
      getUserListViewSettingsRequest(officeUserListVeiwSettingsRequstBody);
    }
  };

  getTable = () => {
    const title = {
      name: NO_RESULT_FOUND,
    };
    let userListViewProfileSettings = {};
    const contracts = _.get(this.props, 'getContracts', []);
    const offices = _.get(this.props, 'getOffices', []);
    const listViewProfileSettings = _.get(this.props, 'getListViewProfileSettings', {});
    userListViewProfileSettings = _.get(this.props, 'getUserListViewSettings', {});
    const commandType = _.get(this.props, 'commandType', '');
    let listViewProfileSettingsData;
    if (
      !_.isEmpty(listViewProfileSettings) &&
      !_.isNull(listViewProfileSettings.listviewProfileSettingsDTO[0].profileId)
    ) {
      const settings = JSON.parse(listViewProfileSettings.listviewProfileSettingsDTO[0].settings);
      if (settings && settings.ListviewSettings && settings.ListviewSettings.VisibleColumns) {
        listViewProfileSettingsData = settings.ListviewSettings.VisibleColumns.Column;
      }
    }
    if (
      !_.isEmpty(listViewProfileSettings) &&
      _.isNull(listViewProfileSettings.listviewProfileSettingsDTO[0].profileId) &&
      !_.isEmpty(userListViewProfileSettings) &&
      !_.isEmpty(userListViewProfileSettings.userListviewSettingsXML)
    ) {
      listViewProfileSettingsData =
        userListViewProfileSettings.userListviewSettingsXML.Settings.Columns.Column;
    }

    if (
      !_.isEmpty(listViewProfileSettings) &&
      _.isNull(listViewProfileSettings.listviewProfileSettingsDTO[0].profileId) &&
      !_.isEmpty(userListViewProfileSettings) &&
      _.isEmpty(userListViewProfileSettings.userListviewSettingsXML)
    ) {
      const settings = JSON.parse(listViewProfileSettings.listviewProfileSettingsDTO[0].settings);
      if (settings && settings.ListviewSettings && settings.ListviewSettings.VisibleColumns) {
        listViewProfileSettingsData = settings.ListviewSettings.VisibleColumns.Column;
      }
    }
    if (
      !_.isEmpty(contracts) &&
      _.isEqual(commandType, 'Contract') &&
      !_.isEmpty(listViewProfileSettingsData)
    ) {
      return <Table listViewData={contracts} coloumsData={listViewProfileSettingsData} />;
    }
    if (!_.isEmpty(offices) && _.isEqual(commandType, 'Office') && !_.isEmpty(listViewProfileSettingsData)) {
      return <Table listViewData={offices} coloumsData={listViewProfileSettingsData} />;
    }

    return <ListTitle title={title} />;
  };

  render() {
    const commandType = _.get(this.props, 'commandType', '');
    if (_.get(this.props, 'getContractsRequest.isLoading', false) && commandType === 'Contract') {
      return (
        <div
          style={{
            flex: 1,
            justifyContent: 'center',
            alignContent: 'center',
            minHeight: window.innerHeight,
          }}
        >
          <LoadingIndicator />
        </div>
      );
    }
    return (
      <>
        <div className="ms-Grid" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">{/* Provider Sub header container */}</div>
          </div>

          <div className="ms-Grid-row section-rl-blocks" style={{ borderTop: '1px solid lightgrey' }}>
            <div
              className={`ms-Grid-col left-menu-aside ms-sm${this.state.leftColSize}`}
              hidden={this.state.isColHidden}
            >
              <DynamicForm
                commandType={this.getCommandType()}
                handleSubmit={this.handleSubmit}
                collapseHandle={action => this.sliderAction(action)}
                formData={this.getFormData}
              />
            </div>

            <div
              className={`ms-Grid-col right-table-content ms-sm${12 - this.state.leftColSize}`}
              style={{ padding: '3px 16px' }}
            >
              {this.state.isColHidden && (
                <button
                  type="button"
                  className="openbtn"
                  style={{
                    top: 0,
                    marginLeft: -17,
                    fontSize: 20,
                    padding: 2,
                    height: 62,
                    color: 'white',
                    border: 'none',
                    backgroundColor: '#004578',
                    position: 'absolute',
                  }}
                  onClick={() => this.sliderAction('openSlider')}
                >
                  »
                </button>
              )}
              {/* <h5>{JSON.stringify(this.state.formData, null, 1)}</h5> */}

              {this.getTable()}
            </div>
          </div>
        </div>
      </>
    );
  }
}

ProviderResultContainer.propTypes = {
  commandType: PropTypes.string,
  getContracts: PropTypes.array,
  getOffices: PropTypes.array,
  getListViewProfileSettings: PropTypes.object,
  getUserListViewSettings: PropTypes.object,
  sessionId: PropTypes.string,
  commandData: PropTypes.func,
  getContractsRequest: PropTypes.func,
  getOfficesRequest: PropTypes.func,
  getListViewProfileSettingsRequest: PropTypes.func,
  getUserListViewSettingsRequest: PropTypes.func,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  commandData: getCommandData(state),
  getContracts: getContracts(state),
  getOffices: getOffices(state),
  commandType: commandType(state),
  getListViewProfileSettings: getListViewProfileSettings(state),
  getUserListViewSettings: getUserListViewSettings(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    getContractsRequest: requestParams => dispatch(getContractsRequest(requestParams)),
    getOfficesRequest: requestParams => dispatch(getOfficesRequest(requestParams)),
    getListViewProfileSettingsRequest: requestParams =>
      dispatch(getListViewProfileSettingsRequest(requestParams)),
    getUserListViewSettingsRequest: requestParams => dispatch(getUserListViewSettingsRequest(requestParams)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ProviderResultContainer);
