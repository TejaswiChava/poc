import _ from 'lodash';

const getOffices = state => _.get(state, 'getOffices.data.offices_V2s', []);
const getContracts = state => _.get(state, 'getContracts.data.contractsDTO', []);

const commandType = state => {
  const routePath = _.get(state, 'router.location.pathname', '');
  return _.isEqual(routePath, '/results/office') ? 'Office' : 'Contract';
};

const getListViewProfileSettings = state => _.get(state, 'getListViewProfileSettings.data', {});

export { getContracts, getOffices, commandType, getListViewProfileSettings };
