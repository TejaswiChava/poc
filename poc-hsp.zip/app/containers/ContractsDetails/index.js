/*
 * Page
 *
 *
 */
import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';
import 'bootstrap/dist/css/bootstrap.css';

import editimage from '../../images/edit-black.png';

const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.9em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;
export const FooterStyle = styled.h5`
  text-align: left;
  margin-bottom: 0.1em;
  font-size: 0.6em;
  color: gray;
`;


function ContractDetails(props) {
  
  const post = _.get(props, 'NavDetails.location.state', null);
  
    return (
    <div>
      <Container fluid="lg">
        <div className="form-group">
          <button className="editbtn btn-pr btn-sm float-right" type="submit">
            <img src={editimage} alt="edit" />
          Edit
        </button>
        </div>
        <Heading>Contract Information</Heading>
        <Row>
          <Col md={3}>
            <Title> Contract Name</Title>
            <Detail> {post.contractName}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Type</Title>
            <Detail> {post.contractDescription}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Number</Title>
            <Detail>{post.contractNumber}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Effective Date</Title>
            <Detail> {post.effectiveDate}</Detail>
          </Col>
          <Col md={3}>
            <Title>Expiration Date</Title>
            <Detail> {post.expirationDate}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Description</Title>
            <Detail> {post.contractDescription}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Pricing Mode</Title>
            <Detail>{post.pricingMode}</Detail>
          </Col>
          <Col md={3}>
            <Title>Fee Schedule Search Criteria</Title>
            <Detail>{post.FeeScheduleSearchCriteria}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title>Contract Notes</Title>
            <Detail>{post.ContractNotes} </Detail>
          </Col>
        </Row>
        <FooterStyle id="header-content">Last updated by Santaco Martis at 4/7/2009 4:25:50 PM</FooterStyle>
      </Container>
    </div>
  );
}
export default withRouter(ContractDetails);
