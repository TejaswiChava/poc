import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';
import 'bootstrap/dist/css/bootstrap.css';

import editimage from '../../images/edit-black.png';

const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.75em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;


function ContractsAdditionalDetails(props) {
  
  const post = _.get(props, 'NavDetails.location.state', null);
  return (
    <div>
      <Container fluid="lg">
        <div className="form-group">
          <button className="editbtn btn-pr btn-sm float-right" type="submit">
            <img src={editimage} alt="edit" />
          Edit
        </button>
        </div>
        <Heading> Claims Posting</Heading>
        <Row>
          <Col md={3}>
            <Title> Payment Class</Title>
            <Detail>{post.paymentClass}</Detail>
          </Col>
          <Col md={3}>
            <Title> Suppress Payment</Title>
            <Detail>{post.suppressPayment}</Detail>
          </Col>
          <Col md={3}>
            <Title> Provider Inherit&apos;s Member&apos;s Mispayment</Title>
            <Detail>{post.providerInheritsMemberPayment}</Detail>
          </Col>
        </Row>
        <Heading>Capitation</Heading>
        <Row>
          <Col md={3}>
            <Title> Capitation Rate</Title>
            <Detail>{post.capitationRateName}</Detail>
          </Col>
          <Col md={3}>
            <Title>Last posted</Title>
            <Detail>{post.lastPostedDate}</Detail>
          </Col>
          <Col md={3}>
            <Title>Posting Cuttoff Day</Title>
            <Detail>{post.postingCutoffDay}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title>Retro Term Limit (Months)</Title>
            <Detail> {post.retroactiveTermLimit}</Detail>
          </Col>
          <Col md={3}>
            <Title>Retro Add Limit (Months)</Title>
            <Detail>{post.retroactiveAddLimit}</Detail>
          </Col>
        </Row>
        <Heading>Claims Adjudication</Heading>
        <Row>
          <Col md={3}>
            <Title> Who to Pay</Title>
            <Detail> {post.toPay}</Detail>
          </Col>
          <Col md={3}>
            <Title> Pre Estimate Expiration </Title>
            <Detail>{post.preEstExpUnits}</Detail>
          </Col>
          <Col md={3}>
            <Title> Apply Copay per schedule</Title>
            <Detail>{post.applyCopayPerSchedule}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Negotiated</Title>
            <Detail>{post.NegotiatedName}</Detail>
          </Col>
          <Col md={3}>
            <Title> Money Limit Processing Order </Title>
            <Detail>{post.MoneyLimitProcessingOrderName}</Detail>
          </Col>
          <Col md={3}>
            <Title> Use HCPCS When Adjustication Finds Fee Schedule</Title>
            <Detail>{post.useHCPCSWhenFindFeeSchedule}</Detail>
          </Col>
        </Row>
        <Heading>PCP Options</Heading>
        <Row>
          <Col md={3}>
            <Title> Panel Size Enforcement</Title>
            <Detail>{post.panelSizeEnforcement}</Detail>
          </Col>
          <Col md={3}>
            <Title> Panel Size Calculation Method </Title>
            <Detail>{post.panelSizeCalculationMethod}</Detail>
          </Col>
          <Col md={3}>
            <Title> Future PCP Lookback Period</Title>
            <Detail>{post.futurePCPLookbackPeriod}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Primary PCP Lookback Period</Title>
            <Detail>{post.primaryPCPLookbackPeriod}</Detail>
          </Col>
          <Col md={3}>
            <Title> Panel Override Allowance </Title>
            <Detail> {post.panelOverrideAllowance}</Detail>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
export default withRouter(ContractsAdditionalDetails);
