/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */

import React from 'react';
import { Helmet } from 'react-helmet';
import styled from 'styled-components';
import { Switch, Route } from 'react-router-dom';

import HomePage from 'containers/HomePage/Loadable';
import FeaturePage from 'containers/FeaturePage/Loadable';
import NotFoundPage from 'containers/NotFoundPage/Loadable';
import Header from 'components/Header';
// import Footer from 'components/Footer';

import { useInjectReducer } from 'utils/injectReducer';
import { useInjectSaga } from 'utils/injectSaga';
import LeftNavDetails from 'containers/LeftNavDetails/Loadable';
import GlobalStyle from '../../global-styles';

import reducer from '../HomePage/reducer';
import saga from '../HomePage/saga';
import ContractDetails from '../ContractsDetails';
import ContractsAdditionalDetails from '../ContractsAdditionalDetails';
import OfficesDemographicsDetails from '../OfficesDemographicsDetails';
import OfficesAdditionalDetails from '../OfficesAdditionalDetails';
import ProviderResultContainer from '../ProviderResultContainer';
import ContentView from '../../components/ContentView';
import Table from '../../components/Table/Table';

const AppWrapper = styled.div`
  /* max-width: calc(768px + 16px * 2); */
  margin: 0 auto;
  display: flex;
  min-height: 100%;
  /* padding: 0 16px; */
  flex-direction: column;
`;

const key = 'home';
export default function App() {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  return (
    <AppWrapper>
      <Helmet titleTemplate="" defaultTitle="Conduent HSP">
        <meta name="description" content="Conduent HSP App" />
      </Helmet>
      <Header />
      {/* <Button onClick={() => history.push('/contractDetails')}> Details </Button> */}
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route path="/features" component={FeaturePage} />
        <Route path="/leftNavDetails" component={LeftNavDetails} />
        <Route path="/contractDetails" component={ContractDetails} />
        <Route path="/contractsAdditionalDetails" component={ContractsAdditionalDetails} />
        <Route path="/officesDemographicsDetails" component={OfficesDemographicsDetails} />
        <Route path="/officesAdditionalDetails" component={OfficesAdditionalDetails} />

        <Route path="/results/office" component={ProviderResultContainer} />
        <Route path="/results/contracts" component={ProviderResultContainer} />

        <Route path="/ContentView" component={ContentView} />
        <Route path="/Table" component={Table} />
        <Route path="" component={NotFoundPage} />
      </Switch>
      {/* <Footer /> */}
      <GlobalStyle />
    </AppWrapper>
  );
}
