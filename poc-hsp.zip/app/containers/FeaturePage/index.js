/*
 * FeaturePage
 *
 *
 */
import React from 'react';
import { Helmet } from 'react-helmet';

export default function FeaturePage() {
  return (
    <div>
      <Helmet>
        <title>Provider Page</title>
        <meta name="description" content="HSP App" />
      </Helmet>
      <div dir="ltr">
        <div className="ms-Grid-col ms-sm6 ms-md4 ms-lg2">
          <h2>A sample feature Container page</h2>
        </div>
        <div className="ms-Grid-col ms-sm6 ms-md8 ms-lg10">Table</div>
      </div>
    </div>
  );
}
