import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';

import cross from '../../images/delete-red.png';
import tick from '../../images/check-greeen.png';
import editimage from '../../images/edit-black.png';

const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.75em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;

const HoursImage = styled.img`
  width: 20px;
  height: 20px;
  /* margin: 5px; */
`;

class OfficesAdditionalDetails extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const post = this.props.NavDetails;

    return (
      <div>
        <Container fluid="lg">
          <div className="form-group">
            <button className="editbtn btn-pr btn-sm float-right" type="submit">
              <img src={editimage} alt="edit" />
              Edit
            </button>
          </div>
          <Heading>Additional Office Details</Heading>
          <Row>
            <Col md={3}>
              <Title> Facility Operating Number</Title>
              <Detail>{post.facilityOperatingNumber}</Detail>
            </Col>
            <Col md={3}>
              <Title> Permanent Facility Identifier</Title>
              <Detail>{post.permanentFacilityID}</Detail>
            </Col>
            <Col md={3}>
              <Title> National Provider Identifier</Title>
              <Detail>{post.allowInvalidNPI}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title> Number of Physicians</Title>
              <Detail>{post.numberOfPhysicians}</Detail>
            </Col>
            <Col md={3}>
              <Title>Contacting Provider</Title>
              <Detail>{post.contractingProviderName}</Detail>
            </Col>
            <Col md={3}>
              <Title>Access Code</Title>
              <Detail>{post.accessCode}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Total Office Hours</Title>
              <Detail>{post.totalOfficeHours}</Detail>
            </Col>
            <Col md={3}>
              <Title>After Hours Contact Method</Title>
              <Detail>{post.afterHoursContactMethod}</Detail>
            </Col>
            <Col md={3}>
              <Title>Wheelchair Access</Title>
              <Detail>{post.wheelchairAccess}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Allow RA Access on Web</Title>
              <Detail>{post.allowRAAccessOnWeb}</Detail>
            </Col>
            <Col md={3}>
              <Title>Show in Web Directory</Title>
              <Detail>{post.showInWebDirectory}</Detail>
            </Col>
            <Col md={3}>
              <Title>Allow Invalid NPI Format</Title>
              <Detail>{post.allowInvalidNPI}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Available After Hours</Title>
              <Detail>{post.availableAfterHours}</Detail>
            </Col>
            <Col md={3}>
              <Title>Override Duplicate Address</Title>
              <Detail>{post.overrideDuplicateAddress}</Detail>
            </Col>
          </Row>
          <Heading>Office Hours</Heading>
          <Row>
            <Row>
              {' '}
              <HoursImage src={tick} />
            </Row>
            <Col md={2}>
              <Title>Monday</Title>
              <Detail>
                {post.mondayStart}-{post.mondayEnd}
              </Detail>
            </Col>
            <Row>
              {' '}
              <HoursImage src={tick} />
            </Row>
            <Col md={2}>
              <Title>Tuesday</Title>
              <Detail>
                {post.tuesdayStart}-{post.tuesdayEnd}
              </Detail>
            </Col>
            <Row>
              {' '}
              <HoursImage src={tick} />
            </Row>
            <Col md={2}>
              <Title>Wednesday</Title>
              <Detail>
                {post.wednesdayStart}-{post.wednesdayEnd}
              </Detail>
            </Col>
            <Row>
              {' '}
              <HoursImage src={tick} />
            </Row>
            <Col md={2}>
              <Title>Thursday</Title>
              <Detail>
                {post.thursdayStart}-{post.thursdayEnd}
              </Detail>
            </Col>
            <Row>
              {' '}
              <HoursImage src={tick} />
            </Row>
            <Col md={2}>
              <Title>Friday</Title>
              <Detail>
                {post.fridayStart}-{post.fridayEnd}M
              </Detail>
            </Col>
          </Row>
          <Row>
            <Row>
              {' '}
              <HoursImage src={cross} />
            </Row>
            <Col md={2}>
              <Title>Saturday</Title>
              <Detail>
                {post.saturdayStart}-{post.saturdayEnd}
              </Detail>
            </Col>
            <Row>
              {' '}
              <HoursImage src={cross} />
            </Row>
            <Col md={2}>
              <Title>Sunday</Title>
              <Detail>__</Detail>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}
export default withRouter(OfficesAdditionalDetails);
