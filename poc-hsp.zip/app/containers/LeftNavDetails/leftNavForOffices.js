import React from 'react';
import { withRouter, BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.css';
import './DetailsStyles.css';
import './LeftNavStyles.scss';


const MainTitle = styled.h5`
  text-align: left;
  font-size: 1em;
  color: grey;
  padding-top: 0.75em;
  margin-top: 0.75em;
  margin-left: 0.75em;
  vertical-align: middle;
`;

const Title = styled.h5`
  color: black;
  text-align: left;
  justify-content: center;
  font-size: 0.9em;
  color: grey;
  margin-left: 1.5em;
  height: 15px;
  vertical-align: middle;
  margin-bottom: 0.75em;
`;


export const ProviderOfficesList = [
    {
        Category: 'PROPERTIES',
        CategoryType: 'PROPERTIES',
        items: [
            { NavTitle: 'Demographics', navPath: './officesDemographicsDetails',  id: 1 },
            { NavTitle: 'Additional Details', navPath: './officesAdditionalDetails',  id: 2 },
        ],
    },
    {
        Category: 'MAPPINGS',
        CategoryType: 'MAPPINGS',
        items: [
            { NavTitle: 'Contracts', navPath: './', id: 3},
            { NavTitle: 'Additional Contracts', navPath: './officesAdditionalDetails', id:4 },
            { NavTitle: 'Additional Services', navPath: './officesAdditionalDetails', id:5},
            { NavTitle: 'Alternate Addresses', navPath: './officesAdditionalDetails', id:6 },
            { NavTitle: 'Attachment', navPath: './officesAdditionalDetails', id:7 },
            { NavTitle: 'DRG Facility Weights', navPath: './officesAdditionalDetails', id:8 },
            { NavTitle: 'Languages', navPath: './officesAdditionalDetails', id:9 },
            { NavTitle: 'Events', navPath: './officesAdditionalDetails', id:10},
            { NavTitle: 'Fulfilment', navPath: './officesAdditionalDetails', id:11},
        ],
    },
    {
        Category: 'RELATED ITEMS',
        CategoryType: 'RELATED ITEMS',
        items: [{ NavTitle: 'Claims', navPath: './officesAdditionalDetails', id: 12 }],
    },
];

class LeftNavForOffices extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isClassNameShow: false
        }
      
    }
    ActiveClass = (e) => {
        // alert("test");

        this.setState({
            isClassNameShow: true
        })
        console.log(e.target.id);
    };

    checkActive = (match, location) => {
       // console.log(location);
        if (!location) return false;
        const { pathname } = location;
        const { url } = match;
        return pathname === url ? true : false;
      };
     
    render() {

       
          
        return (
            <div className="col-2 p-0 border ">
                <nav id="sidebar bd-sidebar">
                    {ProviderOfficesList.map(({ CategoryType, Category, items: subItems, ...rest }) => (
                        <ul className="list-unstyled" key={CategoryType} {...rest}>
                            <MainTitle>{Category}</MainTitle>
                            {subItems.map(({ NavTitle, navPath }) => (
                                 <li class="borderlist">
                                 <Title className="List-Item">
                                   <Link style={{ textDecoration: 'none', color: 'black' }} to={navPath}>{NavTitle}</Link>
                                 </Title>
                               </li>
                            ))}
                        </ul>
                    ))}
                </nav>
            </div>
        );
    }
}
export default LeftNavForOffices;