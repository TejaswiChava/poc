/*
 * LeftNavDetails
 *
 *
 */
import React, { Component } from 'react';
import { withRouter, BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.css';
import ContractDetails from '../ContractsDetails';
import ContractsAdditionalDetails from '../ContractsAdditionalDetails';
import OfficesDemographicsDetails from '../OfficesDemographicsDetails';
import OfficesAdditionalDetails from '../OfficesAdditionalDetails';
import NotFoundPage from '../NotFoundPage';
import LeftNavForOffices from './leftNavForOffices';
import './DetailsStyles.css';
import './LeftNavStyles.scss';

const MainTitle = styled.h5`
  text-align: left;
  font-size: 1em;
  color: grey;
  padding-top: 0.75em;
  margin-top: 0.75em;
  margin-left: 0.75em;
  vertical-align: middle;
`;

const Title = styled.h5`
  color: black;
  text-align: left;
  justify-content: center;
  font-size: 0.9em;
  color: grey;
  margin-left: 1.5em;
  height: 15px;
  vertical-align: middle;
  margin-bottom: 0.75em;
`;

const selectionIndicator = styled.div`
  &:before {
    content: '\2022';
    color: orange
    padding-right: 5px;
    font-size: 33px;
    line-height: 2px;
    position: relative;
    top: 6px;
    visibility: hidden;

  }
`;

export const ProviderContractList = [
  {
    Category: 'PROPERTIES',
    CategoryType: 'PROPERTIES',
    items: [
      { NavTitle: 'Details', navPath: './contractDetails' },
      { NavTitle: 'Additional Details', navPath: './contractsAdditionalDetails' },
    ],
  },
  {
    Category: 'MAPPINGS',
    CategoryType: 'MAPPINGS',
    items: [
      { NavTitle: 'Fee Schedules', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'Reimbursments', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'Denial Categories', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'Attachments', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'Ambulatory Procedure Code Grouping Exceptions', navPath: './contractsAdditionalDetails' },
    ],
  },
  {
    Category: 'RELATED ITEMS',
    CategoryType: 'RELATED ITEMS',
    items: [
      { NavTitle: 'Providers', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'Service Restriction Packages', navPath: './contractsAdditionalDetails' },
      { NavTitle: 'History', navPath: './contractsAdditionalDetails' },
    ],
  },
];

class LeftNavForContracts extends React.Component {
  render() {
    return (
      <div className="col-2 py-3 p-2 border ">
        <nav id="sidebar bd-sidebar">
          {ProviderContractList.map(({ CategoryType, Category, items: subItems, ...rest }) => (
            <ul className="list-unstyled components" key={CategoryType} {...rest}>
              <MainTitle>{Category}</MainTitle>
              {subItems.map(({ NavTitle, navPath }) => (
                <li className="borderlist">
                  <Title className="List-Item">
                    <Link style={{ textDecoration: 'none', color: 'black' }} to={navPath}>
                      {NavTitle}
                    </Link>
                  </Title>
                </li>
              ))}
            </ul>
          ))}
        </nav>
      </div>
    );
  }
}

function LeftNavDetails(props) {
  console.log(props.item);

  return (
    <BrowserRouter>
      <div className="container-fluid d-flex bg-light">
        <LeftNavForOffices />
        <div className="col-10 py-3 p-2 border details-right-block">
          <Switch>
            <Route exact path="/contractDetails" render={() => <ContractDetails NavDetails={props} />} />
            <Route
              exact
              path="/contractsAdditionalDetails"
              render={() => <ContractsAdditionalDetails NavDetails={props} />}
            />
            <Route
              exact
              path="/officesDemographicsDetails"
              render={() => <OfficesDemographicsDetails NavDetails={props} />}
            />
            <Route
              exact
              path="/officesAdditionalDetails"
              render={() => <OfficesAdditionalDetails NavDetails={props} />}
            />
            {/* <Route path="" component={NotFoundPage} /> */}
          </Switch>
        </div>
      </div>
    </BrowserRouter>
  );
}
export default withRouter(LeftNavDetails);
