import * as yup from 'yup';

export const createYupSchema = (schemas, config) => {
  const schema = schemas;
  const { id, validationType, validations = [] } = config;
  if (!yup[validationType]) {
    return schema;
  }
  let validator = yup[validationType]();
  validations.forEach(validation => {
    const { params, type } = validation;
    if (!validator[type]) {
      return;
    }

    validator = validator[type](...params);
  });
  schema[id] = validator;
  return schema;
};

export const getParamValueFromSQL = (sqlParams, paramName) => {
  if (!sqlParams) {
    return '';
  }
  const regex = new RegExp(`@${paramName}(.*)`);
  const value = sqlParams.match(regex);
  const paramObj = value && value.length > 0 ? value[0].split(',')[0].slice() : '';
  const paramValue = paramObj ? paramObj.split('=')[1].trim() : '';
  return paramValue.substring(1, paramValue.length - 1);
};

export const getApiNameFromSQL = sqlParams => {
  if (!sqlParams) {
    return '';
  }
  const value = sqlParams.match(/exec ee_(.*)/);
  const apiName = value && value.length >= 2 ? value[1] : '';
  return apiName ? apiName.split(' ')[0].slice() : '';
};

// ToDo : Remove bellow comments after API integration

// getOptionsData = (formType: string, fieldName: string, formProps: any, item: any) => {

//   // const apiName = getApiNameFromSQL(item.comboBoxSql);
//   // const apiParams: any = {
//   //   SessionID: '',
//   //   Usage: '',
//   //   Type: "",
//   //   SubType: "",
//   //   State: '',
//   // }
//   // for (var key of Object.keys(apiParams)) {
//   //   const paramsValue = getParamValueFromSQL(item.comboBoxSql, key)
//   //   apiParams[`${key}`] = paramsValue !== 'LINK' ? paramsValue : formProps.values.State
//   // }
//   // console.log('API==>', apiName, '\n params=>', apiParams);

//   //TODO:MasterData API call
//   if (formType === 'Contract') {
//     if (fieldName === 'ReimbursementID') {
//       //TODO: Get Data for Contract form ReimbursementID field
//       return reimbursementOptions.benefitStructuresDTO || []
//     }
//   }
//   else if (formType === 'Office') {
//     if (fieldName === 'Region') {
//       //TODO: Get Data for Office form Region field
//       return region.referenceCodes_V2DTOs || []
//     }
//     else if (fieldName === 'State') {
//       //TODO: Get Data for Office form State field
//       return region.referenceCodes_V2DTOs || []
//     }
//     else if (fieldName === 'Language') {
//       //TODO: Get Data for Office form County field with stateValue
//       return language.referenceCodes_V2DTOs || []
//     }
//     else if (fieldName === 'AdditionalService') {
//       //TODO: Get Data for Office form County field with stateValue
//       return additionalService.referenceCodes_V2DTOs || []
//     }
//     else if (fieldName === 'WheelchairAccess') {
//       //TODO: Get Data for Office form County field with stateValue
//       return wheelChairAccess.referenceCodes_V2DTOs || []
//     }
//     else if (fieldName === 'ResultCount') {
//       //TODO: Get Data for Office form County field with stateValue
//       return paginationData.referenceCodes_V2DTOs || []
//     }

//     else if (fieldName === 'County') {
//       if (!formProps.values.State && formProps.values.County) {
//         formProps.setFieldValue('County', "")
//       } else if (formProps.values.State) {
//         //TODO: Get Data for Office form County field with stateValue
//         return region.referenceCodes_V2DTOs || []
//       }
//     }
//   }
//   return [];

// }
