import React, { Component } from 'react';

import { connect } from 'react-redux';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import LoadingIndicator from 'components/LoadingIndicator';

import { Formik } from 'formik';
import * as yup from 'yup';
import _ from 'lodash';
import { PrimaryButton } from 'office-ui-fabric-react';

import { getParamValueFromSQL, getApiNameFromSQL, createYupSchema } from './utility';
import InputTextBox from '../../components/InputTextBox/index';
import ComboBox from '../../components/ComboBox/index';
import ResultCountButtons from '../../components/ResultCountButtons/index';
import CustomDatePicker from '../../components/CustomDatePicker/index';

// TODO: Replace JSON data With API Data
import paginationData from './mockData/Contract_Find_Form_Result_Count_Values.json';
import additionalService from './mockData/options/additionalService.json';
import ProfileAction from '../../components/ProfileAction/CustomToggle';
import lastSearch from '../../images/icons/recent-search.svg';
import { getSessionId, getControl } from './selectors';

import {
  getUserOptionsRequest,
  getFindProfilesRequest,
  getFindControlRequest,
  getLinkedDropDownValuesRequest,
  getReferenceCodesRequest,
} from './actions';

class __DynamicForm extends Component {
  state = {
    options: {},
  };

  componentDidMount() {
    this.loadComponentData();

    this.setState(prevState => {
      const optionObj = { ...prevState.options };
      _.get(this.props, 'findControls.data', []).map(item => {
        if (
          ['ToolkitCombobox', 'ToolkitMultiColumnCombobox'].indexOf(item.controlType) > -1 &&
          item.name !== 'County'
        ) {
          // TODO : API name and params should come from api mapper
          const apiName = getApiNameFromSQL(item.comboBoxSql);
          const apiParams = {
            SessionID: '',
            Usage: '',
            Type: '',
            SubType: '',
            State: '',
          };

          Object.keys(apiParams).map(key => {
            const paramsValue = getParamValueFromSQL(item.comboBoxSql, key);
            apiParams[`${key}`] = paramsValue;
            return apiParams;
          });
          const options = this.getOptionsDataFromAPI(apiName, apiParams);
          optionObj[`${item.name}`] = options;
        }
        return optionObj;
      });
      return { options: optionObj };
    });
  }

  getSnapshotBeforeUpdate(prevProps) {
    if (prevProps.commandType !== this.props.commandType) {
      this.loadComponentData();
    }
  }

  getOptionsDataFromAPI = (url, param) => {
    // TODO : API structure here ; This method to do API call and return response
    // eslint-disable-next-line no-console
    console.log(param, url);
    return additionalService.referenceCodes_V2DTOs || [];
  };

  // This will fetch & set county option data based on state data.
  onClickHandle = (fieldName, formProps) => {
    if (!formProps.values.State && !formProps.values.County) {
      return;
    }
    const stateOptions = { ...this.state.options };
    if (fieldName === 'State' && formProps.values.State) {
      const options = this.getOptionsDataFromAPI('HardCodedUriForCounty', 'hardCodedParamsForCounty');
      stateOptions.County = options;
      this.setState({ options: stateOptions });
    } else if (fieldName === 'State' && !formProps.values.State) {
      stateOptions.County = [];
      formProps.setFieldValue('County', '');
      this.setState({ options: stateOptions });
    }
  };

  // This is to decide which component will render in form.
  renderFormElements = props => {
    try {
      return _.get(this.props, 'findControls.data', []).map(item => {
        // Component Mapper based on type
        const fieldMap = {
          text: InputTextBox,
          date: CustomDatePicker,
          select: ComboBox,
          result: ResultCountButtons,
        };

        const DynamicComponent = fieldMap[item.type];
        if (!DynamicComponent) {
          return '';
        }

        const error =
          Object.prototype.hasOwnProperty.call(props.errors, item.id) &&
          _.get(props, `errors[${item.id}]`, '');

        if (item.type && ['text', 'date'].indexOf(item.type) > -1 && item.visible === 'Y') {
          return (
            <DynamicComponent
              type={item.type}
              key={`text_${item.name}`}
              label={item.label}
              name={item.name}
              id={item.id}
              placeholder={item.placeholder}
              value={props.values[item.id]}
              onChange={props.handleChange}
              error={error}
              isRequired={item.required === 'Y'}
              title={item.tooltip}
            />
          );
        }

        if (item.type && ['select'].indexOf(item.type) > -1 && item.visible === 'Y') {
          return (
            <DynamicComponent
              key={`Select_${item.name}`}
              label={item.label}
              name={item.id}
              value={props.values[item.id]}
              onChange={props.handleChange}
              error={error}
              isRequired={item.required === 'Y'}
              title={item.tooltip}
              type={item.controlType}
              onClickHandle={() => this.onClickHandle(item.name, props)}
              // options={_.get(this.state.options, [`${item.name}`], [])}
              options={additionalService.referenceCodes_V2DTOs || []}
              isLoading={false}
            />
          );
        }

        if (item.type && ['result'].indexOf(item.type) > -1 && item.visible === 'Y') {
          // TOCheck : why if and else is same
          const value = props.values[`${item.name}`]
            ? props.values[`${item.name}`]
            : props.values[`${item.name}`];
          return (
            <DynamicComponent
              key={`pagination_${item.name}`}
              label={item.label}
              paginationData={paginationData.referenceCodes_V2DTOs}
              // paginationData={_.get(this.state.options, [`${item.name}`], [])} // TODO: Use after API Integration
              error={error}
              isRequired={item.required === 'Y'}
              setResultCount={count => props.setFieldValue(item.name, count.code)}
              title={item.tooltip}
              value={value}
            />
          );
        }
        return '';
      });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(`ERROR: in DynamicFormScree/renderFormElements() \n${error}`);
      return '';
    }
  };

  setInitialValues = () => {
    try {
      const initialValues = {};
      _.get(this.props, 'findControls.data', []).forEach(item => {
        initialValues[item.name] = item.value || '';
      });
      return initialValues;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(`ERROR: in DynamicFormScree/setInitialValues() \n${error}`);
      return {};
    }
  };

  getFormControlData = () => {
    const sessionId = _.get(this.props, 'sessionId', '');
    const mockGetFindCommandsRequestParam = {
      sessionId,
      usage: '|ByFindCommand|',
      findCommand: this.props.commandType,
    };
    this.props.getFindControl(mockGetFindCommandsRequestParam);
  };

  loadComponentData = () => {
    this.getFormControlData();
  };

  render() {
    const initialValues = this.setInitialValues();
    const input = _.get(this.props, 'findControls.data', []);

    const yepSchema = input.reduce(createYupSchema, {});
    const validateSchema = yup.object().shape(yepSchema);

    if (_.get(this.props, 'findControls.isLoading', false)) {
      return (
        <div
          style={{
            flex: 1,
            justifyContent: 'center',
            alignContent: 'center',
            minHeight: window.innerHeight,
          }}
        >
          <LoadingIndicator />
        </div>
      );
    }
    if (_.get(this.props, 'findControls.isError', false)) {
      return (
        <div
          style={{
            minHeight: window.innerHeight,
            padding: 30,
          }}
        >
          <PrimaryButton
            style={{
              background: 'white',
              color: '#0078D4',
            }}
            text="Retry"
            allowDisabledFocus
            onClick={() => this.loadComponentData()}
          />
        </div>
      );
    }

    return (
      <>
        <div className="ms-Grid leftMenu-block" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12 form">
              {/* form action icons */}
              <div className="ms-Grid-row parameter-grid">
                <div className="ms-Grid-col ms-sm6 ms-md8 ms-lg9 ">
                  <button
                    type="button"
                    onClick={() => {
                      const collapseHandle = _.get(this.props, 'collapseHandle', null);
                      if (collapseHandle) {
                        collapseHandle('closeSlider');
                      }
                    }}
                    style={{
                      fontSize: 24,
                      background: 'transparent',
                      border: 'unset',
                      cursor: 'pointer',
                    }}
                  >
                    &#171;
                  </button>
                  <span> PARAMETERS</span>
                </div>
                <div className="ms-Grid-col ms-sm6 ms-md4 ms-lg3 " style={{ top: 5, textAlign: 'right' }}>
                  <div className="ms-Grid-row parameter-grid-row">
                    <div
                      className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 parameter-left-menu"
                      style={{ fontSize: 20, cursor: 'pointer' }}
                    >
                      {/* &#9881; */}
                      <ProfileAction />
                    </div>
                    <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 ">
                      <span
                        style={{
                          fontSize: 20,
                          textAlign: 'right',
                          cursor: 'pointer',
                        }}
                      >
                        {' '}
                        {/* &#8634; */}
                        <img src={lastSearch} alt="lastSearch" />
                      </span>
                      {/* <image
                        src="../../images/icons/recent-search.svg"
                        alt="search"
                        style={{ height: 20, width: 20 }}
                      /> */}
                    </div>
                  </div>
                </div>
              </div>

              <Formik
                initialValues={initialValues}
                validationSchema={validateSchema}
                onSubmit={(values, actions) => {
                  // eslint-disable-next-line no-console
                  console.log('Values---->', values, '\n actions--->', actions);

                  // Pass the data back to ProviderResultContainer
                  const formData = _.get(this.props, 'formData', null);
                  if (formData) {
                    formData(values);
                  }

                  const handleSubmit = _.get(this.props, 'handleSubmit', null);
                  if (handleSubmit) {
                    handleSubmit(values);
                  }

                  actions.setSubmitting(false); // TODO: need to set false inside submit API
                }}
              >
                {props => (
                  <div>
                    <form onSubmit={props.handleSubmit}>
                      <div
                        style={{
                          overflowY: 'scroll',
                          overflowX: 'hidden',
                          top: 0,
                          bottom: 0,
                          height: window.innerHeight,
                          paddingLeft: 16,
                          paddingRight: 16,
                          paddingBottom: 16,
                          backgroundColor: '#ebedf0',
                        }}
                      >
                        {this.renderFormElements(props)}
                      </div>
                      <div style={{ paddingTop: 16, textAlign: 'right' }}>
                        <div className="ms-Grid-row">
                          <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg8 ">
                            <PrimaryButton
                              style={{ background: 'white', color: '#0078D4' }}
                              text="Clear"
                              allowDisabledFocus
                              onClick={() => props.resetForm(initialValues)}
                              disabled={props.isSubmitting}
                            />
                          </div>
                          <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg4 ">
                            <PrimaryButton
                              text="Find"
                              allowDisabledFocus
                              type="submit"
                              block
                              disabled={props.isSubmitting}
                            />
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </>
    );
  }
}

__DynamicForm.propTypes = {
  getUserOptions: PropTypes.func,
  getFindProfiles: PropTypes.func,
  getFindControl: PropTypes.func,
  getLinkedDropDownValues: PropTypes.func,
  getReferenceCodes: PropTypes.func,
  sessionId: PropTypes.string,
  commandType: PropTypes.string,
  formData: PropTypes.func,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state.connectUser),
  findControls: getControl(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    getUserOptions: requestParams => dispatch(getUserOptionsRequest(requestParams)),
    getFindProfiles: requestParams => dispatch(getFindProfilesRequest(requestParams)),
    getFindControl: requestParams => dispatch(getFindControlRequest(requestParams)),
    getLinkedDropDownValues: requestParams => dispatch(getLinkedDropDownValuesRequest(requestParams)),
    getReferenceCodes: requestParams => dispatch(getReferenceCodesRequest(requestParams)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

// export default compose(withConnect)(DynamicForm);
export const DynamicForm = compose(withConnect)(__DynamicForm);
