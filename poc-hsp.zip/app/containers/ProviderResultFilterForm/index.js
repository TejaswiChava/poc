/* eslint-disable no-shadow */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
import React, { Component } from 'react';

import { connect } from 'react-redux';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import LoadingIndicator from 'components/LoadingIndicator';
import LoadingOverlay from 'react-loading-overlay';
import { Formik } from 'formik';
import * as yup from 'yup';
import _ from 'lodash';
import { PrimaryButton } from 'office-ui-fabric-react';

import { createYupSchema } from './utility';
import InputTextBox from '../../components/InputTextBox/index';
import ComboBox from '../../components/ComboBox/index';
import ResultCountButtons from '../../components/ResultCountButtons/index';
import CustomDatePicker from '../../components/CustomDatePicker/index';

import ProfileAction from '../../components/ProfileAction/CustomToggle';
import lastSearch from '../../images/icons/recent-search.svg';
import {
  getControl,
  getAllDropDownValues,
  getDropDownStatus,
  getReferenceCode,
  getFindProfilesData,
  getSearchedItems,
  getProfileId,
} from './selectors';

import { getCommandId, getUserId, getSessionId, getUsage } from '../../components/Header/selectors';

import {
  getUserOptionsRequest,
  getFindProfilesRequest,
  getFindControlRequest,
  getLinkedDropDownValuesRequest,
  getReferenceCodesRequest,
} from './actions';

import { clearTableData } from '../HomePage/actions';

class __DynamicForm extends Component {
  componentDidMount() {
    this.loadComponentData();
    this.props.clearTableData();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.commandType !== this.props.commandType) {
      this.loadComponentData();
      this.props.clearTableData();
    }
  }

  // This will fetch & set county option data based on state data.
  onClickHandle = item => {
    const itemOptions = _.get(this.props.allDropDownValues, `${[item.name]}`, []);
    if (itemOptions && itemOptions.length && item.name !== 'County') {
      return;
    }
    if (
      ['ToolkitCombobox', 'ToolkitMultiColumnCombobox'].indexOf(item.controlType) > -1 &&
      ['County', 'Language', 'State'].indexOf(item.name) === -1 &&
      item.comboBoxSql
    ) {
      const apiParams = {
        spQuery: item.comboBoxSql.replace('{0}', this.props.sessionId),
        staticColumnName: item.displayFieldName,
        dynamicColumnName: item.displayIDName,
      };
      this.props.getLinkedDropDownValues(apiParams, item.name);
    } else if (['Language'].indexOf(item.name) > -1) {
      const apiParams = {
        SessionId: this.props.sessionId,
        Type: 'LANGUAGE',
        Usage: this.props.getUsage,
        AllowCheckout: 'N',
      };
      this.props.getReferenceCodes(apiParams, item.name);
    }
  };

  // Refactor Needed
  onClickCaptureHandle = (item, formProps) => {
    const { sessionId } = this.props;
    if (item.name !== 'State') {
      return;
    }
    const itemOptions = _.get(this.props.allDropDownValues, `${[item.name]}`, []);
    if (!(itemOptions && itemOptions.length)) {
      const apiParams = {
        spQuery: item.comboBoxSql.replace('{0}', sessionId),
        staticColumnName: item.displayFieldName,
        dynamicColumnName: item.displayIDName,
      };
      this.props.getLinkedDropDownValues(apiParams, item.name);
    }
    if (formProps.values.State) {
      const comboBoxSql = "exec ee_GetDemographicsFromZips @SessionID={0}, @Usage='|COUNTY|', @State=#LINK#";
      const sql = comboBoxSql.replace('{0}', sessionId);
      const apiParams = {
        spQuery: sql.replace('#LINK#', formProps.values.State),
        staticColumnName: 'Demographic',
        dynamicColumnName: 'Demographic',
      };
      this.props.getLinkedDropDownValues(apiParams, 'County');
    } else if (!formProps.values.State) {
      formProps.setFieldValue('County', '');
    }
  };

  renderFormElements = props => {
    try {
      return _.get(this.props, 'findControls.data', []).map(item => {
        // Component Mapper based on type
        const fieldMap = {
          text: InputTextBox,
          date: CustomDatePicker,
          select: ComboBox,
          result: ResultCountButtons,
        };

        const DynamicComponent = fieldMap[item.type];
        if (!DynamicComponent) {
          return '';
        }

        const error =
          Object.prototype.hasOwnProperty.call(props.errors, item.id) &&
          _.get(props, `errors[${item.id}]`, '');

        if (item.type && ['text', 'date'].indexOf(item.type) > -1 && item.visible === 'Y') {
          return (
            <DynamicComponent
              type={item.type}
              key={`text_${item.name}`}
              label={item.label}
              name={item.name}
              id={item.id}
              placeholder={item.placeholder}
              value={props.values[item.id]}
              onChange={props.handleChange}
              error={error}
              isRequired={item.required === 'Y'}
              title={item.tooltip}
            />
          );
        }

        if (item.type && ['select'].indexOf(item.type) > -1 && item.visible === 'Y') {
          let optionsData = [];
          if (item.name === 'Language') {
            optionsData = _.get(this.props.referenceCode, `${[item.name]}`, []);
          } else if (!props.values.State && item.name === 'County') {
            optionsData = [];
          } else {
            optionsData = _.get(this.props.allDropDownValues, `${[item.name]}`, []);
          }
          return (
            <DynamicComponent
              key={`Select_${item.name}`}
              label={item.label}
              name={item.id}
              value={props.values[item.id]}
              onChange={props.handleChange}
              error={error}
              isRequired={item.required === 'Y'}
              title={item.tooltip}
              type={item.controlType}
              onClickHandle={() => this.onClickHandle(item)}
              options={optionsData.length > 0 ? [{ name: 'Please Select', value: '' }, ...optionsData] : []}
              isLoading={false}
              onClickCapture={() => this.onClickCaptureHandle(item, props)}
            />
          );
        }

        if (item.type && ['result'].indexOf(item.type) > -1 && item.visible === 'Y') {
          const value = props.values[`${item.name}`] ? props.values[`${item.name}`] : '';
          return (
            <DynamicComponent
              key={`pagination_${item.name}`}
              label={item.label}
              paginationData={_.get(this.props.referenceCode, `${[item.name]}`, [])}
              error={error}
              isRequired={item.required === 'Y'}
              setResultCount={count => props.setFieldValue(item.name, count.code)}
              title={item.tooltip}
              value={value}
            />
          );
        }
        return '';
      });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(`ERROR: in DynamicFormScree/renderFormElements() \n${error}`);
      return '';
    }
  };

  setInitialValues = () => {
    try {
      const initialValues = {};
      _.get(this.props, 'findControls.data', []).forEach(item => {
        initialValues[item.name] = item.value || '';
      });
      return initialValues;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(`ERROR: in DynamicFormScree/setInitialValues() \n${error}`);
      return {};
    }
  };

  getFormControlData = () => {
    const { commandType } = this.props;
    const formParam = {
      sessionId: this.props.sessionId,
      usage: '|ByFindCommand|',
      findCommand: commandType,
    };
    this.props.getFindControl(formParam);
  };

  getResultCountData = getUsage => {
    const resultCountParam = {
      sessionId: this.props.sessionId,
      Type: 'RESULTCOUNT',
      SubType: 'RESULTCOUNT',
      Usage: getUsage,
      AllowCheckout: 'N',
    };
    this.props.getReferenceCodes(resultCountParam, 'ResultCount');
  };

  getProfiles = commandId => {
    const profilesRequestData = {
      sessionId: this.props.sessionId,
      findCommandId: commandId,
      usage: '|ForFindCommand|',
    };
    this.props.getFindProfiles(profilesRequestData);
  };

  getLastSearchedItems = formProps => {
    let itemType = '';
    if (this.props.commandType === 'Contract') {
      itemType = 'ContractSearch';
    } else {
      itemType = 'OfficeSearch';
    }
    const lastSearchedItemParam = {
      userID: '267',
      itemType,
    };
    this.props.getUserOptions(lastSearchedItemParam);
    this.setDefaultValues(itemType, formProps);
  };

  setDefaultValues = (itemType, formProps) => {
    const data = _.get(this.props.lastSearchedItems, `${[itemType]}`, null);
    if (data) {
      const defaultData = JSON.parse(data);
      Object.keys(defaultData).map(key => {
        formProps.setFieldValue(key, defaultData[key]);
      });
    }
  };

  loadComponentData = () => {
    this.getFormControlData();
    this.getResultCountData();
    this.getProfiles();
  };

  profileActionHandle = data => {
    // eslint-disable-next-line no-console
    console.log('Profile Clicked', data);
  };

  profileActionHandle = data => {
    // eslint-disable-next-line no-console
    console.log('Profile Clicked', data);
  };

  shouldComponentUpdate(nextProp) {
    const { commandId } = this.props;
    if (commandId !== nextProp.commandId) {
      this.getProfiles(nextProp.commandId);
    }

    if (this.props.getUsage !== nextProp.getUsage) {
      this.getResultCountData(nextProp.getUsage);
    }
    return true;
  }

  render() {
    const initialValues = this.setInitialValues();
    const input = _.get(this.props, 'findControls.data', []);

    const yepSchema = input.reduce(createYupSchema, {});
    const validateSchema = yup.object().shape(yepSchema);

    if (
      _.get(this.props, 'findControls.isLoading', false) &&
      !_.get(this.props, 'findControls.isError', false)
    ) {
      return (
        <div
          style={{
            flex: 1,
            justifyContent: 'center',
            alignContent: 'center',
            minHeight: window.innerHeight,
          }}
        >
          <LoadingIndicator />
        </div>
      );
    }
    if (_.get(this.props, 'findControls.isError', false)) {
      return (
        <div
          style={{
            minHeight: window.innerHeight,
            padding: 30,
          }}
        >
          <PrimaryButton
            style={{
              background: 'white',
              color: '#0078D4',
            }}
            text="Retry"
            allowDisabledFocus
            onClick={() => this.loadComponentData()}
          />
        </div>
      );
    }

    return (
      <>
        <div className="ms-Grid leftMenu-block" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12 form">
              {/* form action icons */}

              <Formik
                initialValues={initialValues}
                validationSchema={validateSchema}
                onSubmit={(values, actions) => {
                  // eslint-disable-next-line no-console
                  console.log('Values---->', JSON.stringify(values), '\n actions--->', actions);

                  // Pass the data back to ProviderResultContainer
                  const formData = _.get(this.props, 'formData', null);
                  if (formData) {
                    formData(values, this.props.getProfileId);
                  }

                  const handleSubmit = _.get(this.props, 'handleSubmit', null);
                  if (handleSubmit) {
                    handleSubmit(values);
                  }

                  actions.setSubmitting(false); // TODO: need to set false inside submit API
                }}
              >
                {props => (
                  <>
                    <div className="ms-Grid-row">
                      <div className="ms-Grid-col ms-sm6 ms-md8 ms-lg8 ">
                        <button
                          type="button"
                          onClick={() => {
                            const collapseHandle = _.get(this.props, 'collapseHandle', null);
                            if (collapseHandle) {
                              collapseHandle('closeSlider');
                            }
                          }}
                          style={{
                            fontSize: 24,
                            background: 'transparent',
                            border: 'unset',
                            cursor: 'pointer',
                          }}
                        >
                          &#171;
                        </button>
                        <span> &nbsp; &nbsp; PARAMETERS</span>
                      </div>
                      <div
                        className="ms-Grid-col ms-sm6 ms-md4 ms-lg4 "
                        style={{ top: 5, textAlign: 'right' }}
                      >
                        <div className="ms-Grid-row">
                          <div
                            className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 "
                            style={{ fontSize: 20, cursor: 'pointer' }}
                          >
                            <ProfileAction
                              profileActionHandle={this.profileActionHandle}
                              profiles={[
                                ..._.get(this.props, 'findProfiles.data.findProfile', []),
                                ..._.get(this.props, 'findProfiles.data.findProfile2', []),
                              ]}
                            />
                          </div>
                          <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 ">
                            <span
                              style={{
                                fontSize: 20,
                                textAlign: 'right',
                                cursor: 'pointer',
                              }}
                            >
                              <img
                                src={lastSearch}
                                alt="lastSearch"
                                onClick={() => this.getLastSearchedItems(props)}
                              />
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <hr />
                    <div
                      style={{
                        overflowY: 'scroll',
                        overflowX: 'hidden',
                        top: 0,
                        bottom: 0,
                        height: window.innerHeight,
                        paddingLeft: 16,
                        paddingRight: 16,
                        paddingBottom: 16,
                        marginTop: -16,
                      }}
                    >
                      <form onSubmit={props.handleSubmit}>
                        <LoadingOverlay
                          active={this.props.dropdownStatus.isLoading}
                          spinner={<LoadingIndicator />}
                        >
                          {this.renderFormElements(props)}
                        </LoadingOverlay>

                        <div style={{ paddingTop: 16, textAlign: 'right' }}>
                          <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 ">
                              <PrimaryButton
                                style={{ background: 'white', color: '#0078D4' }}
                                text="Clear"
                                allowDisabledFocus
                                onClick={() => props.resetForm(initialValues)}
                                disabled={props.isSubmitting}
                              />
                            </div>
                            <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg6 ">
                              <PrimaryButton
                                text="Find"
                                allowDisabledFocus
                                type="submit"
                                block
                                disabled={props.isSubmitting}
                              />
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </>
    );
  }
}

__DynamicForm.propTypes = {
  getUserOptions: PropTypes.func,
  getFindProfiles: PropTypes.func,
  getFindControl: PropTypes.func,
  getLinkedDropDownValues: PropTypes.func,
  getReferenceCodes: PropTypes.func,
  sessionId: PropTypes.string,
  commandType: PropTypes.any,
  allDropDownValues: PropTypes.any,
  dropdownStatus: PropTypes.any,
  referenceCode: PropTypes.any,
  lastSearchedItems: PropTypes.any,
  commandId: PropTypes.string,
  getUsage: PropTypes.string,
  getProfileId: PropTypes.string,
  clearTableData: PropTypes.func,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  findControls: getControl(state),
  allDropDownValues: getAllDropDownValues(state),
  dropdownStatus: getDropDownStatus(state),
  referenceCode: getReferenceCode(state),
  findProfiles: getFindProfilesData(state),
  getProfileId: getProfileId(state),
  lastSearchedItems: getSearchedItems(state),
  commandId: getCommandId(state),
  getUserId: getUserId(state),
  getUsage: getUsage(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    getUserOptions: requestParams => dispatch(getUserOptionsRequest(requestParams)),
    getFindProfiles: requestParams => dispatch(getFindProfilesRequest(requestParams)),
    getFindControl: requestParams => dispatch(getFindControlRequest(requestParams)),
    getLinkedDropDownValues: (requestParams, key) =>
      dispatch(getLinkedDropDownValuesRequest(requestParams, key)),
    getReferenceCodes: (requestParams, key) => dispatch(getReferenceCodesRequest(requestParams, key)),
    clearTableData: () => dispatch(clearTableData()),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export const DynamicForm = compose(withConnect)(__DynamicForm);
