/**
 * Gets the repositories of the user from Github
 */
import _ from 'lodash';
import { call, put, takeLatest, all } from 'redux-saga/effects';

import request from 'utils/request';
import { getParamValueFromSQL } from '../../utils/utils';

import * as actions from './actions';

// GetFindProfiles API

function* getFindProfilesRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetFindProfiles';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getFindProfilesSuccess(result));
    } else {
      yield put(actions.getFindProfilesFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getFindProfilesFailure(error));
  }
}

// GetFindControl API

function* findControlsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetFindControls';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getFindControlSuccess(result));
    } else {
      yield put(actions.getFindControlFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getFindControlFailure(error));
  }
}

// GetDropDownValues API

function* getDropDownValuesRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetLinkedDropDownValue';

  const spQuery = _.get(action, 'input.spQuery', '');

  let type = '';
  if (action.key === '') {
    type = getParamValueFromSQL(spQuery, 'Type');
  } else {
    type = action.key;
  }

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getLinkedDropDownValuesSuccess(result, type));
    } else {
      yield put(actions.getLinkedDropDownValuesFailure(response.problem, type));
    }
  } catch (error) {
    yield put(actions.getLinkedDropDownValuesFailure(error, type));
  }
}

// ReferenceCodes API

function* getReferenceCodesRequest(action) {
  const { input } = action;

  const refType = _.get(action, 'input.Type', '');
  const requestURL = '/common/api/common/GetReferenceCodesV2';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getReferenceCodesSuccess(result, refType));
    } else {
      yield put(actions.getReferenceCodesFailure(response.problem, refType));
    }
  } catch (error) {
    yield put(actions.getReferenceCodesFailure(error, refType));
  }
}

// GetUserOptions API

export function* getUserOptionsRequestSaga(action) {
  const { input } = action;
  const key = _.get(action, 'input.itemType', '');
  const requestURL = '/common/api/common/GetUserOptions';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getUserOptionsSuccess(result, key));
    } else {
      yield put(actions.getUserOptionsFailure(response.problem, key));
    }
  } catch (error) {
    yield put(actions.getUserOptionsFailure(error, key));
  }
}

/**
 * Root saga manages watcher lifecycle
 */
export default function* githubData() {
  yield all([
    takeLatest('GET_FIND_PROFILES_REQUEST', getFindProfilesRequestSaga),
    takeLatest('GET_USER_OPTIONS_REQUEST', getUserOptionsRequestSaga),
    takeLatest('FIND_CONTROL_REQUEST', findControlsRequestSaga),
    takeLatest('DROPDOWN_VALUES_REQUEST', getDropDownValuesRequestSaga),
    takeLatest('REFERENCE_CODES_REQUEST', getReferenceCodesRequest),
  ]);
}
