/**
 * Dynamic Form selectors
 */
import _ from 'lodash';
import { getFormattedInput } from './responseFormatter';

const getSessionId = state => _.get(state, 'data.status.sessionId', null);

const getControl = state => ({
  data: getFormattedInput(_.get(state, 'findControl.data.findControls', [])),
  isLoading: _.get(state, 'findControl.isLoading', false),
  isError: _.get(state, 'findControl.isError', false),
});

export { getSessionId, getControl };
