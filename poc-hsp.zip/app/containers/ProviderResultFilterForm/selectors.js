/**
 * Dynamic Form selectors
 */
import _ from 'lodash';
import { getFormattedInput } from './responseFormatter';

const getControl = state => ({
  data: getFormattedInput(_.get(state, 'findControl.data.findControls', [])),
  isLoading: _.get(state, 'findControl.isLoading', false),
  isError: _.get(state, 'findControl.isError', false),
});

const getAllDropDownValues = state => state.getAllDropDownValues;
const getDropDownStatus = state => ({
  isLoading: _.get(state, 'getDropDownValues.isLoading', false),
  isError: _.get(state, 'getDropDownValues.isError', false),
  data: _.get(state, 'getDropDownValues.data', false),
});

const getReferenceCode = state => state.getAllReferenceCodes;
const getFindProfilesData = state => state.getFindProfiles;
const getProfileId = state => _.get(state, 'getFindProfiles.data.findProfile2[0].findProfileId', '0');
const getSearchedItems = state => state.allUserOptions;

const getReferenceCodeStatus = state => _.get(state, 'getReferenceCodes', null);

export {
  getControl,
  getAllDropDownValues,
  getDropDownStatus,
  getReferenceCode,
  getFindProfilesData,
  getSearchedItems,
  getProfileId,
  getReferenceCodeStatus,
};
