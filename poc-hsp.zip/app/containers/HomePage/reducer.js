/*
 * HomeReducer
 *
 * The reducer takes care of our data. Using actions, we can
 * update our application state. To add a new action,
 * add it to the switch statement in the reducer function
 *
 */

import _ from 'lodash';
import { arrayToObject } from '../../utils/utils';
// ConnectUser API

export default function connectUserReducer(state = null, action) {
  switch (action.type) {
    case 'CONNECT_USER_REQUEST':
      return { ...state, isLoading: true };
    case 'CONNECT_USER_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'CONNECT_USER_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export const getSessionId = state => _.get(state, 'data.status.sessionId', null);

// CheckPermission API

export function checkPermissionReducer(state = null, action) {
  switch (action.type) {
    case 'CHECK_PERMISSION_REQUEST':
      return { ...state, isLoading: true };
    case 'CHECK_PERMISSION_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'CHECK_PERMISSION_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export function getAllPermissionsReducer(state = [], action) {
  switch (action.type) {
    case 'CHECK_PERMISSION_SUCCESS': {
      const obj = [];
      obj[action.entityType] = _.get(action, 'data.checkPermission[0].permission', []);

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

// GetFindCommands API

export function getFindCommandsReducer(state = {}, action) {
  switch (action.type) {
    case 'FIND_COMMAND_REQUEST':
      return { ...state, isLoading: true };
    case 'FIND_COMMAND_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'FIND_COMMAND_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetFindProfiles API

export function getFindProfilesReducer(state = null, action) {
  switch (action.type) {
    case 'GET_FIND_PROFILES_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_FIND_PROFILES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_FIND_PROFILES_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetFindControl API

export function findControlReducer(state = null, action) {
  switch (action.type) {
    case 'FIND_CONTROL_REQUEST':
      return { ...state, isLoading: true };
    case 'FIND_CONTROL_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'FIND_CONTROL_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetDropDownValues API

export function getDropDownValuesReducer(state = null, action) {
  switch (action.type) {
    case 'DROPDOWN_VALUES_REQUEST':
      return { ...state, isLoading: true };
    case 'DROPDOWN_VALUES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'DROPDOWN_VALUES_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export function getAllDropDownValuesReducer(state = [], action) {
  switch (action.type) {
    case 'DROPDOWN_VALUES_SUCCESS': {
      const obj = [];
      obj[action.key] = arrayToObject(_.get(action, 'data.getCustomValues', []), 'name');

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

export const getDropDownValues = state => _.get(state, 'data.getCustomValues', null);

// GetReferenceCodes API

export function getReferenceCodesReducer(state = null, action) {
  switch (action.type) {
    case 'REFERENCE_CODES_REQUEST':
      return { ...state, isLoading: true };
    case 'REFERENCE_CODES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'REFERENCE_CODES_FAILURE':
      return { ...state, isLoading: false, isError: true, errorMessage: action.error };
    default:
      return state;
  }
}

export function getAllReferenceCodesReducer(state = [], action) {
  switch (action.type) {
    case 'REFERENCE_CODES_SUCCESS': {
      const obj = [];
      obj[action.refType] = arrayToObject(_.get(action, 'data.referenceCodes_V2DTOs', []), 'name');

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

// GetContracts API

export function getContractsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_CONTRACTS_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_CONTRACTS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_CONTRACTS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetOffices API

export function getOfficesReducer(state = null, action) {
  switch (action.type) {
    case 'OFFICES_REQUEST':
      return { ...state, isLoading: true };
    case 'OFFICES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'OFFICES_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export const getOffices = state => _.get(state, 'data.offices_V2s', null);

// GetListViewProfileSettings API

export function getListViewProfileSettingsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_LIST_VIEW_PROFILE_SETTINGS_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_LIST_VIEW_PROFILE_SETTINGS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_LIST_VIEW_PROFILE_SETTINGS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetUserListViewSettings API

export function getUserListViewSettingsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_USER_LIST_VIEW_SETTINGS_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_USER_LIST_VIEW_SETTINGS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_USER_LIST_VIEW_SETTINGS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetUserReports API

export function getUserReportsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_USER_REPORT_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_USER_REPORT_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_USER_REPORT_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetXMLStyleSheet API

export function getXMLStyleSheetReducer(state = null, action) {
  switch (action.type) {
    case 'GET_XML_STYLESHEET_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_XML_STYLESHEET_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_XML_STYLESHEET_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetUserOptions API

export function getUserOptionsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_USER_OPTIONS_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_USER_OPTIONS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_USER_OPTIONS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export function allUserOptionsReducer(state = [], action) {
  switch (action.type) {
    case 'GET_USER_OPTIONS_SUCCESS': {
      const obj = [];
      obj[action.key] = _.get(action, 'data.itemValue', []);

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

// SetUserOptions API

export function setUserOptionsReducer(state = null, action) {
  switch (action.type) {
    case 'SET_USER_OPTIONS_REQUEST':
      return { ...state, isLoading: true };
    case 'SET_USER_OPTIONS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'SET_USER_OPTIONS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// DisconnectUser API

export function disconnectUserReducer(state = null, action) {
  switch (action.type) {
    case 'DISCONNECT_USER_REQUEST':
      return { ...state, isLoading: true };
    case 'DISCONNECT_USER_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'DISCONNECT_USER_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetBenefitStructures API

export function getBenefitStructuresReducer(state = null, action) {
  switch (action.type) {
    case 'BENEFIT_STRUCTURE_REQUEST':
      return { ...state, isLoading: true };
    case 'BENEFIT_STRUCTURE_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'BENEFIT_STRUCTURE_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export const getBenefitStructures = state => {
  return _.get(state, 'data.benefitStructuresDTO', null);
};
