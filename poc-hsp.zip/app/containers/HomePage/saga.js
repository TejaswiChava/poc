/**
 * Gets the repositories of the user from Github
 */
import _ from 'lodash';
import { call, put, takeLatest, all } from 'redux-saga/effects';

import request from 'utils/request';
import { getParamValueFromSQL } from '../../utils/utils';

import * as actions from './actions';

// ConnectUser API

function* connectUserRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/Common/ConnectUser';

  try {
    const response = yield call(request, requestURL, input);

    const result = response.data;
    if (response.ok) {
      yield put(actions.getConnectUserSuccess(result));
    } else {
      yield put(actions.getConnectUserFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getConnectUserFailure(error));
  }
}

// CheckPermission API

function* checkPermissionRequestSaga(action) {
  const { input } = action;

  const entityType = _.get(action, 'input.EntityType', '');
  const requestURL = '/common/api/common/CheckPermission';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.checkPermissionSuccess(result, entityType));
    } else {
      yield put(actions.checkPermissionFailure(response.problem, entityType));
    }
  } catch (error) {
    yield put(actions.checkPermissionFailure(error, entityType));
  }
}

// GetFindCommands API

function* getFindCommandsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetFindCommands';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getFindCommandsSuccess(result));
    } else {
      yield put(actions.getFindCommandsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getFindCommandsFailure(error));
  }
}

// GetFindProfiles API

function* getFindProfilesRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetFindProfiles';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getFindProfilesSuccess(result));
    } else {
      yield put(actions.getFindProfilesFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getFindProfilesFailure(error));
  }
}

// GetFindControl API

function* findControlsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetFindControls';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getFindControlSuccess(result));
    } else {
      yield put(actions.getFindControlFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getFindControlFailure(error));
  }
}

// GetDropDownValues API

function* getDropDownValuesRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetLinkedDropDownValue';

  const spQuery = _.get(action, 'input.spQuery', '');
  const type = getParamValueFromSQL(spQuery, 'Type');

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getLinkedDropDownValuesSuccess(result, type));
    } else {
      yield put(actions.getLinkedDropDownValuesFailure(response.problem, type));
    }
  } catch (error) {
    yield put(actions.getLinkedDropDownValuesFailure(error, type));
  }
}

// ReferenceCodes API

function* getReferenceCodesRequest(action) {
  const { input } = action;

  const refType = _.get(action, 'input.Type', '');
  const requestURL = '/common/api/common/GetReferenceCodesV2';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getReferenceCodesSuccess(result, refType));
    } else {
      yield put(actions.getReferenceCodesFailure(response.problem, refType));
    }
  } catch (error) {
    yield put(actions.getReferenceCodesFailure(error, refType));
  }
}

// GetContracts API

function* getContractsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/provider/contracts/api/Provider/Contracts/GetContracts';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getContractsSuccess(result));
    } else {
      yield put(actions.getContractsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getContractsFailure(error));
  }
}

// GetOffices API

function* getOfficesRequestSaga(action) {
  const { input } = action;
  const requestURL = '/provider/providers/api/Provider/Providers/GetOffices_V2';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getOfficesSuccess(result));
    } else {
      yield put(actions.getOfficesFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getOfficesFailure(error));
  }
}

// GetListViewProfileSettingsSaga API

function* getListViewProfileSettingsSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetListviewProfileSettings';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getListViewProfileSettingsSuccess(result));
    } else {
      yield put(actions.getListViewProfileSettingsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getListViewProfileSettingsFailure(error));
  }
}

// GetUserListViewSettings API

function* getUserListViewSettingsSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetUserListviewSettings';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getUserListViewSettingsSuccess(result));
    } else {
      yield put(actions.getUserListViewSettingsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getUserListViewSettingsFailure(error));
  }
}

// GetUserReports API

function* getUserReportsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/GetUserReports';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getUserReportsSuccess(result));
    } else {
      yield put(actions.getUserReportsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getUserReportsFailure(error));
  }
}

// GetXMLStyleSheet API

function* getXMLStyleSheetSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/Common/GetXMLStyleSheet';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getXMLStyleSheetSuccess(result));
    } else {
      yield put(actions.getXMLStyleSheetFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getXMLStyleSheetFailure(error));
  }
}

// GetUserOptions API

export function* getUserOptionsRequestSaga(action) {
  const { input } = action;
  const key = _.get(action, 'input.itemType', '');
  const requestURL = '/common/api/common/GetUserOptions';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getUserOptionsSuccess(result, key));
    } else {
      yield put(actions.getUserOptionsFailure(response.problem, key));
    }
  } catch (error) {
    yield put(actions.getUserOptionsFailure(error, key));
  }
}

// SetUserOptions API

function* setUserOptionsRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/SetUserOptions';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.setUserOptionsSuccess(result));
    } else {
      yield put(actions.setUserOptionsFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.setUserOptionsFailure(error));
  }
}

// DisconnectUser API

function* disconnectUserRequestSaga(action) {
  const { input } = action;
  const requestURL = '/common/api/common/DisConnectUser';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getDisconnectUserSuccess(result));
    } else {
      yield put(actions.getDisconnectUserFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getDisconnectUserFailure(error));
  }
}

// GetBanefitStructures API

function* getBenefitStructuresRequestSaga(action) {
  const { input } = action;
  const requestURL = '/provider/contracts/api/Provider/Contracts/GetBenefitStructures';

  try {
    const response = yield call(request, requestURL, input);
    const result = response.data;
    if (response.ok) {
      yield put(actions.getBenefitStructuresSuccess(result));
    } else {
      yield put(actions.getBenefitStructuresFailure(response.problem));
    }
  } catch (error) {
    yield put(actions.getBenefitStructuresFailure(error));
  }
}

/**
 * Root saga manages watcher lifecycle
 */
export default function* githubData() {
  yield all([
    takeLatest('CONNECT_USER_REQUEST', connectUserRequestSaga),
    takeLatest('CHECK_PERMISSION_REQUEST', checkPermissionRequestSaga),
    takeLatest('FIND_COMMAND_REQUEST', getFindCommandsRequestSaga),
    takeLatest('GET_FIND_PROFILES_REQUEST', getFindProfilesRequestSaga),
    takeLatest('FIND_CONTROL_REQUEST', findControlsRequestSaga),
    takeLatest('DROPDOWN_VALUES_REQUEST', getDropDownValuesRequestSaga),
    takeLatest('REFERENCE_CODES_REQUEST', getReferenceCodesRequest),
    takeLatest('GET_CONTRACTS_REQUEST', getContractsRequestSaga),
    takeLatest('OFFICES_REQUEST', getOfficesRequestSaga),
    takeLatest('GET_LIST_VIEW_PROFILE_SETTINGS_REQUEST', getListViewProfileSettingsSaga),
    takeLatest('GET_USER_LIST_VIEW_SETTINGS_REQUEST', getUserListViewSettingsSaga),
    takeLatest('GET_USER_REPORT_REQUEST', getUserReportsRequestSaga),
    takeLatest('GET_XML_STYLESHEET_REQUEST', getXMLStyleSheetSaga),
    takeLatest('GET_USER_OPTIONS_REQUEST', getUserOptionsRequestSaga),
    takeLatest('SET_USER_OPTIONS_REQUEST', setUserOptionsRequestSaga),
    takeLatest('DISCONNECT_USER_REQUEST', disconnectUserRequestSaga),
    takeLatest('BENEFIT_STRUCTURE_REQUEST', getBenefitStructuresRequestSaga),
  ]);
}
