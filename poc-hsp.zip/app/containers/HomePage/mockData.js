export const mockConnectUserRequestData = {
  username: 'C5110547',
  password: 'admin@12345',
  appName: 'Meditrac',
  version: '10.07.0.HSP.0.0.173',
  computerName: '',
  licenseMode: 'db',
  numberOfLicensedSeats: '1',
};

export const mockGetFindCommandsRequestParam = {
  sessionId: '124',
  usage: '|ByFindCommand|',
  findCommand: 'Contract',
};

export const mockFindProfilesRequestData = {
  sessionId: '124',
  findCommandId: '85',
  usage: '|ForFindCommand|',
};

export const mockFindControlRequestData = {
  sessionId: '124',
  findCommand: 'Contract',
  findProfileId: '0',
  usage: '|ByFindCommand|',
};

export const mockGetDropDownValuesRequestParams = {
  spQuery: "exec ee_GetBenefitStructures @SessionID=124, @Usage='|USAGE2|', @Type='RBI'",
  staticColumnName: 'Name',
  dynamicColumnName: 'StructureID',
};

export const mockGetDropDownValuesRequestParams2 = {
  spQuery:
    "exec ee_GetReferenceCodes_V2 @SessionID=124, @AllowCheckout='N', @Type='REGION', @Usage='|USAGE2|'",
  staticColumnName: 'Name',
  dynamicColumnName: 'Code',
};

export const mockGetReferenceCodesRequestParams = {
  SessionId: '124',
  Type: 'RESULTCOUNT',
  SubType: 'RESULTCOUNT',
  Usage: '|USAGE2|',
  AllowCheckout: 'N',
};

export const mockGetReferenceCodesRequestParams2 = {
  SessionId: '124',
  Type: 'LANGUAGE',
  Usage: '|USAGE2|',
  AllowCheckout: 'N',
};

export const mockContractsRequestParam = {
  sessionID: '124',
  usage: '|USAGE2|',
  contractName: 'hsp',
};

export const mockOfficesRequestParam = {
  SessionId: '124',
  OfficeName: 'c',
  Usage: '|SEARCH|',
};

export const mockOfficesErrorRequestParam = {
  SessionId: '124',
  Usage: '|SEARCH|',
};

export const mockgetListViewProfileSettingsRequestData = {
  sessionId: '124',
  listviewName: 'Contract',
  listviewProfileId: '0',
  usage: '|ForListview|',
};

export const mockgetListViewProfileSettingsRequestData2 = {
  sessionId: '124',
  listviewName: 'Office',
  listviewProfileId: '0',
  usage: '|ForListview|',
};

export const mockgetUserListViewSettingsRequestData = {
  sessionId: '124',
  formName: 'FindForm',
  listView: 'lvwResult',
  storedProcedure: 'ee_GetOffices_v2',
};

export const mockGetUserReportsRequestParam = {
  sessionID: '124',
  usage: '|BYCATEGORYCODE|',
  categoryCode: 'OP',
};

export const mockGetXMLStyleSheetRequestData = {
  SPName: 'ee_getcontractprofile_xml',
  XSLTPath: 'ContractProfile.xsl',
  sessionId: '124',
  contractid: '23',
};

export const mockGetUserOptionsRequestParam = {
  userID: '267',
  itemType: 'ContractHistory',
};

export const mockGetUserOptionsRequestParam2 = {
  userID: '267',
  itemType: 'ContractSearch',
};

export const mockGetUserOptionsRequestParam3 = {
  userID: '267',
  itemType: 'OfficeSearch',
};

export const mockSetUserOptionsRequestParam = {
  userID: '267',
  itemType: 'ContractHistory',
  itemValue: '[{"EntityId":"29", "EntityName":"HSP Extended Contract"}]',
  addedTime: '2020-04-09T11:47:30.085Z',
};

export const mockGetDisconnectUser = {
  sessionID: '4283',
};

export const mockCheckPermission = {
  SessionId: 124,
  EntityType: 'Contracts',
  Usage: 'USAGE1',
  PermissionName: 'View Template',
  ProductName: 'Meditrac',
};

export const mockCheckPermission2 = {
  SessionId: 124,
  EntityType: 'Offices',
  Usage: 'USAGE1',
  PermissionName: 'View Template',
  ProductName: 'Meditrac',
};

export const mockGetBenefitStructuresData = {
  sessionID: '124',
  type: 'RBI',
  usage: '|Usage2|',
};
