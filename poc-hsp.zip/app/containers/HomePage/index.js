/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 */

import React, { useEffect, memo } from 'react';

import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';

import { connect } from 'react-redux';
import { compose } from 'redux';
import { createStructuredSelector } from 'reselect';

import CenteredSection from './CenteredSection';
import Section from './Section';

import {
  getConnectUserRequest,
  getFindCommandsRequest,
  getFindProfilesRequest,
  getFindControlRequest,
  getLinkedDropDownValuesRequest,
  getReferenceCodesRequest,
  getContractsRequest,
  getOfficesRequest,
  getListViewProfileSettingsRequest,
  getUserListViewSettingsRequest,
  getUserReportsRequest,
  getXMLStyleSheetRequest,
  getUserOptionsRequest,
  setUserOptionsRequest,
  getDisconnectUserRequest,
  checkPermissionRequest,
  getBenefitStructuresRequest,
} from './actions';

import {
  mockConnectUserRequestData,
  mockGetFindCommandsRequestParam,
  mockFindProfilesRequestData,
  mockFindControlRequestData,
  mockGetDropDownValuesRequestParams,
  mockGetDropDownValuesRequestParams2,
  mockGetReferenceCodesRequestParams,
  mockGetReferenceCodesRequestParams2,
  mockContractsRequestParam,
  mockOfficesRequestParam,
  mockOfficesErrorRequestParam,
  mockgetListViewProfileSettingsRequestData,
  mockgetUserListViewSettingsRequestData,
  mockGetUserReportsRequestParam,
  mockGetXMLStyleSheetRequestData,
  mockGetUserOptionsRequestParam,
  mockGetUserOptionsRequestParam2,
  mockGetUserOptionsRequestParam3,
  mockSetUserOptionsRequestParam,
  mockGetDisconnectUser,
  mockCheckPermission,
  mockCheckPermission2,
  mockGetBenefitStructuresData,
  mockgetListViewProfileSettingsRequestData2,
} from './mockData';

export function HomePage({
  getConnectUser,
  getFindCommands,
  getFindProfiles,
  getFindControl,
  getLinkedDropDownValues,
  getReferenceCodes,
  getContracts,
  getOffices,
  getListViewProfileSettings,
  getUserListViewSettings,
  getUserReports,
  getXMLStyleSheet,
  getUserOptions,
  setUserOptions,
  getDisconnectUser,
  checkPermission,
  getBenefitStructures,
}) {
  // useInjectReducer({ key, reducer });
  // useInjectSaga({ key, saga });

  useEffect(() => {
    // getConnectUser(mockConnectUserRequestData);
    // getFindCommands(mockGetFindCommandsRequestParam);
    // getFindProfiles(mockFindProfilesRequestData);
    // getFindControl(mockFindControlRequestData);
    // getLinkedDropDownValues(mockGetDropDownValuesRequestParams);
    // setTimeout(() => {
    //   getLinkedDropDownValues(mockGetDropDownValuesRequestParams2);
    // }, 4000);
    // getReferenceCodes(mockGetReferenceCodesRequestParams);
    // setTimeout(() => {
    //   getReferenceCodes(mockGetReferenceCodesRequestParams2);
    // }, 4000);
    // getContracts(mockContractsRequestParam);
    // getOffices(mockOfficesRequestParam);
    // setTimeout(() => {
    //   getOffices(mockOfficesErrorRequestParam);
    // }, 4000);
    // getListViewProfileSettings(mockgetListViewProfileSettingsRequestData);
    // setTimeout(() => {
    //   getListViewProfileSettings(mockgetListViewProfileSettingsRequestData2);
    // }, 4000);
    // getUserListViewSettings(mockgetUserListViewSettingsRequestData);
    // getUserReports(mockGetUserReportsRequestParam);
    // getXMLStyleSheet(mockGetXMLStyleSheetRequestData);
    // getUserOptions(mockGetUserOptionsRequestParam);
    // setTimeout(() => {
    //   getUserOptions(mockGetUserOptionsRequestParam2);
    // }, 4000);
    // setTimeout(() => {
    //   getUserOptions(mockGetUserOptionsRequestParam3);
    // }, 6000);
    // setUserOptions(mockSetUserOptionsRequestParam);
    // getDisconnectUser(mockGetDisconnectUser);
    // checkPermission(mockCheckPermission);
    // setTimeout(() => {
    //   checkPermission(mockCheckPermission2);
    // }, 4000);
    // getBenefitStructures(mockGetBenefitStructuresData);
  }, []);

  return (
    <article>
      <Helmet>
        <title>Home Page</title>
        <meta name="description" content="Conduent HSP" />
      </Helmet>
      <div>
        <CenteredSection>
          <h2>Home</h2>
        </CenteredSection>
        <Section />
      </div>
    </article>
  );
}

HomePage.propTypes = {
  getConnectUser: PropTypes.func,
  getFindCommands: PropTypes.func,
  getFindProfiles: PropTypes.func,
  getFindControl: PropTypes.func,
  getLinkedDropDownValues: PropTypes.func,
  getReferenceCodes: PropTypes.func,
  getContracts: PropTypes.func,
  getOffices: PropTypes.func,
  getListViewProfileSettings: PropTypes.func,
  getUserListViewSettings: PropTypes.func,
  getUserReports: PropTypes.func,
  getXMLStyleSheet: PropTypes.func,
  getUserOptions: PropTypes.func,
  setUserOptions: PropTypes.func,
  getDisconnectUser: PropTypes.func,
  checkPermission: PropTypes.func,
  getBenefitStructures: PropTypes.func,
};

const mapStateToProps = createStructuredSelector({});

export function mapDispatchToProps(dispatch) {
  return {
    getConnectUser: requestParams => dispatch(getConnectUserRequest(requestParams)),
    getFindCommands: requestParams => dispatch(getFindCommandsRequest(requestParams)),
    getFindProfiles: requestParams => dispatch(getFindProfilesRequest(requestParams)),
    getFindControl: requestParams => dispatch(getFindControlRequest(requestParams)),
    getLinkedDropDownValues: requestParams => dispatch(getLinkedDropDownValuesRequest(requestParams)),
    getReferenceCodes: requestParams => dispatch(getReferenceCodesRequest(requestParams)),
    getContracts: requestParams => dispatch(getContractsRequest(requestParams)),
    getOffices: requestParams => dispatch(getOfficesRequest(requestParams)),
    getListViewProfileSettings: requestParams => dispatch(getListViewProfileSettingsRequest(requestParams)),
    getUserListViewSettings: requestParams => dispatch(getUserListViewSettingsRequest(requestParams)),
    getUserReports: requestParams => dispatch(getUserReportsRequest(requestParams)),
    getXMLStyleSheet: requestParams => dispatch(getXMLStyleSheetRequest(requestParams)),
    getUserOptions: requestParams => dispatch(getUserOptionsRequest(requestParams)),
    setUserOptions: requestParams => dispatch(setUserOptionsRequest(requestParams)),
    getDisconnectUser: requestParams => dispatch(getDisconnectUserRequest(requestParams)),
    checkPermission: requestParams => dispatch(checkPermissionRequest(requestParams)),
    getBenefitStructures: requestParams => dispatch(getBenefitStructuresRequest(requestParams)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(HomePage);
