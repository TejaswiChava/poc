import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';
import { DatePicker } from 'office-ui-fabric-react/lib/DatePicker';
import { Field } from 'formik';

import ErrorMessage from '../ErrorMessage/index';

export default class CustomDatePicker extends PureComponent {
  propTypes = {
    error: PropTypes.any,
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    value: PropTypes.any.isRequired,
    onChange: PropTypes.func,
    isRequired: PropTypes.string.isRequired,
    title: PropTypes.string,
  };

  onFormatDate = date => `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;

  render() {
    const renderError = _.get(this.props, 'error', null) ? (
      <ErrorMessage isVisible={this.props.error} message={this.props.error} />
    ) : null;
    return (
      <div style={{ paddingTop: 8 }}>
        <Field name={this.props.name} key={`Field_${this.props.name}`} title={this.props.title}>
          {props => {
            const { field } = props;
            return (
              <DatePicker
                {...field}
                label={this.props.label}
                placeholder="MM/DD/YYYY"
                ariaLabel="Select a date"
                value={this.props.value}
                onSelectDate={value => props.form.setFieldValue(this.props.name, value)}
                isRequired={this.props.isRequired}
                formatDate={this.onFormatDate}
              />
            );
          }}
        </Field>
        {renderError}
      </div>
    );
  }
}
