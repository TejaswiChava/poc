export default function clickRowItem(clickedRowItem) {
    return { type: 'CLICK_ROW_ITEM', clickedRowItem };
  }
  