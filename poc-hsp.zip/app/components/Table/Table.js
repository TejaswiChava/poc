/* eslint-disable no-shadow */
/* eslint-disable no-param-reassign */
import * as React from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Fabric } from 'office-ui-fabric-react/lib/Fabric';
import { HoverCard, HoverCardType } from 'office-ui-fabric-react/lib/HoverCard';
import { TestImages } from '@uifabric/example-data';
import { Image, ImageFit } from 'office-ui-fabric-react/lib/Image';
import {
  DetailsList,
  DetailsListLayoutMode,
  Selection,
  SelectionMode,
  DetailsRow,
} from 'office-ui-fabric-react/lib/DetailsList';
import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { getTheme, mergeStyleSets } from 'office-ui-fabric-react/lib/Styling';
import { Pagination } from '@uifabric/experiments/lib/Pagination';
import { ComboBox, mergeStyles } from 'office-ui-fabric-react/lib/index';
import { Card, ListGroup } from 'react-bootstrap';
import history from 'utils/history';
import data from './data.json';
// import listViewProfileSetting from './listViewProfileSetting.json';
import contentJson from '../ContentView/HTMLContent.json';

import ListTitle from '../ListTitle/ListTitle';
import eyeImage from '../../images/eye-icon.svg';
import printImage from '../../images/printer.svg';
import restoreImage from '../../images/restore.svg';
import styleImage from '../../images/stylesheet.png';
import downImage from '../../images/down_arrow.svg';
import upImage from '../../images/up_arrow.svg';
import './Table.scss';
import { getUserReports, getXMLStyleSheet } from './selectors';
import { getUserReportsRequest, getXMLStyleSheetRequest } from '../../containers/HomePage/actions';
import { getSessionId } from '../Header/selectors';
import {
  getContracts,
  getOffices,
  getListViewProfileSettings,
  commandType,
} from '../../containers/ProviderResultContainer/selectors';
import { checkIsAllow } from '../Header/action';
import clickRowItem from './action';
// initializeIcons();
const theme = getTheme();
const dragEnterClass = mergeStyles({
  backgroundColor: theme.palette.neutralLight,
});

const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: '16px',
  },
  fileIconCell: {
    textAlign: 'center',
    selectors: {
      '&:before': {
        content: '.',
        display: 'inline-block',
        verticalAlign: 'middle',
        height: '100%',
        width: '0px',
        visibility: 'hidden',
      },
    },
  },
  fileIconImg: {
    verticalAlign: 'middle',
    maxHeight: '16px',
    maxWidth: '16px',
  },
  controlWrapper: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  exampleToggle: {
    display: 'inline-block',
    marginBottom: '10px',
    marginRight: '30px',
  },
  selectionDetails: {
    marginBottom: '20px',
  },
  compactCard: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
  },
  expandedCard: {
    padding: '16px 24px',
  },
  item: {
    selectors: {
      '&:hover': {
        textDecoration: 'underline',
        cursor: 'pointer',
      },
    },
  },
});
const wrapperClassName = mergeStyles({
  selectors: {
    '& > *': { marginBottom: '20px' },
    '& .ms-ComboBox': { maxWidth: '300px' },
  },
  float: 'left',
  boxSizing: 'border-box',
  padding: '10px',
  width: '50%',
});

class Table extends React.Component {
  constructor(props) {
    super(props);
    this.selector = React.createRef();
    this.onPageChange = index => {
      this.setState(
        {
          selectedPageIndex: index,
        },
        () => {},
      );
    };

    this.handleOnClick = () => {
      const sessionId = _.get(this.props, 'sessionId', '');

      const getXMLStyleSheetRequestData = {
        SPName: this.props.getUserReports[0].storedProcedureName,
        XSLTPath: this.props.getUserReports[0].reportPath,
        sessionId,
        contractid: this.state.hoveredRowItem.contractId,
      };

      const getXMLStyleSheetRequestOfficeData = {
        SPName: this.props.getUserReports[0].storedProcedureName,
        XSLTPath: this.props.getUserReports[0].reportPath,
        sessionId,
        officeid: this.state.hoveredRowItem.officeID,
      };

      const getXMLStyleSheet = _.get(this.props, 'getXMLStyleSheetRequest', null);
      if (getXMLStyleSheet) {
        getXMLStyleSheet(
          this.state.hoveredRowItem.officeID
            ? getXMLStyleSheetRequestOfficeData
            : getXMLStyleSheetRequestData,
        );
      }

      setTimeout(() => {
        if (this.props.getXMLStyleSheet) {
          if (history) {
            history.push('/ContentView', { post: this.props.getXMLStyleSheet });
          }
        }
      }, 800);
    };

    this.handleRowItemClick = (path, itemDetail) => {
      if (history) {
        history.push(path, { post: itemDetail });
      }
    };
    this._onRenderItemColumn = item => {
      const plainCardProps = {
        onRenderPlainCard: this._onRenderPlainCard,
        renderData: item,
      };
      return (
        <HoverCard
          plainCardProps={plainCardProps}
          instantOpenOnClick
          type={HoverCardType.plain}
          onClick={() => this.handleOnClick('/contentViewComponent')}
        >
          <div className={classNames.item}>{item.name}</div>
        </HoverCard>
      );
      // return item[column!.key as keyof IDocument];
    };
    this._onRenderPlainCard = () => {
      const src = TestImages.iconPpt;
      return <Image src={src} width={100} height={100} imageFit={ImageFit.cover} />;
    };

    this._handleColumnReorder = (draggedIndex, targetIndex) => {
      const columns = _.get(this.state, 'columns', []);
      const draggedItems = columns[draggedIndex];
      const newColumns = [...columns];
      // insert before the dropped item
      newColumns.splice(draggedIndex, 1);
      newColumns.splice(targetIndex, 0, draggedItems);
      this.setState({ columns: newColumns });
    };
    this._onColumnClick = (ev, column) => {
      const { columns, items } = this.state;
      const newColumns = columns.slice();
      const currColumn = newColumns.filter(currCol => column.key === currCol.key)[0];
      newColumns.forEach(newCol => {
        if (newCol === currColumn) {
          currColumn.isSortedDescending = !currColumn.isSortedDescending;
          currColumn.isSorted = true;
          this.setState({
            announcedMessage: `${currColumn.name} is sorted ${
              currColumn.isSortedDescending ? 'descending' : 'ascending'
            }`,
          });
        } else {
          newCol.isSorted = false;
          newCol.isSortedDescending = true;
        }
      });
      const newItems = _copyAndSort(items, currColumn.fieldName, currColumn.isSortedDescending);
      this.setState({
        columns: newColumns,
        items: newItems,
      });
    };

    this._dragDropEvents = this._getDragDropEvents();
    this._draggedIndex = -1;

    this._allItems = _generateDocuments();
    this._selection = new Selection({
      onSelectionChanged: () => {
        this.setState({
          selectionDetails: this._getSelectionDetails(),
        });
      },
    });
    this.state = {
      items: [],
      columns: [],
      selectionDetails: this._getSelectionDetails(),
      isModalSelection: false,
      isCompactMode: false,
      announcedMessage: undefined,
      isColumnReorderEnabled: true,
      frozenColumnCountFromStart: '0',
      frozenColumnCountFromEnd: '0',
      selectedPageIndex: 0,
      limitPerPage: 10,
      initialOptions: this.loadInitialOptions(this.props.listViewData),
      someCondition: false,
      someCondition2: false,
      clicked: false,
      rectVal: 0,
      hoveredRowItem: '',
      commandTypeUpdated: false,
      title: {},
      defaultSelectedKey: 10,
      selectedKey: 10,
    };
    this._renderRow = this._renderRow.bind(this);
  }

  _onChange = (event, option) => {
    this.setState({ defaultSelectedKey: 10 });
    if (option) {
      this.setState({ limitPerPage: option.key, selectedPageIndex: 0, selectedKey: option.key });
    }
  };

  loadInitialOptions(listData) {
    const tableData = listData;
    const dataLength = tableData.length;
    const INITIAL_OPTIONS = [];
    const balance = dataLength % 10;
    for (let i = 1; i <= dataLength / 10; i++) {
      const pagination = {
        key: i * 10,
        text: `Showing ${i * 10} of ${dataLength}`,
      };
      INITIAL_OPTIONS.push(pagination);
    }
    if (balance !== 0) {
      const pagination = {
        key: dataLength,
        text: `Showing ${dataLength} of ${dataLength}`,
      };
      INITIAL_OPTIONS.push(pagination);
    }
    this.setState({ initialOptions: INITIAL_OPTIONS, selectedKey: 10 });
    return INITIAL_OPTIONS;
  }

  loadListViewData() {
    const dataWithKey = [];
    if (this.props.listViewData && this.props.listViewData.length > 0) {
      this.props.listViewData.map((option, index) => {
        const key = index + 1;
        option.key = key.toString();
        option.name = option.contractName;
        dataWithKey.push(option);
        return dataWithKey;
      });
    }
    const title = {
      name: `Available ${this.props.commandType}s`,
    };
    this.setState({ items: dataWithKey, title });
  }

  render() {
    const { columns, isCompactMode, items, selectedPageIndex, limitPerPage, rectVal } = this.state;
    return (
      <div className="tabs-container">
        <div className="ms-Grid-row">
          <div className="tab-header">
            <ListTitle title={this.state.title} />
            <div className="float-right" style={{ marginRight: 5 }}>
              <img src={restoreImage} alt="reset contracts" />
              <img src={printImage} alt="print contracts" />
            </div>
          </div>
        </div>
        {this.state.someCondition ? (
          <Card>
            <button
              type="button"
              style={{ top: `${rectVal + 6}px`, position: 'absolute', right: 60, border: 'none' }}
              className="imageClass"
              onMouseEnter={() => {
                this.setState({
                  someCondition: true,
                });
              }}
              onClick={() => {
                if (!this.state.clicked) {
                  this.setState({
                    someCondition2: true,
                  });

                  this.setState({
                    clicked: true,
                  });
                } else {
                  this.setState({
                    someCondition2: false,
                  });
                  this.setState({
                    clicked: false,
                  });
                }
              }}
            >
              <img src={eyeImage} alt="Contracts Detail" width={30} height={30} imageFit={ImageFit.cover} />
              {!this.state.someCondition2 ? (
                <img
                  src={downImage}
                  style={{ position: 'absolute', left: 30, border: 'none', outline: 'none' }}
                  alt="Contracts Detail"
                  width={30}
                  height={30}
                  imageFit={ImageFit.cover}
                />
              ) : (
                <img
                  src={upImage}
                  style={{ position: 'absolute', left: 30, border: 'none', outline: 'none' }}
                  alt="Contracts Detail"
                  width={30}
                  height={30}
                  imageFit={ImageFit.cover}
                />
              )}
            </button>
            <p
              className="imageClass"
              style={
                this.state.someCondition2
                  ? { display: 'block', top: `${rectVal + 50}px`, position: 'absolute', right: 40 }
                  : { display: 'none' }
              }
            >
              <Card style={{ width: '18rem' }}>
                <ListGroup variant="flush">
                  <ListGroup.Item>Open in New Window</ListGroup.Item>
                  <ListGroup.Item>Open in New Tab</ListGroup.Item>
                </ListGroup>
              </Card>
            </p>
            <button
              type="button"
              style={{ top: `${rectVal + 9}px`, position: 'absolute', right: 10 }}
              className="imageClass"
              onMouseEnter={() => {
                this.setState({
                  someCondition: true,
                });
              }}
              onClick={() => this.handleOnClick()}
            >
              <img src={styleImage} alt="style contracts" width={25} height={25} imageFit={ImageFit.cover} />
            </button>
          </Card>
        ) : null}

        <Fabric>
          <MarqueeSelection selection={this._selection}>
            <DetailsList
              setKey="hoverSet"
              items={items.slice(
                selectedPageIndex * limitPerPage,
                selectedPageIndex * limitPerPage + limitPerPage,
              )}
              compact={isCompactMode}
              columns={columns}
              selectionMode={SelectionMode.none}
              getKey={this._getKey}
              layoutMode={DetailsListLayoutMode.justified}
              isHeaderVisible
              selectionPreservedOnEmptyClick
              enterModalSelectionOnTouch
              ariaLabelForSelectionColumn="Toggle selection"
              ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              checkButtonAriaLabel="Row checkbox"
              dragDropEvents={this._dragDropEvents}
              columnReorderOptions={
                this.state.isColumnReorderEnabled ? this._getColumnReorderOptions() : undefined
              }
              onRenderRow={this._renderRow}
            />
          </MarqueeSelection>
          <div>
            <div style={{ float: 'left' }} className="pagination-styles">
              <Pagination
                selectedPageIndex={this.state.selectedPageIndex}
                pageCount={Math.ceil(this.state.items.length / this.state.limitPerPage)}
                onPageChange={this.onPageChange}
                format="buttons"
                comboBoxAriaLabel={`${Math.ceil(
                  this.state.items.length / this.state.limitPerPage,
                )} pages available`}
                // previousPageAriaLabel="previous page"
                // nextPageAriaLabel="next page"
                // firstPageAriaLabel="first page"
                // lastPageAriaLabel="last page"
                pageAriaLabel="page"
                // firstPageIconProps={{ iconName: 'DoubleChevronLeft' }}
                // previousPageIconProps={{ iconName: 'ChevronLeft' }}
                // nextPageIconProps={{ iconName: 'ChevronRight' }}
                // lastPageIconProps={{ iconName: 'DoubleChevronRight' }}
              />
            </div>

            <div style={{ float: 'right' }}>
              <div className="results">Possible results: {this.state.items.length}</div>

              <div className={wrapperClassName}>
                <ComboBox
                  defaultSelectedKey={this.state.defaultSelectedKey}
                  options={this.state.initialOptions}
                  onChange={this._onChange}
                  selectedKey={this.state.selectedKey}
                />
              </div>
            </div>
          </div>
        </Fabric>
      </div>
    );
  }

  _renderRow(props) {
    return (
      <div ref={this.selector} id={props.item.key}>
        <DetailsRow
          {...props}
          onClick={() => {
            props.item.isAllow = true;
            this.props.clickRowItem(props.item);
            this.props.checkIsAllow(true);
            this.handleRowItemClick('/leftNavDetails', props.item);
          }}
          onMouseEnter={e => {
            this.setState({
              someCondition: true,
              someCondition2: false,
              hoveredRowItem: props.item,
              clicked: false,
            });

            this.setState({
              rectVal: e.target.offsetParent.offsetTop,
            });
          }}
          onMouseLeave={() => {
            this.setState({
              someCondition: false,
              someCondition2: false,
            });
          }}
        />
      </div>
    );
  }

  _getColumnReorderOptions() {
    return {
      frozenColumnCountFromStart: parseInt(this.state.frozenColumnCountFromStart, 10),
      frozenColumnCountFromEnd: parseInt(this.state.frozenColumnCountFromEnd, 10),
      handleColumnReorder: this._handleColumnReorder,
    };
  }

  _getDragDropEvents() {
    return {
      canDrop: () => true,
      canDrag: () => true,
      onDragEnter: () => dragEnterClass,
      onDragLeave: () => {},
      onDrop: item => {
        if (this._draggedItem) {
          this._insertBeforeItem(item);
        }
      },
      onDragStart: (item, itemIndex) => {
        this._draggedItem = item;
        this._draggedIndex = itemIndex;
      },
      onDragEnd: () => {
        this._draggedItem = undefined;
        this._draggedIndex = -1;
      },
    };
  }

  _insertBeforeItem(item) {
    const draggedItems = this._selection.isIndexSelected(this._draggedIndex)
      ? this._selection.getSelection()
      : [this._draggedItem];

    this.setState(prevState => {
      const insertIndex = prevState.items.indexOf(item);
      const items = prevState.items.filter(itm => draggedItems.indexOf(itm) === -1);
      items.splice(insertIndex, 0, ...draggedItems);
    });
    // this.setState({ items });
  }

  loadColumnsData = () => {
    let columns = [];
    this._columns = [
      {
        key: 'column1',
        name: '#',
        fieldName: 'key',
        minWidth: 70,
        maxWidth: 90,
        isResizable: true,
        onColumnClick: this._onColumnClick,
        data: 'number',
        onRender: item => <span>{item.key}</span>,
        isPadded: true,
      },
    ];
    if (
      this.props.coloumsData &&
      this.props.coloumsData.listviewProfileSettingsDTO &&
      this.props.coloumsData.listviewProfileSettingsDTO[0]
    ) {
      const settings = JSON.parse(this.props.coloumsData.listviewProfileSettingsDTO[0].settings);
      if (settings && settings.ListviewSettings && settings.ListviewSettings.VisibleColumns) {
        columns = settings.ListviewSettings.VisibleColumns.Column;
        if (columns && columns.length > 0) {
          columns.map((columnOption, index) => {
            const eachColumn = {
              id: '',
              key: '',
              name: '',
              displayIndex: '',
              fieldName: '',
              data: '',
              isResizable: true,
              onRender: () => {},
            };
            eachColumn.id = index;
            eachColumn.key = `column${index + 2}`;
            eachColumn.name = columnOption['@Name'];
            eachColumn.displayIndex = columnOption['@DisplayIndex'];
            eachColumn.fieldName =
              columnOption['@Name'].charAt(0).toLowerCase() + columnOption['@Name'].slice(1);
            eachColumn.data = 'string';
            eachColumn.isResizable = true;
            eachColumn.isRowHeader = true;
            eachColumn.onColumnClick = this._onColumnClick;
            eachColumn.onRender = columnOpt => <span>{columnOpt[eachColumn.fieldName]}</span>;

            this._columns.push(eachColumn);
            return this._columns;
          });
          this.setState({ columns: this._columns });
        }
      }
    }
  };

  componentDidUpdate(previousProps, previousState) {
    if (previousState.isModalSelection !== this.state.isModalSelection && !this.state.isModalSelection) {
      this._selection.setAllSelected(false);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.listViewData !== this.props.listViewData) {
      this.loadListViewData();
      this.loadColumnsData();
      this.loadInitialOptions(nextProps.listViewData);
    }
  }

  componentDidMount() {
    this.loadColumnsData();
    this.loadListViewData();
    this.loadInitialOptions(this.props.listViewData);

    const sessionId = _.get(this.props, 'sessionId', '');

    const commandType = _.get(this.props, 'commandType', '');
    const categoryCode = commandType === 'Office' ? 'OP' : 'COP';
    const getUserReportsRequestParam = {
      sessionID: sessionId,
      usage: '|BYCATEGORYCODE|',
      categoryCode,
    };
    const getUserReports = _.get(this.props, 'getUserReportsRequest', null);

    if (getUserReports) {
      getUserReports(getUserReportsRequestParam);
    }
  }

  _getKey(item) {
    return item.key;
  }

  _getSelectionDetails() {
    const selectionCount = this._selection.getSelectedCount();
    switch (selectionCount) {
      case 0:
        return 'No items selected';
      case 1:
        return `1 item selected: ${this._selection.getSelection()[0].name}`;
      default:
        return `${selectionCount} items selected`;
    }
  }
}
function _copyAndSort(items, columnKey, isSortedDescending) {
  const key = columnKey;
  return items.slice(0).sort((a, b) => ((isSortedDescending ? a[key] < b[key] : a[key] > b[key]) ? 1 : -1));
}
function _generateDocuments() {
  const items = [];
  for (let i = 0; i < 100; i += 1) {
    const randomDate = _randomDate(new Date(2012, 0, 1), new Date());
    const randomFileSize = _randomFileSize();
    const randomFileType = _randomFileIcon();
    let fileName = _lorem(2);
    fileName = fileName.charAt(0).toUpperCase() + fileName.slice(1).concat(`.${randomFileType.docType}`);
    let userName = _lorem(2);
    userName = userName
      .split(' ')
      .map(name => name.charAt(0).toUpperCase() + name.slice(1))
      .join(' ');
    items.push({
      key: i.toString(),
      name: fileName,
      value: fileName,
      iconName: randomFileType.url,
      fileType: randomFileType.docType,
      modifiedBy: userName,
      dateModified: randomDate.dateFormatted,
      dateModifiedValue: randomDate.value,
      fileSize: randomFileSize.value,
      fileSizeRaw: randomFileSize.rawSize,
      sequenceNumber: i + 1,
    });
  }
  return items;
}
function _randomDate(start, end) {
  const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
  return {
    value: date.valueOf(),
    dateFormatted: date.toLocaleDateString(),
  };
}
const FILE_ICONS = [
  { name: 'accdb' },
  { name: 'csv' },
  { name: 'docx' },
  { name: 'dotx' },
  { name: 'mpt' },
  { name: 'odt' },
  { name: 'one' },
  { name: 'onepkg' },
  { name: 'onetoc' },
  { name: 'pptx' },
  { name: 'pub' },
  { name: 'vsdx' },
  { name: 'xls' },
  { name: 'xlsx' },
  { name: 'xsn' },
];
function _randomFileIcon() {
  const docType = FILE_ICONS[Math.floor(Math.random() * FILE_ICONS.length)].name;
  return {
    docType,
    url: `https://static2.sharepointonline.com/files/fabric/assets/brand-icons/document/svg/${docType}_16x1.svg`,
  };
}
function _randomFileSize() {
  const fileSize = Math.floor(Math.random() * 100) + 30;
  return {
    value: `${fileSize} KB`,
    rawSize: fileSize,
  };
}
const LOREM_IPSUM = (
  'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut ' +
  'labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut ' +
  'aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore ' +
  'eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt '
).split(' ');
let loremIndex = 0;
function _lorem(wordCount) {
  const startIndex = loremIndex + wordCount > LOREM_IPSUM.length ? 0 : loremIndex;
  loremIndex = startIndex + wordCount;
  return LOREM_IPSUM.slice(startIndex, loremIndex).join(' ');
}

Table.propTypes = {
  clickRowItem: PropTypes.func,
  checkIsAllow: PropTypes.func,
  listViewData: PropTypes.array,
  coloumsData: PropTypes.object,
  commandType: PropTypes.string,
  getContracts: PropTypes.object,
  getOffices: PropTypes.object,
  getListViewProfileSettings: PropTypes.object,
  getUserReports: PropTypes.array,
  getXMLStyleSheet: PropTypes.object,
  getUserReportsRequest: PropTypes.func,
  getXMLStyleSheetRequest: PropTypes.func,
  sessionId: PropTypes.string,
};

const mapStateToProps = state => ({
  commandType: commandType(state),
  getContracts: getContracts(state),
  getOffices: getOffices(state),
  getListViewProfileSettings: getListViewProfileSettings(state),
  sessionId: getSessionId(state.connectUser),
  getUserReports: getUserReports(state),
  getXMLStyleSheet: getXMLStyleSheet(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    clickRowItem: clickedRowItem => dispatch(clickRowItem(clickedRowItem)),
    checkIsAllow: isAllow => dispatch(checkIsAllow(isAllow)),
    getUserReportsRequest: requestParams => dispatch(getUserReportsRequest(requestParams)),
    getXMLStyleSheetRequest: requestParams => dispatch(getXMLStyleSheetRequest(requestParams)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Table);
