/* eslint-disable no-shadow */
/* eslint-disable no-param-reassign */
import React from 'react';
import { Link } from 'react-router-dom';
import _ from 'lodash';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Fabric } from 'office-ui-fabric-react/lib/Fabric';
import { ImageFit } from 'office-ui-fabric-react/lib/Image';
import {
  DetailsList,
  DetailsListLayoutMode,
  Selection,
  SelectionMode,
  DetailsRow,
} from 'office-ui-fabric-react/lib/DetailsList';
import { MarqueeSelection } from 'office-ui-fabric-react/lib/MarqueeSelection';
import { getTheme } from 'office-ui-fabric-react/lib/Styling';
import { Pagination } from '@uifabric/experiments/lib/Pagination';
import { ComboBox, mergeStyles } from 'office-ui-fabric-react/lib/index';
import { Card, ListGroup } from 'react-bootstrap';
import history from 'utils/history';
import { getRouterHistory } from './Selector';

import ListTitle from '../ListTitle/ListTitle';
import eyeImage from '../../images/eye-icon.svg';
import printImage from '../../images/printer.svg';
import restoreImage from '../../images/restore.svg';
import styleImage from '../../images/stylesheet.png';
import downImage from '../../images/down_arrow.svg';
import upImage from '../../images/up_arrow.svg';
import './Table.scss';
import { getUserReports, getXMLStyleSheet } from './selectors';
import clickRowItem, {
  getUserReportsRequest,
  getXMLStyleSheetRequest,
  addUserListviewSettingRequest,
  updateUserListviewSettingRequest,
} from '../../containers/HomePage/actions';
import { getSessionId } from '../Header/selectors';
import {
  getContracts,
  getOffices,
  getListViewProfileSettings,
  commandType,
} from '../../containers/ProviderResultContainer/selectors';
import { checkIsAllow } from '../Header/action';

// initializeIcons();
const theme = getTheme();
const dragEnterClass = mergeStyles({
  backgroundColor: theme.palette.neutralLight,
});

const wrapperClassName = mergeStyles({
  selectors: {
    '& > *': { marginBottom: '20px' },
    '& .ms-ComboBox': { maxWidth: '300px' },
  },
  float: 'left',
  boxSizing: 'border-box',
  padding: '10px',
  width: '50%',
});

class Table extends React.Component {
  constructor(props) {
    super(props);
    this.selector = React.createRef();
    this.onPageChange = index => {
      this.setState(
        {
          selectedPageIndex: index,
        },
        () => {},
      );
    };
    this.handleOnClick = () => {
      const sessionId = _.get(this.props, 'sessionId', '');
      const commandType = _.get(this.props, 'commandType', '');
      const categoryCode = commandType === 'Office' ? 'OP' : 'COP';
      let url = '';
      if (this.state.hoveredRowItem.contractId) {
        url = '/ContentView?sId=' + btoa(sessionId) + '&cId=' + btoa(this.state.hoveredRowItem.contractId) + '&cc=' + btoa(categoryCode);
      } else {
        url = '/ContentView?sId=' + btoa(sessionId) + '&oId=' + btoa(this.state.hoveredRowItem.officeID) + '&cc=' + btoa(categoryCode);
      }
      window.open(url, '_blank');
    };

    this.handleRowItemClick = (path, itemDetail) => {
      if (history) {
        history.push(path, { post: itemDetail });
      }
    };

    this._handleColumnReorder = (draggedIndex, targetIndex) => {
      debugger
      if (draggedIndex !== 0 && targetIndex !== 0) {
        const columns = _.get(this.state, 'columns', []);
        const draggedItems = columns[draggedIndex];
        const newColumns = [...columns];
        // insert before the dropped item
        newColumns.splice(draggedIndex, 1);
        newColumns.splice(targetIndex, 0, draggedItems);
        this.setState({ columns: newColumns });
        const columnsReorderd = [];
        newColumns.map((column, index) => {
          const reOrderedColumn = {
            Name: column.name,
            Location: index,
            Width: column.maxWidth,
          };
          columnsReorderd.push(reOrderedColumn);
        });
        if (this.props.listViewProfileId) {
          const updateListViewRequestBody = {
            SessionId: this.props.sessionId,
            UserListviewSettingId: this.props.listViewProfileId,
            ColumnSettings: {
              Settings: {
                Columns: {
                  Column: columnsReorderd,
                },
              },
            },
          };
          this.props.updateUserListviewSetting(updateListViewRequestBody);
        } else if (this.props.commandType === 'Contract') {
          const addContractListViewRwequest = {
            sessionId: this.props.sessionId,
            FormName: 'FindForm',
            ListView: 'lvwResult',
            StoredProcedure: 'ee_GetContracts',
            ColumnSettings: {
              Settings: {
                Columns: {
                  Column: columnsReorderd,
                },
              },
            },
          };
          console.log('request', addContractListViewRwequest);
          this.props.addUserListViewSetting(addContractListViewRwequest);
        } else if (this.props.commandType === 'Office') {
          const addOfficeListViewRequest = {
            sessionId: this.props.sessionId,
            FormName: 'FindForm',
            ListView: 'lvwResult',
            StoredProcedure: 'ee_GetContracts',
            ColumnSettings: {
              Settings: {
                Columns: {
                  Column: columnsReorderd,
                },
              },
            },
          };
          console.log('request', addOfficeListViewRequest);
          this.props.addUserListViewSetting(addOfficeListViewRequest);
        }
        console.log('rearranged', columnsReorderd);
      }
    };

    this._onColumnClick = (ev, column) => {
      const { columns, items } = this.state;
      const newColumns = columns.slice();
      const currColumn = newColumns.filter(currCol => column.key === currCol.key)[0];
      newColumns.forEach(newCol => {
        if (newCol === currColumn) {
          currColumn.isSortedDescending = !currColumn.isSortedDescending;
          currColumn.isSorted = true;
          this.setState({
            announcedMessage: `${currColumn.name} is sorted ${
              currColumn.isSortedDescending ? 'descending' : 'ascending'
            }`,
          });
        } else {
          newCol.isSorted = false;
          newCol.isSortedDescending = true;
        }
      });
      const columnsResized = [];
      newColumns.map((column, index) => {
        debugger;
        console.log('on click width', column.minWidth);
      });
      const newItems = _copyAndSort(items, currColumn.fieldName, currColumn.isSortedDescending);

      this.setState({
        columns: newColumns,
        items: newItems,
      });
    };

    this._dragDropEvents = this._getDragDropEvents();
    this._draggedIndex = -1;

    this._selection = new Selection({
      onSelectionChanged: () => {
        this.setState({
          selectionDetails: this._getSelectionDetails(),
        });
      },
    });
    this.state = {
      items: [],
      columns: [],
      selectionDetails: this._getSelectionDetails(),
      isModalSelection: false,
      isCompactMode: false,
      announcedMessage: undefined,
      isColumnReorderEnabled: true,
      frozenColumnCountFromStart: '0',
      frozenColumnCountFromEnd: '0',
      selectedPageIndex: 0,
      limitPerPage: 10,
      initialOptions: [],
      initialOptions: this.loadInitialOptions(this.props.listViewData),
      isRowHovered: false,
      isDetailCardOpened: false,
      clicked: false,
      rectVal: 0,
      hoveredRowItem: '',
      commandTypeUpdated: false,
      title: {},
      defaultSelectedKey: 10,
      selectedKey: 10,
      allResizedColumns: [],
    };
    this._renderRow = this._renderRow.bind(this);
    this._onColumnResized = this._onColumnResized.bind(this);
  }

  _onChange = (event, option) => {
    this.setState({ defaultSelectedKey: 10 });
    if (option) {
      this.setState({ limitPerPage: option.key, selectedPageIndex: 0, selectedKey: option.key });
    }
  };

  loadInitialOptions(listData) {
    const tableData = listData;
    const dataLength = tableData.length;
    const INITIAL_OPTIONS = [];
    const balance = dataLength % 10;
    for (let i = 1; i <= dataLength / 10; i += 1) {
      const pagination = {
        key: i * 10,
        text: `Showing ${i * 10} of ${dataLength}`,
      };
      INITIAL_OPTIONS.push(pagination);
    }
    if (balance !== 0) {
      const pagination = {
        key: dataLength,
        text: `Showing ${dataLength} of ${dataLength}`,
      };
      INITIAL_OPTIONS.push(pagination);
    }
    this.setState({ initialOptions: INITIAL_OPTIONS, selectedKey: INITIAL_OPTIONS[0].key });
    return INITIAL_OPTIONS;
  }

  loadListViewData(listViewData) {
    const dataWithKey = [];
    if (listViewData && listViewData.length > 0) {
      listViewData.map((option, index) => {
        const key = index + 1;
        option.key = key.toString();
        option.name = option.contractName;
        dataWithKey.push(option);
        return dataWithKey;
      });
    }
    const title = {
      name: `Available ${this.props.commandType}s`,
    };
    this.setState({ items: dataWithKey, title });
  }

  render() {
    const { columns, isCompactMode, items, selectedPageIndex, limitPerPage, rectVal } = this.state;
    return (
      <div className="tabs-container">
        <div className="ms-Grid-row">
          <div className="tab-header">
            <ListTitle title={this.state.title} />
            <div className="float-right" style={{ marginRight: 5 }}>
              <img
                src={restoreImage}
                alt="reset contracts"
                onClick={() => this.getItemsMaxCharLengthForColumns()}
              />
              <img src={printImage} alt="print contracts" />
            </div>
          </div>
        </div>
        {this.state.isRowHovered ? (
          <Card>
            <button
              type="button"
              style={{ top: `${rectVal + 6}px`, position: 'absolute', right: 60, border: 'none' }}
              className="imageClass"
              onMouseEnter={() => {
                this.setState({
                  isRowHovered: true,
                });
              }}
              onClick={() => {
                if (!this.state.clicked) {
                  this.setState({
                    isDetailCardOpened: true,
                  });

                  this.setState({
                    clicked: true,
                  });
                } else {
                  this.setState({
                    isDetailCardOpened: false,
                  });
                  this.setState({
                    clicked: false,
                  });
                }
              }}
            >
              <img src={eyeImage} alt="Contracts Detail" width={30} height={30} imageFit={ImageFit.cover} />
              {!this.state.isDetailCardOpened ? (
                <img
                  src={downImage}
                  style={{ position: 'absolute', left: 30, border: 'none', outline: 'none' }}
                  alt="Contracts Detail"
                  width={30}
                  height={30}
                  imageFit={ImageFit.cover}
                />
              ) : (
                <img
                  src={upImage}
                  style={{ position: 'absolute', left: 30, border: 'none', outline: 'none' }}
                  alt="Contracts Detail"
                  width={30}
                  height={30}
                  imageFit={ImageFit.cover}
                />
              )}
            </button>
            {this.state.isDetailCardOpened ? (
              <p className="imageClass" style={{ top: `${rectVal + 30}px`, position: 'absolute', right: 50 }}>
                <Card style={{ width: '18rem' }}>
                  <ListGroup variant="flush">
                    <ListGroup.Item onClick={() => window.open('/leftNavDetails', '_blank', 'resizable=yes')}>
                      Open in New Window
                    </ListGroup.Item>
                    <ListGroup.Item onClick={() => window.open('/leftNavDetails', '_blank')}>
                      Open in New Tab
                    </ListGroup.Item>
                  </ListGroup>
                </Card>
              </p>
            ) : null}
            <button
              type="button"
              style={{ top: `${rectVal + 9}px`, position: 'absolute', right: 10 }}
              className="imageClass"
              onMouseEnter={() => {
                this.setState({
                  isRowHovered: true,
                });
              }}
              onClick={() => this.handleOnClick()}
              // onClick={(event) => {event.preventDefault(); window.open(this.makeHref("/ContentView"), '_blank');}}
            >
              <img src={styleImage} alt="style contracts" width={25} height={25} imageFit={ImageFit.cover} />
            </button>
          </Card>
        ) : null}

        <Fabric>
          <MarqueeSelection selection={this._selection}>
            <DetailsList
              setKey="hoverSet"
              items={items.slice(
                selectedPageIndex * limitPerPage,
                selectedPageIndex * limitPerPage + limitPerPage,
              )}
              compact={isCompactMode}
              columns={columns}
              selectionMode={SelectionMode.none}
              getKey={this._getKey}
              layoutMode={DetailsListLayoutMode.justified}
              isHeaderVisible
              selectionPreservedOnEmptyClick
              enterModalSelectionOnTouch
              ariaLabelForSelectionColumn="Toggle selection"
              ariaLabelForSelectAllCheckbox="Toggle selection for all items"
              checkButtonAriaLabel="Row checkbox"
              dragDropEvents={this._dragDropEvents}
              columnReorderOptions={
                this.state.isColumnReorderEnabled ? this._getColumnReorderOptions() : undefined
              }
              onRenderRow={this._renderRow}
              onColumnResize={this._onColumnResized}
            />
          </MarqueeSelection>
          <div>
            <div style={{ float: 'left' }} className="pagination-styles">
              <Pagination
                selectedPageIndex={this.state.selectedPageIndex}
                pageCount={Math.ceil(this.state.items.length / this.state.limitPerPage)}
                onPageChange={this.onPageChange}
                format="buttons"
                comboBoxAriaLabel={`${Math.ceil(
                  this.state.items.length / this.state.limitPerPage,
                )} pages available`}
                pageAriaLabel="page"
              />
            </div>

            <div style={{ float: 'right' }}>
              <div className="results">Possible results: {this.state.items.length}</div>

              <div className={wrapperClassName}>
                <ComboBox
                  defaultSelectedKey={this.state.defaultSelectedKey}
                  options={this.state.initialOptions}
                  onChange={this._onChange}
                  selectedKey={this.state.selectedKey}
                />
              </div>
            </div>
          </div>
        </Fabric>
      </div>
    );
  }

  getItemsMaxCharLengthForColumns = () => {
    const columnsWithItems = [];
    this.state.columns.map(option => {
      const columnFieldName = option.fieldName;
      let maxLength = 0;
      this.state.items.map(itemOption => {
        const itemKeys = Object.keys(itemOption);
        itemKeys.map(keyOption => {
          if (columnFieldName === keyOption) {
            if (itemOption && itemOption[keyOption] && itemOption[keyOption].length > maxLength) {
              maxLength = itemOption[keyOption].length;
            }
          }
        });
      });
      columnsWithItems.push(maxLength * 8);
    });
    this._setColumnsWidth(columnsWithItems);
  };

  _setColumnsWidth = columnsWithItems => {
    this.state.columns.map((columnOpt, columnIndex) => {
      if (columnOpt.name.length > columnsWithItems[columnIndex] / 8) {
        columnOpt.minWidth = columnOpt.name.length * 8;
      } else {
        columnOpt.minWidth = columnsWithItems[columnIndex];
      }
    });
    this.setState({ columns: this.state.columns });
  };

  _onColumnResized(props) {
    debugger
    console.log('_onColumnResized', props);
    const resizedColumns = [];
    const eachResizedColumn = {
      columnName: '',
      resizedwidth: '',
    };
    eachResizedColumn.columnName = props.key;
    eachResizedColumn.resizedwidth = props.calculatedWidth;
    resizedColumns.push(eachResizedColumn);
    this.setState({ allResizedColumns: resizedColumns });
    console.log('onresize', this.state.columns);
    const columnsReSized = [];
    this.state.columns.map((column, index) => {
      const reSizedColumn = {
        Name: column.name,
        Location: index,
        Width: column.minWidth,
      };
      columnsReSized.push(reSizedColumn);
    });
    if (this.props.listViewProfileId) {
      const updateListViewRequestBody = {
        SessionId: this.props.sessionId,
        UserListviewSettingId: this.props.listViewProfileId,
        ColumnSettings: {
          Settings: {
            Columns: {
              Column: columnsReSized,
            },
          },
        },
      };
      this.props.updateUserListviewSetting(updateListViewRequestBody);
    } else if (this.props.commandType === 'Contract') {
      const addContractListViewRwequest = {
        sessionId: this.props.sessionId,
        FormName: 'FindForm',
        ListView: 'lvwResult',
        StoredProcedure: 'ee_GetContracts',
        ColumnSettings: {
          Settings: {
            Columns: {
              Column: columnsReSized,
            },
          },
        },
      };
      console.log('request', addContractListViewRwequest);
      this.props.addUserListViewSetting(addContractListViewRwequest);
    } else if (this.props.commandType === 'Office') {
      const addOfficeListViewRequest = {
        sessionId: this.props.sessionId,
        FormName: 'FindForm',
        ListView: 'lvwResult',
        StoredProcedure: 'ee_GetContracts',
        ColumnSettings: {
          Settings: {
            Columns: {
              Column: columnsReSized,
            },
          },
        },
      };
      console.log('request', addOfficeListViewRequest);
      this.props.addUserListViewSetting(addOfficeListViewRequest);
    }
    return resizedColumns;
  }

  _renderRow(props) {
    return (
      <div ref={this.selector} id={props.item.key}>
        {console.log('getrouterHistory - command type--', this.props.getCurrentRoutePath)}
        <DetailsRow
          {...props}
          onClick={() => {
            props.item.isAllow = true;
            this.props.clickRowItem(props.item);
            this.props.checkIsAllow(true);
            if (this.props.getCurrentRoutePath === '/results/contracts') {
              this.handleRowItemClick('/results/contracts/details', props.item);
            }
            if (this.props.getCurrentRoutePath === '/results/office') {
              this.handleRowItemClick('/results/office/details', props.item);
            }
          }}
          onMouseEnter={e => {
            this.setState({
              isRowHovered: true,
              isDetailCardOpened: false,
              hoveredRowItem: props.item,
              clicked: false,
            });

            this.setState({
              rectVal: e.target.offsetParent.offsetTop,
            });
          }}
          onMouseLeave={() => {
            this.setState({
              isRowHovered: false,
              isDetailCardOpened: false,
            });
          }}
        />
      </div>
    );
  }

  _getColumnReorderOptions() {
    return {
      frozenColumnCountFromStart: parseInt(this.state.frozenColumnCountFromStart, 10),
      frozenColumnCountFromEnd: parseInt(this.state.frozenColumnCountFromEnd, 10),
      handleColumnReorder: this._handleColumnReorder,
    };
  }

  _getDragDropEvents() {
    return {
      canDrop: () => true,
      canDrag: () => true,
      onDragEnter: () => dragEnterClass,
      onDragLeave: () => {},
      onDrop: item => {
        if (this._draggedItem) {
          this._insertBeforeItem(item);
        }
      },
      onDragStart: (item, itemIndex) => {
        this._draggedItem = item;
        this._draggedIndex = itemIndex;
      },
      onDragEnd: () => {
        this._draggedItem = undefined;
        this._draggedIndex = -1;
      },
    };
  }

  _insertBeforeItem(item) {
    const draggedItems = this._selection.isIndexSelected(this._draggedIndex)
      ? this._selection.getSelection()
      : [this._draggedItem];

    this.setState(prevState => {
      const insertIndex = prevState.items.indexOf(item);
      const items = prevState.items.filter(itm => draggedItems.indexOf(itm) === -1);
      items.splice(insertIndex, 0, ...draggedItems);
    });
  }

  loadColumnsData = columnsData => {
    let columns = [];
    this._columns = [];
    if (columnsData) {
      columns = columnsData;
      if (columns && columns[0]['@Name']) {
        this._columns = [
          {
            key: 'column0',
            name: '#',
            fieldName: 'key',
            // isResizable: true,
            onColumnClick: this._onColumnClick,
            data: 'number',
            onRender: item => <span>{item.key}</span>,
            isPadded: true,
          },
        ];
      }
      if (columns && columns.length > 0) {
        columns.map((columnOption, index) => {
          const eachColumn = {
            id: '',
            key: '',
            name: '',
            displayIndex: '',
            fieldName: '',
            data: '',
            isResizable: false,
            onRender: () => {},
          };
          eachColumn.id = index;
          eachColumn.key = `column${index + 1}`;
          if (columnOption.Name) {
            eachColumn.name = columnOption.Name;
          } else {
            eachColumn.name = columnOption['@Name'];
          }
          if (columnOption.Location) {
            eachColumn.displayIndex = columnOption.Location;
          } else {
            eachColumn.displayIndex = columnOption['@DisplayIndex'];
          }
          if (columnOption.Name) {
            eachColumn.fieldName = columnOption.Name.charAt(0).toLowerCase() + columnOption.Name.slice(1);
          } else {
            eachColumn.fieldName =
              columnOption['@Name'].charAt(0).toLowerCase() + columnOption['@Name'].slice(1);
          }
          // if (columnOption.Width) {
          //   eachColumn.minWidth = +columnOption.Width;
          //   eachColumn.maxWidth = +columnOption.Width + 50;
          // } else {
          //    eachColumn.minWidth = 50;
          //    eachColumn.maxWidth = 100;
          // }
          eachColumn.data = 'string';
          eachColumn.isResizable = true;
          eachColumn.isRowHeader = true;
          eachColumn.isPadded = true;
          eachColumn.onColumnClick = this._onColumnClick;
          eachColumn.onRender = columnOpt => <span>{columnOpt[eachColumn.fieldName]}</span>;
          if (eachColumn.name === '#') {
            eachColumn.fieldName = 'key';
            eachColumn.isResizable = false;
          }
          // eachColumn.onColumnResize = width => {
          //   if (width > eachColumn.maxWidth) {
          //     eachColumn.minWidth = width;
          //     eachColumn.maxWidth = width + 50;
          //   }
          // };

          this._columns.push(eachColumn);
          return this._columns;
        });
        this.setState({ columns: this._columns });
      }
    }
  };

  columnResizeTable = (eachColumn, minWidth) => {
    console.log('onresize', eachColumn, minWidth);
    const resizeColumns = [];
    this.state.columns.map((column, index) => {
      if (column.name === eachColumn.name) {
        column.minWidth = minWidth;
      }
      resizeColumns.push(column);
    });
    // this.setState({ columns: resizeColumns });
    console.log(resizeColumns);
  };

  componentDidUpdate(previousProps, previousState) {
    if (previousState.isModalSelection !== this.state.isModalSelection && !this.state.isModalSelection) {
      this._selection.setAllSelected(false);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.listViewData !== this.props.listViewData) {
      this.loadListViewData(nextProps.listViewData);
      this.loadColumnsData(nextProps.coloumsData);
      this.loadInitialOptions(nextProps.listViewData);
    }
  }

  componentDidMount() {
    this.loadColumnsData(this.props.coloumsData);
    this.loadListViewData(this.props.listViewData);
    this.loadInitialOptions(this.props.listViewData);
  }

  _getKey(item) {
    return item.key;
  }

  _getSelectionDetails() {
    const selectionCount = this._selection.getSelectedCount();
    switch (selectionCount) {
      case 0:
        return 'No items selected';
      case 1:
        return `1 item selected: ${this._selection.getSelection()[0].name}`;
      default:
        return `${selectionCount} items selected`;
    }
  }
}
function _copyAndSort(items, columnKey, isSortedDescending) {
  const key = columnKey;
  return items.slice(0).sort((a, b) => ((isSortedDescending ? a[key] < b[key] : a[key] > b[key]) ? 1 : -1));
}

Table.propTypes = {
  clickRowItem: PropTypes.func,
  checkIsAllow: PropTypes.func,
  listViewData: PropTypes.array,
  listViewProfileId: PropTypes.string,
  coloumsData: PropTypes.object,
  commandType: PropTypes.string,
  getContracts: PropTypes.object,
  getOffices: PropTypes.object,
  getListViewProfileSettings: PropTypes.object,
  getCurrentRoutePath: PropTypes.string,
  getUserReports: PropTypes.array,
  getXMLStyleSheet: PropTypes.object,
  getUserReportsRequest: PropTypes.func,
  getXMLStyleSheetRequest: PropTypes.func,
  sessionId: PropTypes.string,
  addUserListViewSetting: PropTypes.func,
  updateUserListviewSetting: PropTypes.func,
};

const mapStateToProps = state => ({
  commandType: commandType(state),
  getContracts: getContracts(state),
  getOffices: getOffices(state),
  getListViewProfileSettings: getListViewProfileSettings(state),
  getCurrentRoutePath: getRouterHistory(state),
  sessionId: getSessionId(state),
  getUserReports: getUserReports(state),
  getXMLStyleSheet: getXMLStyleSheet(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    clickRowItem: clickedRowItem => dispatch(clickRowItem(clickedRowItem)),
    checkIsAllow: isAllow => dispatch(checkIsAllow(isAllow)),
    getUserReportsRequest: requestParams => dispatch(getUserReportsRequest(requestParams)),
    getXMLStyleSheetRequest: requestParams => dispatch(getXMLStyleSheetRequest(requestParams)),
    addUserListViewSetting: requestParams => dispatch(addUserListviewSettingRequest(requestParams)),
    updateUserListviewSetting: requestParams => dispatch(updateUserListviewSettingRequest(requestParams)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Table);
