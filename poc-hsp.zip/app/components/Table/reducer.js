export default function clickRowItemReducer(state = {}, action) {
    switch (action.type) {
      case 'CLICK_ROW_ITEM': {
        return action.clickedRowItem;
      }
      default:
        return state;
    }
  }
  