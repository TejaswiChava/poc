import React from 'react';

const ErrorMessage = Props =>
  Props.isVisible ? (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
          <p style={{ color: 'red' }}>{Props.message}</p>
        </div>
      </div>
    </div>
  ) : null;

export default ErrorMessage;
