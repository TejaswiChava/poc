import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';
import { Field } from 'formik';

import ErrorMessage from '../ErrorMessage/index';
import './style.css';

export default class ComboBox extends Component {
  static propTypes = {
    error: PropTypes.any,
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    value: PropTypes.string,
    onChange: PropTypes.func,
    isRequired: PropTypes.bool,
    title: PropTypes.string,
    options: PropTypes.array,
    onClickHandle: PropTypes.func,
    isLoading: PropTypes.bool,
  };

  getOptionsStyle = optionsData =>
    optionsData.map(i => (
      <option key={`combo_${i.name}`} value={i.code}>
        {i.name}
      </option>
    ));

  render() {
    const renderError = _.get(this.props, 'error', null) ? (
      <ErrorMessage isVisible={this.props.error} message={this.props.error} />
    ) : null;
    const isLoading = _.get(this.props, 'isLoading', null) ? (
      <ErrorMessage isVisible={!!_.get(this.props, 'isLoading', null)} message="Loading..." />
    ) : null;

    return (
      <Fragment key={`Fragment_${this.props.name}`}>
        <div style={{ paddingTop: 12 }}>
          <label id="selectOne" className={this.props.isRequired ? 'required label' : 'label'}>
            {' '}
            {this.props.label}{' '}
          </label>
          <div>
            <Field name={this.props.name} key={`Field_${this.props.name}`}>
              {props => {
                const { field } = props;
                const defaultOption = (
                  <option key={`Default${this.props.name}`} value="">
                    Please Select
                  </option>
                );
                const optionsFormat = this.getOptionsStyle(_.get(this, 'props.options', []));
                const options = [defaultOption, ...optionsFormat];
                return (
                  <div className="dropdown" title={this.props.title} key={`div${this.props.name}`}>
                    <select
                      {...field}
                      value={field.value}
                      multiple={false}
                      key={`Select${this.props.name}`}
                      onClick={() => this.props.onClickHandle()}
                      style={{ padding: 4, width: '100%' }}
                      required={this.props.isRequired}
                    >
                      {options}
                    </select>
                  </div>
                );
              }}
            </Field>
          </div>
        </div>
        {renderError}
        {isLoading}
      </Fragment>
    );
  }
}
