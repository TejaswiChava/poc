import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';
import { Field } from 'formik';

import ErrorMessage from '../ErrorMessage/index';
import './style.css';

export default class ComboBox extends Component {
  static propTypes = {
    error: PropTypes.any,
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    value: PropTypes.string,
    onChange: PropTypes.func,
    isRequired: PropTypes.bool,
    title: PropTypes.string,
    options: PropTypes.array,
    onClickHandle: PropTypes.func,
    isLoading: PropTypes.bool,
    onClickCapture: PropTypes.func,
  };

  getOptionsStyle = optionsData =>
    optionsData.map(i => (
      <option key={`combo_${i.name}_${i.value}`} value={i.value}>
        {i.name}
      </option>
    ));

  render() {
    const renderError = _.get(this.props, 'error', null) ? (
      <ErrorMessage isVisible={this.props.error} message={this.props.error} />
    ) : null;
    const isLoading = _.get(this.props, 'isLoading', null) ? (
      <ErrorMessage isVisible={!!_.get(this.props, 'isLoading', null)} message="Loading..." />
    ) : null;

    return (
      <Fragment key={`Fragment_${this.props.name}`}>
        <div style={{ paddingTop: 12 }}>
          <label id="selectOne" className={this.props.isRequired ? 'required label' : 'label'}>
            {' '}
            {this.props.label}{' '}
          </label>
          <div>
            <Field name={this.props.name} key={`Field_${this.props.name}`}>
              {props => {
                const { field } = props;
                const defaultOption = (
                  <option key={`Default${this.props.name}`} value="" disabled selected hidden>
                    Please Select
                  </option>
                );

                const dropdownValues = _.get(this.props, 'options', [])
                  ? _.get(this.props, 'options', [])
                  : [];
                const optionsFormat = this.getOptionsStyle(dropdownValues);
                const options = [defaultOption, ...optionsFormat];
                return (
                  <div className="dropdown" title={this.props.title} key={`div${this.props.name}`}>
                    <select
                      {...field}
                      value={field.value}
                      multiple={false}
                      key={`Select${this.props.name}`}
                      onClick={() => this.props.onClickHandle()}
                      style={{ padding: 4, width: '100%' }}
                      required={this.props.isRequired}
                      onLoad={this.props.onLoad}
                      onClickCapture={() => this.props.onClickCapture()}
                    >
                      {options}
                    </select>
                  </div>
                );
              }}
            </Field>
          </div>
        </div>
        {renderError}
        {isLoading}
      </Fragment>
    );
  }
}
