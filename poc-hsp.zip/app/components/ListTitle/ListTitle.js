/* eslint-disable react/prop-types */
import React from 'react';
import _ from 'lodash';

const ListTitle = props => {
  const name = _.get(props, 'title.name', '');

  return <h5 className="tab-heading float-left">{name}</h5>;
};
export default ListTitle;
