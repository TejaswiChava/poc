import React, { Component } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';

import ErrorMessage from '../ErrorMessage/index';
import './style.css';

export default class ResultCountButtons extends Component {
  static propTypes = {
    paginationData: PropTypes.array,
    label: PropTypes.string,
    setResultCount: PropTypes.func,
    error: PropTypes.any,
    isRequired: PropTypes.bool,
  };

  state = {
    value: '',
  };

  static getDerivedStateFromProps(props, state) {
    if (_.get(props, 'value', '') !== state.value) {
      return {
        value: _.get(props, 'value', ''),
      };
    }
    return null;
  }

  render() {
    const lastOptionData = _.get(this.props, `paginationData[${this.props.paginationData.length - 1}]`, {});
    const renderError = _.get(this.props, 'error', null) ? (
      <ErrorMessage isVisible={this.props.error} message={this.props.error} />
    ) : null;

    return (
      <div style={{ paddingTop: 6 }} key="resultPagination_Container">
        <label
          id="resultPagination_Label"
          className={this.props.isRequired ? 'required ms-Label root-70' : 'ms-Label root-70'}
        >
          {this.props.label}
        </label>
        <div id="resultPagination" key="resultPagination">
          {_.get(this.props, 'paginationData', []).length > 0 && (
            <button
              type="button"
              className="resultPaginationBtn"
              key={this.props.label}
              style={
                lastOptionData.code === this.state.value ? { backgroundColor: '#b3d1ff', color: 'black' } : {}
              }
              onClick={() => {
                this.setState({ value: lastOptionData.code }, () =>
                  this.props.setResultCount(lastOptionData),
                );
              }}
            >
              All
            </button>
          )}
          {this.props.paginationData.map(data => (
            <button
              key={`button_${data.name}`}
              type="button"
              className="resultPaginationBtn"
              style={data.code === this.state.value ? { backgroundColor: '#b3d1ff', color: 'black' } : {}}
              onClick={() => {
                this.setState({ value: data.code }, () => this.props.setResultCount(data));
              }}
            >
              {data.name}
            </button>
          ))}
        </div>
        {renderError}
      </div>
    );
  }
}
