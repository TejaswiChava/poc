/* eslint-disable react/prop-types */
import * as React from 'react';
import { Dropdown } from 'react-bootstrap';
import _ from 'lodash';
import settings from '../../images/icons/settings.svg';

const ProfileAction = props => {
  const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <button
      style={{ background: 'transparent', border: 'unset' }}
      type="button"
      ref={ref}
      onClick={e => {
        e.preventDefault();
        onClick(e);
      }}
      onChange={e => {
        props.profileActionHandle(e);
      }}
    >
      {children}
      {/* &#9881; */}
      <img src={settings} alt="Profile action" />
    </button>
  ));
  return (
    <>
      <Dropdown>
        <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components" />

        <Dropdown.Menu>
          <Dropdown.Item eventKey="3" disabled>
            Available Profiles
          </Dropdown.Item>
          <Dropdown.Divider style={{ marginBottom: 4, marginTop: -4 }} />
          {_.get(props, 'profiles', []).map((data, index) => (
            <Dropdown.Item
              eventKey={index}
              key={`action_${data}`}
              onClick={() => props.profileActionHandle(data)}
              // active={data.status === 'Active'}
            >
              {data.name}
            </Dropdown.Item>
          ))}
          <Dropdown.Item eventKey="3" disabled>
            Manage Profile
          </Dropdown.Item>
          <Dropdown.Divider style={{ marginBottom: 4, marginTop: -4 }} />
        </Dropdown.Menu>
      </Dropdown>
    </>
  );
};

export default ProfileAction;
