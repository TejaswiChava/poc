/* eslint-disable react/prop-types */
import * as React from 'react';
import { Dropdown } from 'react-bootstrap';
import settings from '../../images/icons/settings.svg';

const profileClicked = data => {
  console.log('Clicked', data);
};
const ProfileAction = () => {
  const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <button
      style={{ background: 'transparent', border: 'unset' }}
      type="button"
      ref={ref}
      onClick={e => {
        e.preventDefault();
        onClick(e);
      }}
      onChange={e => {
        profileClicked(e);
      }}
    >
      {children}
      {/* &#9881; */}
      <img src={settings} alt="Profile action" />
    </button>
  ));
  return (
    <>
      <Dropdown>
        <Dropdown.Toggle as={CustomToggle} id="dropdown-custom-components" />

        <Dropdown.Menu onChange={profileClicked}>
          {[1, 2, 3].map((data, index) => (
            <Dropdown.Item eventKey={index} key={`action_${data}`} onClick={() => profileClicked(data)}>
              Profile {data}
            </Dropdown.Item>
          ))}
        </Dropdown.Menu>
      </Dropdown>
    </>
  );
};

export default ProfileAction;
