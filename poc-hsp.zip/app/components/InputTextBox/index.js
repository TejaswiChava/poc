import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';

import { TextField } from 'office-ui-fabric-react/lib/TextField';

export default class InputTextBox extends PureComponent {
  static propTypes = {
    error: PropTypes.any.isRequired,
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    value: PropTypes.any.isRequired,
    onChange: PropTypes.any.isRequired,
    isRequired: PropTypes.bool.isRequired,
    title: PropTypes.string.isRequired,
  };

  render() {
    const renderError = _.get(this.props, 'error', null) ? this.props.error : '';

    return (
      <div style={{ paddingTop: 8 }}>
        <TextField
          label={this.props.label}
          errorMessage={renderError}
          placeholder={`Enter ${this.props.label}`}
          name={this.props.name}
          value={this.props.value}
          title={this.props.title}
          onChange={this.props.onChange}
          required={this.props.isRequired}
        />
      </div>
    );
  }
}
