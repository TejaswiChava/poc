import React from 'react';
import _ from 'lodash';
import ReactHtmlParser from 'react-html-parser';

class ContentViewComponent extends React.Component {
  constructor(props) {
    super(props);
    this.html = _.get(props, 'location.state.post', null);
  }

  render() {
    return <div>{ReactHtmlParser(this.html.data)}</div>;
  }
}

export default ContentViewComponent;
