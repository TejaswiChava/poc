import React from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { getUserReports, getXMLStyleSheet } from './selectors';
import { getUserReportsRequest, getXMLStyleSheetRequest } from '../../containers/HomePage/actions';
import { commandType } from '../../containers/ProviderResultContainer/selectors';
import { getSessionId } from '../Header/selectors';
import './ContentView.scss';
import printImage from '../../images/printer.svg';
import popImage from '../../images/pop_out.svg';
import restoreImage from '../../images/restore.svg';

class ContentViewComponent extends React.Component {
  
  constructor(props) {
    super(props);
    this.urlParams = new URLSearchParams(window.location.search);
    this.sessionId = this.urlParams.get('sId') ? atob(this.urlParams.get('sId')) : this.props.sessionId;
    this.contractId = this.urlParams.get('cId') ? atob(this.urlParams.get('cId')) : (this.props.NavDetails ? this.props.NavDetails.contractId : '');
    this.officeId = this.urlParams.get('oId') ? atob(this.urlParams.get('oId')) : (this.props.NavDetails ? this.props.NavDetails.officeID : '');
    this.contractCode = this.urlParams.get('cc') ? atob(this.urlParams.get('cc')) : '';
    this.report = '';
    this.zoomLevel = ['25%', '33%', '50%', '67%', '75%', '80%', '90%', '100%', '110%', '125%', '150%', '175%', '200%', '250%', '300%', '400%', '500%']
  }

  componentWillMount() {
    this.callXMLAPI = true;
    _.set(this.props, 'getXMLStyleSheet.data', '');
  }

  componentDidMount() {
    this.contractCode = this.contractCode ? this.contractCode : (this.props.CommandType === 'Office' ? 'OP' : 'COP');
    setTimeout(() => {
      this.getUserReportsOnMount();
    }, 1000)
  }

  getUserReportsOnMount() {
    const getUserReportsRequestParam = {
      sessionID: this.sessionId,
      usage: '|BYCATEGORYCODE|',
      categoryCode: this.contractCode,
    };
    const getUserReports = _.get(this.props, 'getUserReportsRequest', null);   
    if (getUserReports) {
      getUserReports(getUserReportsRequestParam);
    }
  }

  componentDidUpdate () {
    if (this.props.getUserReports.length > 0 && this.callXMLAPI) {
      this.report = this.props.getUserReports[0].userReportId;
      this.callXMLAPI = false;
      this.getXMLStyleSheetOnMount(this.props.getUserReports[0]);
    }
  }

  getXMLStyleSheetOnMount(reports) {
    const getXMLStyleSheetRequestData = {
        SPName: reports.storedProcedureName,
        XSLTPath: reports.reportPath,
        sessionId: this.sessionId,
      };

      if (this.contractId) {
        getXMLStyleSheetRequestData.contractid = this.contractId;
      } else {
        getXMLStyleSheetRequestData.officeid = this.officeId;
        getXMLStyleSheetRequestData.ReturnStatus = 'N';
      }

      const getXMLStyleSheet = _.get(this.props, 'getXMLStyleSheetRequest', null);
      if (getXMLStyleSheet) {
        getXMLStyleSheet(getXMLStyleSheetRequestData);
      }
  }

  changeStyleSheet(reports, report) {
    _.set(this.props, 'getXMLStyleSheet.data', '');
    this.report = report;
    reports.map((value) => {
      if (report.toString() === value.userReportId.toString()) {
        this.getXMLStyleSheetOnMount(value);
      }
    })
  }

  openInNewWindow(reports, report) {
    this.report = report;
    reports.map((value) => {
      if (report.toString() === value.userReportId.toString()) {
        let url = '';
        if (this.contractId) {
          url = '/ContentView?sId=' + btoa(this.sessionId) + '&cId=' + btoa(this.contractId) + '&cc=' + btoa(this.contractCode);
        } else {
          url = '/ContentView?sId=' + btoa(this.sessionId) + '&oId=' + btoa(this.officeId) + '&cc=' + btoa(this.contractCode);
        }
        window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=300,width=800,height=500");
      }
    })
  }

  changeZoomStyle(zoom) {
    document.getElementById('stylesheetContainer').style.zoom = zoom;
  }

  render() {
    return <div>
     {this.props.getUserReports.length > 0 ?
      <form>
      <div class="form-group">
        <label for="styleSheetSelect"></label>
        <select class="combo-select" id="styleSheetSelect" onChange={() => this.changeStyleSheet(this.props.getUserReports, event.target.value)}>
          {this.props.getUserReports.map((reports) => {
            return <option value={reports.userReportId}>{reports.reportName}</option>
          })
          }
        </select>
        <span className="float-right" style={{ marginRight: 5 }}>
          <img src={restoreImage} alt="reset contracts" onClick={() => this.changeStyleSheet(this.props.getUserReports, this.report)}/>
          <img src={printImage} alt="print contracts" />
          <img src={popImage} alt="new window contracts" onClick={() => this.openInNewWindow(this.props.getUserReports, this.report)}/>
          <select class="combo-select-zoom" onChange={() => this.changeZoomStyle(event.target.value)}>
            {this.zoomLevel.map((zoom) => {
              if (zoom === '100%') {
                return <option value={zoom} selected>{zoom}</option>
              } else {
                return <option value={zoom}>{zoom}</option>
              }
            })
            }
        </select>
        </span>
        </div>
      </form> : null }
    <div id="stylesheetContainer"><iframe allowFullScreen width="100%" height="530" srcDoc = { _.get(this.props, 'getXMLStyleSheet.data', null) }/></div>
    </div>
  }
}

ContentViewComponent.propTypes = {
  commandType: PropTypes.string,
  getUserReports: PropTypes.array,
  getXMLStyleSheet: PropTypes.object,
  getUserReportsRequest: PropTypes.func,
  getXMLStyleSheetRequest: PropTypes.func,
  sessionId: PropTypes.string,
};

const mapStateToProps = state => ({
  commandType: commandType(state),
  sessionId: getSessionId(state),
  getUserReports: getUserReports(state),
  getXMLStyleSheet: getXMLStyleSheet(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    getUserReportsRequest: requestParams => dispatch(getUserReportsRequest(requestParams)),
    getXMLStyleSheetRequest: requestParams => dispatch(getXMLStyleSheetRequest(requestParams)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ContentViewComponent);


