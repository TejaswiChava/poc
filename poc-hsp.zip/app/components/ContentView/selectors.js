import _ from 'lodash';

const getXMLStyleSheet = state => _.get(state, 'getXMLStyleSheet', {});
const getUserReports = state => _.get(state, 'getUserReports.data.userReportsDTO', []);

export { getUserReports, getXMLStyleSheet };
