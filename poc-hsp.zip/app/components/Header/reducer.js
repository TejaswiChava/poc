export function commandTypeReducer(state = '', action) {
  switch (action.type) {
    case 'SAVE_COMMAND_TYPE': {
      return action.commandType;
    }
    default:
      return state;
  }
}

export function checkIsAllowReducer(state = false, action) {
  switch (action.type) {
    case 'CHECK_IS_ALLOW': {
      return action.isAllow;
    }
    default:
      return state;
  }
}

export default { commandTypeReducer, checkIsAllowReducer };
