import _ from 'lodash';

const getCommandType = state => _.get(state, 'commandType', '');
const getPost = state => _.get(state, 'clickedRowItem', null);
const getIsAllow = state => _.get(state, 'isAllow', true);
const getRouterHistory = state => _.get(state, 'router.location.pathname', null);
const getSessionId = state => _.get(state, 'data.status.sessionId', null);
const getCommandData = state => _.get(state, 'getFindCommands.data.findCommands[0]', null);

export { getCommandType, getSessionId, getCommandData, getPost, getIsAllow, getRouterHistory };
