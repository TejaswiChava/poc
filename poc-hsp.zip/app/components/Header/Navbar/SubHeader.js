/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { Component } from 'react';
import { PrimaryButton, Stack } from 'office-ui-fabric-react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import ArrowIcon from '../../../images/back.svg';
import Magnify from '../../../images/zoom.svg';
import More from '../../../images/actions.svg';
import './SubHeader.scss';
import history from '../../../utils/history';
import { checkIsAllow } from '../action';
import { getCommandType, getPost, getIsAllow, getRouterHistory } from '../selectors';
import Breadcrumb from 'react-bootstrap/Breadcrumb';

class SubHeader extends Component {
  arrowClicked = () => {
    this.props.checkIsAllow(false);
    history.goBack();
  };

  loadComponent = () => {
    if (this.props.getPath === '/results/contracts') {
      return <h4>Contracts</h4>;
    }
    if (this.props.getPath === '/results/office') {
      return <h4>Offices</h4>;
    }
  };

  loadComponentDetails = () => {
    if (this.props.getCommandType === 'Contract') {
      return <h4>{this.props.getPost.contractName}</h4>;
    }
    if (this.props.getCommandType === 'Office') {
      return <h4>{this.props.getPost.officeName}</h4>;
    }
  };

  loadButtonData = () => {
    if (this.props.getPath === '/results/contracts') {
      return <PrimaryButton text="Create Contract" allowDisabledFocus />;
    }
    if (this.props.getPath === '/results/office') {
      return <PrimaryButton text="&nbsp;&nbsp;Create Office&nbsp;&nbsp;&nbsp;" allowDisabledFocus />;
    }
  };

  BreadcrumbItem = () => {
    if (this.props.isAllow === true) {
      if (this.props.getCommandType === 'Contract') {
        return <Breadcrumb.Item href="#">Contracts</Breadcrumb.Item>;
      }
      if (this.props.getCommandType === 'Office') {
        return <Breadcrumb.Item href="#">Offices</Breadcrumb.Item>;
      }
    }
  };

  setValForRoute = () => {
    if (this.props.getPath === '/leftNavDetails') {
      this.props.checkIsAllow(true);
      
    }
  };

  render() {
    console.log('isAllow', this.props.isAllow);
    return (
      <div className="ms-Grid subHeader-block" dir="ltr">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg9 left-side-items">
            {this.setValForRoute()}
            {this.props.isAllow === true ? (
              <span className="arrow-btn-block" onClick={this.arrowClicked}>
                <img src={ArrowIcon} alt="arrow" />
              </span>
            ) : null}
            <div style={{ display: 'inline-block' }}>
              {this.props.getPath === '/' ? null : (
                <Breadcrumb className="sub-header-breadCrumb">
                  <Breadcrumb.Item href="#">Provider</Breadcrumb.Item>
                  {this.BreadcrumbItem()}
                </Breadcrumb>
              )}
              {this.props.isAllow === true ? this.loadComponentDetails() : this.loadComponent()}
            </div>
          </div>
          <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg3 sh-btn-block">
            {this.props.isAllow === true ? (
              <div className="float-right sh-icon-block">
                <img src={Magnify} alt="zoom" onClick={this.alertClicked} />
                <img src={More} alt="more" onClick={this.alertClicked} />
              </div>
            ) : (
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm5 ms-md7 ms-lg4"></div>
                {this.props.getPath === '/' ? null : (
                  <div className="ms-Grid-col ms-sm1 ms-md1 ms-lg1">
                    <span className="img-block-zoom">
                      <img src={Magnify} alt="zoom" onClick={this.alertClicked} />
                    </span>
                  </div>
                )}
                <div className="ms-Grid-col ms-sm6 ms-md4 ms-lg7">
                  <Stack horizontal className="float-right create-contract-btn">
                    {this.loadButtonData()}
                  </Stack>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}

SubHeader.propTypes = {
  getCommandType: PropTypes.string,
  getPost: PropTypes.object,
  isAllow: PropTypes.bool,
  checkIsAllow: PropTypes.func,
  getPath: PropTypes.string,
};

const mapStateToProps = state => ({
  getCommandType: getCommandType(state),
  getPost: getPost(state),
  isAllow: getIsAllow(state),
  getPath: getRouterHistory(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    checkIsAllow: isAllow => dispatch(checkIsAllow(isAllow)),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(SubHeader);
