import React, { Component } from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { Navbar, NavDropdown, Nav, Button } from 'react-bootstrap';
import './Navbar.scss';
import logo from '../../../images/logo_blue_hsp.png';
import history from '../../../utils/history';

import { saveCommandType, checkIsAllow } from '../action';
import { getConnectUserRequest, getFindCommandsRequest } from '../../../containers/HomePage/actions';
import { mockConnectUserRequestData } from '../../../containers/HomePage/mockData';

import { getSessionId, getCommandType, getCommandData } from '../selectors';

const navlist = [
  { id: 1, name: 'Claims' },
  { id: 2, name: 'Enrollment' },
  { id: 3, name: 'Benefits' },
  {
    id: 4,
    name: 'Provider',
    subTitle: [
      { sid: 1, text: 'Contracts', url: '/results/contracts' },
      { sid: 2, text: 'Offices', url: '/results/office' },
    ],
  },
  { id: 5, name: 'Finance' },
  { id: 6, name: 'UM' },
  { id: 7, name: 'WorkFlow' },
  { id: 8, name: 'Tools' },
  { id: 9, name: 'Help' },
];
class NavbarHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      navlistItems: [],
      isClicked: false,
      isClickedProvider: true,
    };
  }

  componentDidMount() {
    const sessionId = _.get(this.props, 'sessionId', null);
    if (sessionId === null || sessionId === '') {
      setTimeout(() => {
        this.props.getConnectUser(mockConnectUserRequestData);
      }, 500);
    }
    this.setState({
      navlistItems: navlist,
    });
  }

  navItemClicked = (event, listItem) => {
    event.preventDefault();
    if (listItem === event && listItem.id !== 4) {
      this.setState({
        isClicked: true,
        isClickedProvider: false,
      });
    }
  };

  loadDataFromAPI = commandType => {
    const sessionId = _.get(this.props, 'sessionId', null);

    if (sessionId !== null) {
      const requestParams = {
        sessionId,
        usage: '|ByFindCommand|',
        findCommand: commandType,
      };
      this.props.getFindCommands(requestParams);
    }
  };

  render() {
    const { navlistItems, isClicked, isClickedProvider } = this.state;
    const commandData = _.get(this.props, 'commandData', {});
    return (
      <div className="Nav-container">
        <Navbar bg="light" expand="lg">
          <Navbar.Brand href="/">
            <img src={logo} alt="logo" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              {navlistItems.map(listItem => {
                if (listItem.id === 4) {
                  return (
                    <NavDropdown
                      title={listItem.name}
                      key={listItem.id}
                      className={isClickedProvider === true ? 'activeCls' : 'hideCls'}
                    >
                      {listItem.subTitle.map(subItem => (
                        <NavDropdown.Item
                          key={subItem.sid}
                          onClick={event => {
                            event.preventDefault();

                            this.setState({
                              isClickedProvider: true,
                            });
                            // this.props.saveCommandType(subItem.text);
                            this.props.checkIsAllow(false);
                            this.props.saveCommandType(subItem.text === 'Contracts' ? 'Contract' : 'Office');
                            if (history) {
                              history.push(subItem.url);
                            }
                            this.loadDataFromAPI(subItem.text === 'Contracts' ? 'Contract' : 'Office');
                          }}
                        >
                          {subItem.text}
                        </NavDropdown.Item>
                      ))}
                    </NavDropdown>
                  );
                }
                return <Nav.Link key={listItem.id}>{listItem.name}</Nav.Link>;
              })}
            </Nav>
            <Button>Log Out</Button>
          </Navbar.Collapse>
        </Navbar>
      </div>
    );
  }
}

NavbarHeader.propTypes = {
  saveCommandType: PropTypes.func,
  checkIsAllow: PropTypes.func,
  getConnectUser: PropTypes.func,
  getFindCommands: PropTypes.func,
  sessionId: PropTypes.string,
  commandData: PropTypes.object,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state.connectUser),
  commandData: getCommandData(state),
});
export function mapDispatchToProps(dispatch) {
  return {
    saveCommandType: commandType => dispatch(saveCommandType(commandType)),
    checkIsAllow: isAllow => dispatch(checkIsAllow(isAllow)),
    getConnectUser: requestParams => dispatch(getConnectUserRequest(requestParams)),
    getFindCommands: requestParams => dispatch(getFindCommandsRequest(requestParams)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(NavbarHeader);
