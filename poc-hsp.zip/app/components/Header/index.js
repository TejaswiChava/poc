import React from 'react';
import NavbarHeader from './Navbar/NavbarHeader';
import SubHeader from './Navbar/SubHeader';
function Header() {
  return (
    <div>
      <NavbarHeader />
      <SubHeader />
    </div>
  );
}

export default Header;
