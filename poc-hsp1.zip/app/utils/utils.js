/**
 * Converts an array into an object keyed by the keyField. eg.
 *
 * const array = [
 *  { id: 123, name: "dave", age: 23 },
 *  { id: 102, name: "tim", age: 23 }
 * ]
 *
 * arrayToObject(array, 'id'):
 * {
 * "123": { id: 123, name: "dave", age: 23 },
 * "102": { id: 102, name: "tim", age: 23 }
 * }
 */
export const arrayToObject = (array, keyField) => {
  if (array && array.length > 0) {
    return array.reduce((obj, item) => {
      // eslint-disable-next-line no-param-reassign
      obj[item[keyField]] = item;
      return obj;
    }, {});
    // eslint-disable-next-line no-else-return
  } else {
    return {};
  }
};

export const getParamValueFromSQL = (sqlParams, paramName) => {
  if (!sqlParams) {
    return '';
  }
  const regex = new RegExp(`@${paramName}(.*)`);
  const value = sqlParams.match(regex);
  const paramObj = value && value.length > 0 ? value[0].split(',')[0].slice() : '';
  const paramValue = paramObj ? paramObj.split('=')[1].trim() : '';
  return paramValue.substring(1, paramValue.length - 1);
};
