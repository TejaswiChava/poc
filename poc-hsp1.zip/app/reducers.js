/**
 * Combine all reducers in this file and export the combined reducers.
 */

import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';

import history from 'utils/history';
import globalReducer from 'containers/App/reducer';

import connectUserReducer, {
  getFindCommandsReducer,
  getFindProfilesReducer,
  findControlReducer,
  getAllDropDownValuesReducer,
  getAllReferenceCodesReducer,
  getContractsReducer,
  getOfficesReducer,
  getListViewProfileSettingsReducer,
  getUserListViewSettingsReducer,
  getUserReportsReducer,
  getXMLStyleSheetReducer,
  allUserOptionsReducer,
  setUserOptionsReducer,
  disconnectUserReducer,
  getAllPermissionsReducer,
  getBenefitStructuresReducer,
  getDropDownValuesReducer,
  getReferenceCodesReducer,
  addUserListviewSettingReducer,
  updateUserListviewSettingReducer,
  getUserOptionsReducer,
} from 'containers/HomePage/reducer';

import clickRowItemReducer from './components/Table/reducer';
import { commandTypeReducer, checkIsAllowReducer } from './components/Header/reducer';
/**
 * Merges the main reducer with the router state and dynamically injected reducers
 */
export default function createReducer(injectedReducers = {}) {
  const rootReducer = combineReducers({
    global: globalReducer,
    router: connectRouter(history),
    clickedRowItem: clickRowItemReducer,
    commandType: commandTypeReducer,
    isAllow: checkIsAllowReducer,
    connectUser: connectUserReducer,
    getFindCommands: getFindCommandsReducer,
    getFindProfiles: getFindProfilesReducer,
    findControl: findControlReducer,
    getAllDropDownValues: getAllDropDownValuesReducer,
    getDropDownValues: getDropDownValuesReducer,
    getAllReferenceCodes: getAllReferenceCodesReducer,
    getReferenceCodes: getReferenceCodesReducer,
    getContracts: getContractsReducer,
    getOffices: getOfficesReducer,
    getListViewProfileSettings: getListViewProfileSettingsReducer,
    getUserListViewSettings: getUserListViewSettingsReducer,
    getUserReports: getUserReportsReducer,
    getXMLStyleSheet: getXMLStyleSheetReducer,
    allUserOptions: allUserOptionsReducer,
    setUserOptions: setUserOptionsReducer,
    disconnectUser: disconnectUserReducer,
    getAllPermissions: getAllPermissionsReducer,
    getBenefitStructures: getBenefitStructuresReducer,
    addUserListviewSetting: addUserListviewSettingReducer,
    updateUserListviewSetting: updateUserListviewSettingReducer,
    getUserOptions: getUserOptionsReducer,
    ...injectedReducers,
  });

  return rootReducer;
}
