import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router-dom';

import editimage from '../../images/edit-black.png';

const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.75em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;

class OfficesDemographicsDetails extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const post = this.props.NavDetails;

    return (
      <div>
        <Container fluid="lg">
          <div className="form-group">
            <button className="editbtn btn-pr btn-sm float-right" type="submit">
              <img src={editimage} alt="edit" />
              Edit
            </button>
          </div>
          <Heading>Demographics</Heading>
          <Row>
            <Col md={2}>
              <Title>Office Number</Title>
              <Detail>{post.officeNumber}</Detail>
            </Col>
            <Col md={2}>
              <Title>Office Name</Title>
              <Detail>{post.OfficeName}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={2}>
              <Title>Street Address 1</Title>
              <Detail>{post.address1}</Detail>
            </Col>
            <Col md={2}>
              <Title>Street Address 2</Title>
              <Detail>{post.address2}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={2}>
              <Title>City</Title>
              <Detail>{post.city}</Detail>
            </Col>
            <Col md={2}>
              <Title>State</Title>
              <Detail>{post.state}</Detail>
            </Col>
            <Col md={2}>
              <Title>Zip Code</Title>
              <Detail>{post.zip}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={2}>
              <Title>County</Title>
              <Detail>{post.County}</Detail>
            </Col>
            <Col md={2}>
              <Title>Country</Title>
              <Detail>{post.countryCode}</Detail>
            </Col>
          </Row>
          <Heading>Contact Information</Heading>
          <Row>
            <Col md={2}>
              <Title>Contact Name</Title>
              <Detail>{post.ContactName}</Detail>
            </Col>
            <Col md={2}>
              <Title>Contact Phone</Title>
              <Detail>{post.ContactPhone}</Detail>
            </Col>
            <Col md={2}>
              <Title>Ext</Title>
              <Detail>{post.ContactExt}</Detail>
            </Col>
            <Col md={2}>
              <Title>Contact Fax</Title>
              <Detail>{post.ContactFax}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={2}>
              <Title>Contact Email</Title>
              <Detail>{post.ContactEmail}</Detail>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}
export default withRouter(OfficesDemographicsDetails);
