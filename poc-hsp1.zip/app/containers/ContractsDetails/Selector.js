import _ from 'lodash';

const getCommandType = state => _.get(state, 'commandType', '');
const getSessionId = state => _.get(state, 'connectUser.data.status.sessionId', null);
const getUsage = state => _.get(state, 'getFindCommands.data.findCommands[0].findUsage', null);

export {
  getCommandType,
  getSessionId,
  getUsage,
};
