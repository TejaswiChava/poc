/*
 * Home Actions
 *
 *
 * To add a new Action:
 * 1) Import your constant
 * 2) Add a function like this:
 *    export function yourAction(var) {
 *        return { type: YOUR_ACTION_CONSTANT, var: var }
 *    }
 */


// GetFindProfiles API

export function getFindProfilesRequest(input) {
  return { type: 'GET_FIND_PROFILES_REQUEST', input };
}

export function getFindProfilesSuccess(data) {
  return { type: 'GET_FIND_PROFILES_SUCCESS', data };
}

export function getFindProfilesFailure(error) {
  return { type: 'GET_FIND_PROFILES_FAILURE', error };
}

// GetFindControl API

export function getFindControlRequest(input) {
  return { type: 'FIND_CONTROL_REQUEST', input };
}

export function getFindControlSuccess(data) {
  return { type: 'FIND_CONTROL_SUCCESS', data };
}

export function getFindControlFailure(error) {
  return { type: 'FIND_CONTROL_FAILURE', error };
}

// GetLinkedDropDownValues API

export function getLinkedDropDownValuesRequest(input, key) {
  return { type: 'DROPDOWN_VALUES_REQUEST', input, key };
}

export function getLinkedDropDownValuesSuccess(data, key) {
  return { type: 'DROPDOWN_VALUES_SUCCESS', data, key };
}

export function getLinkedDropDownValuesFailure(error, key) {
  return { type: 'DROPDOWN_VALUES_FAILURE', error, key };
}

// ReferenceCodes API

export function getReferenceCodesRequest(input, refType) {
  return { type: 'REFERENCE_CODES_REQUEST', input, refType };
}

export function getReferenceCodesSuccess(data, refType) {
  return { type: 'REFERENCE_CODES_SUCCESS', data, refType };
}

export function getReferenceCodesFailure(error, refType) {
  return { type: 'REFERENCE_CODES_FAILURE', error, refType };
}

// GetUserOptions API

export function getUserOptionsRequest(input, key) {
  return { type: 'GET_USER_OPTIONS_REQUEST', input, key };
}

export function getUserOptionsSuccess(data, key) {
  return { type: 'GET_USER_OPTIONS_SUCCESS', data, key };
}

export function getUserOptionsFailure(error, key) {
  return { type: 'GET_USER_OPTIONS_FAILURE', error, key };
}
