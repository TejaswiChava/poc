/*
 * Page
 *
 *
 */
import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';
import 'bootstrap/dist/css/bootstrap.css';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import editimage from '../../images/edit-black.png';
import { getReferenceCode, getAllDropDownValues, getDropDownData } from '../ProviderResultFilterForm/selectors';

import { getUsage, getSessionId } from '../../components/Header/selectors';
import { getReferenceCodesRequest, getLinkedDropDownValuesRequest } from '../ContractsDetails/Action';

const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.9em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;
export const FooterStyle = styled.h5`
  text-align: left;
  margin-bottom: 0.1em;
  font-size: 0.6em;
  color: gray;
`;


class ContractDetails extends React.Component {
  constructor(props){
    super(props);
  }
  render() {
    console.log("contract details",this.props.NavDetails);
    const post = this.props.NavDetails;
    console.log(this.props.getAllDropDownValues.PRICINGMODE);

    const effectiveDateString = post.effectiveDate.split(" ")
    const expirationDateString = post.expirationDate.split(" ")
    return (
    <div>
      <Container fluid="lg">
        <div className="form-group">
          <button className="editbtn btn-pr btn-sm float-right" type="submit">
            <img src={editimage} alt="edit" />
          Edit
        </button>
        </div>
        <Heading>Contract Information</Heading>
        <Row>
          <Col md={3}>
            <Title> Contract Name</Title>
            <Detail> {post.contractName}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Type</Title>
            <Detail> {post.contractDescription}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Number</Title>
            <Detail>{post.contractNumber}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Effective Date</Title>
            <Detail>{expirationDateString[0]}</Detail>
          </Col>
          <Col md={3}>
            <Title>Expiration Date</Title>
            <Detail> {effectiveDateString[0]}</Detail>
          </Col>
          <Col md={3}>
            <Title> Contract Description</Title>
            <Detail> {post.contractDescription}</Detail>
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title> Pricing Mode</Title>
            {/* {this.props.getAllDropDownValues.PRICINGMODE.map(item => {debugger;
              {post.pricingMode === item.value ? <Detail>{item.name}</Detail> : <Detail>-</Detail>}
             })} */}

            {this.props.getAllDropDownValues.PRICINGMODE.map((item) => { 
           
            if (post.pricingMode === item.value) {
              return  <Detail>{item.name}</Detail>
            }  
            if (post.pricingMode === null || undefined) {
              return  <Detail>_</Detail>
            }  
            })}  
                      
          </Col>
          <Col md={3}>
            <Title>Fee Schedule Search Criteria</Title>
            {/* <Detail>{post.feeScheduleSearchCriteria}</Detail> */}
            {this.props.getAllDropDownValues.FeeScheduleSearchCriteria.map((item) => { 
           
           if (post.feeScheduleSearchCriteria === item.value) {
             return  <Detail>{item.name}</Detail>
           }  
           if (post.feeScheduleSearchCriteria === null || undefined) {
             return  <Detail>_</Detail>
           }  
           })} 
          </Col>
        </Row>
        <Row>
          <Col md={3}>
            <Title>Contract Notes</Title>
            <Detail>{post.contractNotes} </Detail>
          </Col>
        </Row>
        <FooterStyle id="header-content">Last updated by Santaco Martis at 4/7/2009 4:25:50 PM</FooterStyle>
      </Container>
    </div>
  );
}
}

ContractDetails.propTypes = {
  getReferenceCodes: PropTypes.func,
  sessionId: PropTypes.string,
  getLinkedDropDownValues: PropTypes.func,
  getAllDropDownValues: PropTypes.object,
  // getDropDownData: PropTypes.array,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  referenceCode: getReferenceCode(state),
  getUsage: getUsage(state),
  getAllDropDownValues: getAllDropDownValues(state),
  // getDropDownData: getDropDownData(state),
});


export default withRouter(
  connect(
    mapStateToProps,
  )(ContractDetails)
);
