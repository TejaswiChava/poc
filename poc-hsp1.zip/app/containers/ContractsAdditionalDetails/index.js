import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';
import 'bootstrap/dist/css/bootstrap.css';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import editimage from '../../images/edit-black.png';
import { getReferenceCode, getAllDropDownValues, getDropDownData } from '../ProviderResultFilterForm/selectors';

import { getUsage, getSessionId } from '../../components/Header/selectors';
import { getReferenceCodesRequest, getLinkedDropDownValuesRequest } from '../ContractsDetails/Action';


const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.75em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;


class ContractsAdditionalDetails extends React.Component {

  constructor(props) {
    super(props);
  }
  render() {
    const post = this.props.NavDetails;

    return (
      <div>
        <Container fluid="lg">
          <div className="form-group">
            <button className="editbtn btn-pr btn-sm float-right" type="submit">
              <img src={editimage} alt="edit" />
          Edit
        </button>
          </div>
          <Heading> Claims Posting</Heading>
          <Row>
            <Col md={3}>
              <Title> Payment Class</Title>
              {/* <Detail>{post.paymentClass}</Detail> */}
              {this.props.getAllDropDownValues.PaymentClass.map((item) => {

                if (post.paymentClass === item.value) {
                  return <Detail>{item.name}</Detail>
                }
                if (post.paymentClass === null || undefined) {
                  return <Detail>_</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Suppress Payment</Title>
              {/* <Detail>{post.suppressPayment}</Detail> */}
              {this.props.getAllDropDownValues.SuppressPayment.map((item) => {

                if (post.suppressPayment === item.value) {
                  return <Detail>{item.name}</Detail>
                }
                if (post.suppressPayment === null || undefined) {
                  return <Detail>_</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Provider Inherit&apos;s Member&apos;s Mispayment</Title>
              {/* <Detail>{post.providerInheritsMemberPayment}</Detail> */}
              {this.props.getAllDropDownValues.ProviderInheritsMemberPayment.map((item) => {

                if (post.providerInheritsMemberPayment === item.value) {
                  return <Detail>{item.name}</Detail>
                }
                //  if (post.providerInheritsMemberPayment === null || undefined) {
                //    return  <Detail>_</Detail>
                //  }  
              })}
            </Col>
          </Row>
          <Heading>Capitation</Heading>
          <Row>
            <Col md={3}>
              <Title> Capitation Rate</Title>
              <Detail>{post.capitationRateName}</Detail>
            </Col>
            <Col md={3}>
              <Title>Last posted</Title>
              <Detail>{post.lastPostedDate}</Detail>
            </Col>
            <Col md={3}>
              <Title>Posting Cuttoff Day</Title>
              <Detail>{post.postingCutoffDay}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Retro Term Limit (Months)</Title>
              <Detail> {post.retroactiveTermLimit}</Detail>
            </Col>
            <Col md={3}>
              <Title>Retro Add Limit (Months)</Title>
              <Detail>{post.retroactiveAddLimit}</Detail>
            </Col>
          </Row>
          <Heading>Claims Adjudication</Heading>
          <Row>
            <Col md={3}>
              <Title> Who to Pay</Title>
              {/* <Detail> {post.toPay}</Detail> */}
              {this.props.getAllDropDownValues.ToPay.map((item) => {
                if (post.toPay === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Pre Estimate Expiration </Title>
              <Detail>{post.preEstExpUnits}</Detail>
            </Col>
            <Col md={3}>
              <Title> Apply Copay per schedule</Title>
              {/* <Detail>{post.applyCopayPerSchedule}</Detail> */}
              {this.props.getAllDropDownValues.ApplyCopayPerSchedule.map((item) => {
                if (post.applyCopayPerSchedule === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title> Negotiated</Title>
              {/* <Detail>{post.NegotiatedName}</Detail> */}
              {this.props.getAllDropDownValues.Negotiated.map((item) => {
                if (post.negotiated === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Money Limit Processing Order </Title>
              {/* <Detail>{post.MoneyLimitProcessingOrderName}</Detail> */}
              {this.props.getAllDropDownValues.MoneyLimitProcessingOrder.map((item) => {
                if (post.moneyLimitProcessingOrder === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Use HCPCS When Adjustication Finds Fee Schedule</Title>
              <Detail>{post.useHCPCSWhenFindFeeSchedule}</Detail>
            </Col>
          </Row>
          <Heading>PCP Options</Heading>
          <Row>
            <Col md={3}>
              <Title> Panel Size Enforcement</Title>
              {/* <Detail>{post.panelSizeEnforcement}</Detail> */}
              {this.props.getAllDropDownValues.PanelSizeEnforcement.map((item) => {
                if (post.panelSizeEnforcement === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Panel Size Calculation Method </Title>
              {/* <Detail>{post.panelSizeCalculationMethod}</Detail> */}
              {this.props.getAllDropDownValues.PanelSizeCalculationMethod.map((item) => {
                if (post.panelSizeCalculationMethod === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title> Future PCP Lookback Period</Title>
              {/* <Detail>{post.futurePCPLookbackPeriod}</Detail> */}
              {post.futurePCPLookbackPeriod === 0 ? <Detail>None</Detail> : <Detail> {post.futurePCPLookbackPeriod}</Detail>}
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title> Primary PCP Lookback Period</Title>
              {/* <Detail>{post.primaryPCPLookbackPeriod}</Detail> */}
              {post.primaryPCPLookbackPeriod === 0 ? <Detail>None</Detail> : <Detail> {post.primaryPCPLookbackPeriod}</Detail>}

            </Col>
            <Col md={3}>
              <Title> Panel Override Allowance </Title>
              {/* <Detail> {post.panelOverrideAllowance}</Detail> */}
              {this.props.getAllDropDownValues.PanelOverrideAllowance.map((item) => {
                if (post.panelOverrideAllowance === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

ContractsAdditionalDetails.propTypes = {
  getReferenceCodes: PropTypes.func,
  sessionId: PropTypes.string,
  getLinkedDropDownValues: PropTypes.func,
  getAllDropDownValues: PropTypes.object,
  // getDropDownData: PropTypes.array,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  referenceCode: getReferenceCode(state),
  getUsage: getUsage(state),
  getAllDropDownValues: getAllDropDownValues(state),
  // getDropDownData: getDropDownData(state),
});


export default withRouter(
  connect(
    mapStateToProps,
  )(ContractsAdditionalDetails)
);
