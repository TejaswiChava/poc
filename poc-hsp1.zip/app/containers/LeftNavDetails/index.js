/*
 * LeftNavDetails
 *
 *
 */
import React, { Component } from 'react';
import { withRouter, BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.css';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import ContractDetails from '../ContractsDetails';
import ContractsAdditionalDetails from '../ContractsAdditionalDetails';
import OfficesDemographicsDetails from '../OfficesDemographicsDetails';
import OfficesAdditionalDetails from '../OfficesAdditionalDetails';
import { getCommandType } from './selector';
import NotFoundPage from '../NotFoundPage';
import LeftNavigationResult from './LeftNavigationResult';
import './DetailsStyles.css';
import './LeftNavStyles.scss';

const MainTitle = styled.h5`
  text-align: left;
  font-size: 1em;
  color: grey;
  padding-top: 0.75em;
  margin-top: 0.75em;
  margin-left: 0.75em;
  vertical-align: middle;
`;

const Title = styled.h5`
  color: black;
  text-align: left;
  justify-content: center;
  font-size: 0.9em;
  color: grey;
  margin-left: 1.5em;
  height: 15px;
  vertical-align: middle;
  margin-bottom: 0.75em;
`;

const selectionIndicator = styled.div`
  &:before {
    content: '\2022';
    color: orange
    padding-right: 5px;
    font-size: 33px;
    line-height: 2px;
    position: relative;
    top: 6px;
    visibility: hidden;

  }
`;

class LeftNavDetails extends React.Component {
  getCommandType = () => {
    const history = _.get(this.props, 'history', null);
    if (_.get(history, 'location.pathname', '') === '/results/contracts/details') {
      return 'Contract';
    }
    if (_.get(history, 'location.pathname', '') === '/results/office/details') {
      return 'Office';
    }
    return '';
  };


  render() {
    return (
      <div className="container-fluid d-flex bg-light">
        {/* {this.loadComponentDetails()} */}
        <LeftNavigationResult commandType={this.getCommandType()} NavDetails={this.props.item}  />
      </div>
    );
  }
}

LeftNavDetails.propTypes = {
  getCommandType: PropTypes.string,
  item: PropTypes.object,
};

const mapStateToProps = state => ({
  getCommandType: getCommandType(state),
});
export default connect(
  mapStateToProps,
  null,
)(LeftNavDetails);
