import React from 'react';
import { withRouter, BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import styled from 'styled-components';
import 'bootstrap/dist/css/bootstrap.css';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import ContractDetails from '../ContractsDetails';
import ContractsAdditionalDetails from '../ContractsAdditionalDetails';
import OfficesDemographicsDetails from '../OfficesDemographicsDetails';
import OfficesAdditionalDetails from '../OfficesAdditionalDetails';
import ContentView from '../../components/ContentView';
import { getCommandType, getPost } from './selector';
import './DetailsStyles.css';
import './LeftNavStyles.scss';
import { Resizable } from 're-resizable';

const MainTitle = styled.h5`
  text-align: left;
  font-size: 1em;
  color: grey;
  padding-top: 0.75em;
  margin-top: 0.75em;
  margin-left: 0.75em;
  vertical-align: middle;
`;

const Title = styled.h5`
  color: black;
  text-align: left;
  justify-content: center;
  font-size: 0.9em;
  color: grey;
  margin-left: 1.5em;
  height: 15px;
  vertical-align: middle;
  margin-bottom: 0.75em;
`;

export const ProviderContractList = [
  {
    Category: 'PROPERTIES',
    CategoryType: 'PROPERTIES',
    items: [{ NavTitle: 'Details', id: 11 }, { NavTitle: 'Additional Details', id: 12 }],
  },
  {
    Category: 'MAPPINGS',
    CategoryType: 'MAPPINGS',
    items: [
      { NavTitle: 'Fee Schedules', id: 13 },
      { NavTitle: 'Reimbursments', id: 14 },
      { NavTitle: 'Denial Categories', id: 15 },
      { NavTitle: 'Attachments', id: 16 },
      { NavTitle: 'Ambulatory Procedure Code', id: 17 },
      { NavTitle: 'Grouping Exceptions', id: 19 },
    ],
  },
  {
    Category: 'RELATED ITEMS',
    CategoryType: 'RELATED ITEMS',
    items: [
      { NavTitle: 'Providers', id: 20 },
      { NavTitle: 'Service Restriction Packages', id: 21 },
      { NavTitle: 'History', id: 22 },
    ],
  },
];

export const ProviderOfficesList = [
  {
    Category: 'PROPERTIES',
    CategoryType: 'PROPERTIES',
    items: [{ NavTitle: 'Demographics', id: 1 }, { NavTitle: 'Additional Details', id: 2 }],
  },
  {
    Category: 'MAPPINGS',
    CategoryType: 'MAPPINGS',
    items: [
      { NavTitle: 'Contracts', id: 3 },
      { NavTitle: 'Additional Contracts', id: 4 },
      { NavTitle: 'Additional Services', id: 5 },
      { NavTitle: 'Alternate Addresses', id: 6 },
      { NavTitle: 'Attachment', id: 7 },
      { NavTitle: 'DRG Facility Weights', id: 8 },
      { NavTitle: 'Languages', id: 9 },
      { NavTitle: 'Events', id: 10 },
      { NavTitle: 'Fulfilment', id: 13 },
    ],
  },
  {
    Category: 'RELATED ITEMS',
    CategoryType: 'RELATED ITEMS',
    items: [{ NavTitle: 'Claims', id: 12 }],
  },
];

class LeftNavigationResult extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      Details: false,
      AdditionalDetails: false,
      OfficeDemographics: false,
      OfficeAdditionalDetails: false,
      isShow: true,
      classNameHighlight: 0,
      defaultClassHightlight: true,
      width: '100%',
      height: 260,
    };
  }

  showDetails = () => {
    if (this.props.commandType === 'Contract') {
      return <ContractDetails NavDetails={this.props.getPost} />;
    }
    if (this.props.commandType === 'Office') {
      return <OfficesDemographicsDetails NavDetails={this.props.getPost} />;
    }
  };

  // componentDidUpdate = () => {
  //   this.showDetails();
  // };

  click(key, index) {
    // alert(key
    // debugger;
    console.log(index, 'indexval');
    this.setState({ isShow: false, classNameHighlight: key, defaultClassHightlight: false });
    if (key === 11) {
      this.setState({
        Details: true,
        AdditionalDetails: false,
        OfficeDemographics: false,
        OfficeAdditionalDetails: false,
      });
    }
    if (key === 12) {
      this.setState({
        Details: false,
        AdditionalDetails: true,
        OfficeDemographics: false,
        OfficeAdditionalDetails: false,
      });
    }
    if (key === 1) {
      this.setState({
        Details: false,
        AdditionalDetails: false,
        OfficeDemographics: true,
        OfficeAdditionalDetails: false,
      });
    }
    if (key === 2) {
      this.setState({
        Details: false,
        AdditionalDetails: false,
        OfficeDemographics: false,
        OfficeAdditionalDetails: true,
      });
    }
  }

  currentLeftNavList = () => {
    if (this.props.commandType === 'Contract') {
      return ProviderContractList;
    }
    if (this.props.commandType === 'Office') {
      return ProviderOfficesList;
    }
  };

  componentDidUpdate() {}

  render() {
    const {
      Details,
      AdditionalDetails,
      OfficeDemographics,
      OfficeAdditionalDetails,
      classNameHighlight,
      defaultClassHightlight,
    } = this.state;
    const navlist = this.currentLeftNavList();
    return (
      <div className="container-fluid d-flex bg-light">
        {/* <div className="row"> */}
        <div className="col-2 p-0 border ">
          <nav id="sidebar bd-sidebar">
            {navlist.map(({ CategoryType, Category, items: subItems, ...rest }) => (
              <ul className="list-unstyled" key={CategoryType} {...rest}>
                <MainTitle>{Category}</MainTitle>
                {subItems.map(({ NavTitle, navPath, id }) => (
                  <li
                    key={id}
                    className={
                      classNameHighlight === id ||
                      (id === 11 && defaultClassHightlight === true) ||
                      (id === 1 && defaultClassHightlight === true)
                        ? 'borderlist activeOrangelist'
                        : 'borderlist'
                    }
                    onClick={this.click.bind(this, id)}
                  >
                    <Title className="List-Item">
                      <Link style={{ textDecoration: 'none', color: 'black' }} to={navPath}>
                        {NavTitle}
                      </Link>
                    </Title>
                  </li>
                ))}
              </ul>
            ))}
          </nav>
        </div>
        <div className="col-10 py-3 p-3 border">
          <Resizable
            className="resizable-container"
            size={{ width: this.state.width, height: this.state.height }}
            onResizeStop={(e, direction, ref, d) => {
              this.setState({
                width: this.state.width,
                height: this.state.height + d.height < 500 ? this.state.height + d.height : 500,
              });
            }}
          >
            <div className="w-100">
              <ContentView NavDetails={this.props.getPost} CommandType={this.props.commandType} />
            </div>
          </Resizable>
          <div className="resize-drag"></div>
          <div className="resize-drag pt-1"></div>
          {this.state.isShow === true ? this.showDetails() : null}
          {Details === true ? <ContractDetails NavDetails={this.props.getPost} /> : null}
          {AdditionalDetails === true ? <ContractsAdditionalDetails NavDetails={this.props.getPost} /> : null}
          {OfficeDemographics === true ? (
            <OfficesDemographicsDetails NavDetails={this.props.getPost} />
          ) : null}
          {OfficeAdditionalDetails === true ? (
            <OfficesAdditionalDetails NavDetails={this.props.getPost} />
          ) : null}
        </div>
      </div>
    );
  }
}

LeftNavigationResult.propTypes = {
  getPost: PropTypes.string,
  getCommandType: PropTypes.string,
  commandType: PropTypes.string,
};

const mapStateToProps = state => ({
  getCommandType: getCommandType(state),

  getPost: getPost(state),
});
export default connect(
  mapStateToProps,
  null,
)(LeftNavigationResult);
