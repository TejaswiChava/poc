import _ from 'lodash';

// const getContracts = state => _.get(state, 'getContracts.data.contractsDTO', []);
// const getCommandType = state => _.get(state, 'commandType', '');
const getCommandType = state => {
  const routePath = _.get(state, 'router.location.pathname', '');
  return _.isEqual(routePath, '/results/office') ? 'Office' : 'Contract';
};
const getPost = state => _.get(state, 'clickedRowItem', null);
  
export { getCommandType, getPost};
