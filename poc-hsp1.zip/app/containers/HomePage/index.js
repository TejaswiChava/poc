/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 */

import React, { useEffect, memo } from 'react';

import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';

import { connect } from 'react-redux';
import { compose } from 'redux';

import { getSessionId } from '../../components/Header/selectors';

import CenteredSection from './CenteredSection';
import Section from './Section';

import {
  getConnectUserRequest,
  getFindCommandsRequest,
  getFindProfilesRequest,
  getFindControlRequest,
  getLinkedDropDownValuesRequest,
  getReferenceCodesRequest,
  getContractsRequest,
  getOfficesRequest,
  getListViewProfileSettingsRequest,
  getUserListViewSettingsRequest,
  getUserReportsRequest,
  getXMLStyleSheetRequest,
  getUserOptionsRequest,
  setUserOptionsRequest,
  getDisconnectUserRequest,
  checkPermissionRequest,
  getBenefitStructuresRequest,
  addUserListviewSettingRequest,
  updateUserListviewSettingRequest,
} from './actions';

import {
  mockConnectUserRequestData,
  mockGetFindCommandsRequestParam,
  mockFindProfilesRequestData,
  mockFindControlRequestData,
  mockGetDropDownValuesRequestParams,
  mockGetDropDownValuesRequestParams2,
  mockGetReferenceCodesRequestParams,
  mockGetReferenceCodesRequestParams2,
  mockContractsRequestParam,
  mockOfficesRequestParam,
  mockOfficesErrorRequestParam,
  mockgetListViewProfileSettingsRequestData,
  mockgetUserListViewSettingsRequestData,
  mockGetUserReportsRequestParam,
  mockGetXMLStyleSheetRequestData,
  mockGetUserOptionsRequestParam,
  mockGetUserOptionsRequestParam2,
  mockGetUserOptionsRequestParam3,
  mockSetUserOptionsRequestParam,
  mockGetDisconnectUser,
  mockCheckPermission,
  mockCheckPermission2,
  mockGetBenefitStructuresData,
  mockgetListViewProfileSettingsRequestData2,
  mockAddUserListviewSettingRequestParam,
  mockUpdateUserListviewSettingRequestParam,
} from './mockData';

export function HomePage({
  getConnectUser,
  getFindCommands,
  getFindProfiles,
  getFindControl,
  getLinkedDropDownValues,
  getReferenceCodes,
  getContracts,
  getOffices,
  getListViewProfileSettings,
  getUserListViewSettings,
  getUserReports,
  getXMLStyleSheet,
  getUserOptions,
  setUserOptions,
  getDisconnectUser,
  checkPermission,
  getBenefitStructures,
  addUserListviewSetting,
  updateUserListviewSetting,
  sessionId,
}) {
  // useInjectReducer({ key, reducer });
  // useInjectSaga({ key, saga });

  useEffect(() => {
    // getConnectUser(mockConnectUserRequestData);
    // getFindCommands(mockGetFindCommandsRequestParam);
    // getFindProfiles(mockFindProfilesRequestData);
    // getFindControl(mockFindControlRequestData);
    // getLinkedDropDownValues(mockGetDropDownValuesRequestParams);
    // setTimeout(() => {
    //   getLinkedDropDownValues(mockGetDropDownValuesRequestParams2);
    // }, 4000);
    // getReferenceCodes(mockGetReferenceCodesRequestParams);
    // setTimeout(() => {
    //   getReferenceCodes(mockGetReferenceCodesRequestParams2);
    // }, 4000);
    // getContracts(mockContractsRequestParam);
    // getOffices(mockOfficesRequestParam);
    // setTimeout(() => {
    //   getOffices(mockOfficesErrorRequestParam);
    // }, 4000);
    // getListViewProfileSettings(mockgetListViewProfileSettingsRequestData);
    // setTimeout(() => {
    //   getListViewProfileSettings(mockgetListViewProfileSettingsRequestData2);
    // }, 4000);
    // getUserListViewSettings(mockgetUserListViewSettingsRequestData);
    // getUserReports(mockGetUserReportsRequestParam);
    // getXMLStyleSheet(mockGetXMLStyleSheetRequestData);
    // getUserOptions(mockGetUserOptionsRequestParam);
    // setTimeout(() => {
    //   getUserOptions(mockGetUserOptionsRequestParam2);
    // }, 4000);
    // setTimeout(() => {
    //   getUserOptions(mockGetUserOptionsRequestParam3);
    // }, 6000);
    // setUserOptions(mockSetUserOptionsRequestParam);
    // getDisconnectUser(mockGetDisconnectUser);
    // checkPermission(mockCheckPermission);
    // setTimeout(() => {
    //   checkPermission(mockCheckPermission2);
    // }, 4000);
    // getBenefitStructures(mockGetBenefitStructuresData);
    // addUserListviewSetting(mockAddUserListviewSettingRequestParam);
    // setTimeout(() => {
    //   const mockUpdateUserListviewSettingRequestParam1 = {
    //     SessionId: sessionId,
    //     UserListviewSettingId: '3033',
    //     ColumnSettings:
    //       '<?xml version="1.0"?><Settings><Columns><Column><Name>#</Name><Location>0</Location><Width>31</Width></Column><Column><Name>OfficeNumber</Name><Location>1</Location><Width>83</Width></Column><Column><Name>OfficeName</Name><Location>2</Location><Width>92</Width></Column><Column><Name>Address1</Name><Location>3</Location><Width>108</Width></Column><Column><Name>Address2</Name><Location>4</Location><Width>116</Width></Column><Column><Name>City</Name><Location>5</Location><Width>80</Width></Column><Column><Name>PreferredCity</Name><Location>7</Location><Width>84</Width></Column><Column><Name>State</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Zip</Name><Location>6</Location><Width>94</Width></Column><Column><Name>County</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Region</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactPhone</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactExt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactFax</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NPI</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Distance</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WheelchairAccess</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AvailableAfterHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TotalOfficeHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NumberOfPhysicians</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FacilityOperatingNumber</Name><Location>6</Location><Width>94</Width></Column><Column><Name>PermanentFacilityID</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AccessCode</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContractingProviderName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ShowInWebDirectory</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedAt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedBy</Name><Location>6</Location><Width>94</Width></Column></Columns></Settings>',
    //   };
    //   if (sessionId) {
    //     updateUserListviewSetting(mockUpdateUserListviewSettingRequestParam1);
    //   }
    // }, 2000);
  }, []);

  return (
    <article>
      <Helmet>
        <title>Home Page</title>
        <meta name="description" content="Conduent HSP" />
      </Helmet>
      <div>
        <CenteredSection>
          <h2>Home</h2>
        </CenteredSection>
        <Section />
      </div>
    </article>
  );
}

HomePage.propTypes = {
  getConnectUser: PropTypes.func,
  getFindCommands: PropTypes.func,
  getFindProfiles: PropTypes.func,
  getFindControl: PropTypes.func,
  getLinkedDropDownValues: PropTypes.func,
  getReferenceCodes: PropTypes.func,
  getContracts: PropTypes.func,
  getOffices: PropTypes.func,
  getListViewProfileSettings: PropTypes.func,
  getUserListViewSettings: PropTypes.func,
  getUserReports: PropTypes.func,
  getXMLStyleSheet: PropTypes.func,
  getUserOptions: PropTypes.func,
  setUserOptions: PropTypes.func,
  getDisconnectUser: PropTypes.func,
  checkPermission: PropTypes.func,
  getBenefitStructures: PropTypes.func,
  addUserListviewSetting: PropTypes.func,
  sessionId: PropTypes.string,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
});

export function mapDispatchToProps(dispatch) {
  return {
    getConnectUser: requestParams => dispatch(getConnectUserRequest(requestParams)),
    getFindCommands: requestParams => dispatch(getFindCommandsRequest(requestParams)),
    getFindProfiles: requestParams => dispatch(getFindProfilesRequest(requestParams)),
    getFindControl: requestParams => dispatch(getFindControlRequest(requestParams)),
    getLinkedDropDownValues: requestParams => dispatch(getLinkedDropDownValuesRequest(requestParams)),
    getReferenceCodes: requestParams => dispatch(getReferenceCodesRequest(requestParams)),
    getContracts: requestParams => dispatch(getContractsRequest(requestParams)),
    getOffices: requestParams => dispatch(getOfficesRequest(requestParams)),
    getListViewProfileSettings: requestParams => dispatch(getListViewProfileSettingsRequest(requestParams)),
    getUserListViewSettings: requestParams => dispatch(getUserListViewSettingsRequest(requestParams)),
    getUserReports: requestParams => dispatch(getUserReportsRequest(requestParams)),
    getXMLStyleSheet: requestParams => dispatch(getXMLStyleSheetRequest(requestParams)),
    getUserOptions: requestParams => dispatch(getUserOptionsRequest(requestParams)),
    setUserOptions: requestParams => dispatch(setUserOptionsRequest(requestParams)),
    getDisconnectUser: requestParams => dispatch(getDisconnectUserRequest(requestParams)),
    checkPermission: requestParams => dispatch(checkPermissionRequest(requestParams)),
    getBenefitStructures: requestParams => dispatch(getBenefitStructuresRequest(requestParams)),
    addUserListviewSetting: requestParams => dispatch(addUserListviewSettingRequest(requestParams)),
    updateUserListviewSetting: requestParams => dispatch(updateUserListviewSettingRequest(requestParams)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(HomePage);
