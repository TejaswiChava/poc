/*
 * Home Actions
 *
 *
 * To add a new Action:
 * 1) Import your constant
 * 2) Add a function like this:
 *    export function yourAction(var) {
 *        return { type: YOUR_ACTION_CONSTANT, var: var }
 *    }
 */

import { CHANGE_USERNAME } from './constants';

/**
 * Changes the input field of the form
 *
 * @param  {string} username The new text of the input field
 *
 * @return {object} An action object with a type of CHANGE_USERNAME
 */
export function changeUsername(username) {
  return {
    type: CHANGE_USERNAME,
    username,
  };
}

// ConnectUser API

export function getConnectUserRequest(input) {
  return { type: 'CONNECT_USER_REQUEST', input };
}

export function getConnectUserSuccess(data) {
  return { type: 'CONNECT_USER_SUCCESS', data };
}

export function getConnectUserFailure(error) {
  return { type: 'CONNECT_USER_FAILURE', error };
}

// CheckPermission API

export function checkPermissionRequest(input) {
  return { type: 'CHECK_PERMISSION_REQUEST', input };
}

export function checkPermissionSuccess(data, entityType) {
  return { type: 'CHECK_PERMISSION_SUCCESS', data, entityType };
}

export function checkPermissionFailure(error, entityType) {
  return { type: 'CHECK_PERMISSION_FAILURE', error, entityType };
}

// GetFindCommands API

export function getFindCommandsRequest(input) {
  return { type: 'FIND_COMMAND_REQUEST', input };
}

export function getFindCommandsSuccess(data) {
  return { type: 'FIND_COMMAND_SUCCESS', data };
}

export function getFindCommandsFailure(error) {
  return { type: 'FIND_COMMAND_FAILURE', error };
}

// GetFindProfiles API

export function getFindProfilesRequest(input) {
  return { type: 'GET_FIND_PROFILES_REQUEST', input };
}

export function getFindProfilesSuccess(data) {
  return { type: 'GET_FIND_PROFILES_SUCCESS', data };
}

export function getFindProfilesFailure(error) {
  return { type: 'GET_FIND_PROFILES_FAILURE', error };
}

// GetFindControl API

export function getFindControlRequest(input) {
  return { type: 'FIND_CONTROL_REQUEST', input };
}

export function getFindControlSuccess(data) {
  return { type: 'FIND_CONTROL_SUCCESS', data };
}

export function getFindControlFailure(error) {
  return { type: 'FIND_CONTROL_FAILURE', error };
}

// GetLinkedDropDownValues API

export function getLinkedDropDownValuesRequest(input, key) {
  return { type: 'DROPDOWN_VALUES_REQUEST', input, key };
}

export function getLinkedDropDownValuesSuccess(data, key) {
  return { type: 'DROPDOWN_VALUES_SUCCESS', data, key };
}

export function getLinkedDropDownValuesFailure(error, key) {
  return { type: 'DROPDOWN_VALUES_FAILURE', error, key };
}

// ReferenceCodes API

export function getReferenceCodesRequest(input, refType) {
  return { type: 'REFERENCE_CODES_REQUEST', input, refType };
}

export function getReferenceCodesSuccess(data, refType) {
  return { type: 'REFERENCE_CODES_SUCCESS', data, refType };
}

export function getReferenceCodesFailure(error, refType) {
  return { type: 'REFERENCE_CODES_FAILURE', error, refType };
}

export function clearTableData(input) {
  return { type: 'CLEAR_TABLE_DATA', input };
}

// GetContracts API

export function getContractsRequest(input) {
  return { type: 'GET_CONTRACTS_REQUEST', input };
}

export function getContractsSuccess(data) {
  return { type: 'GET_CONTRACTS_SUCCESS', data };
}

export function getContractsFailure(error) {
  return { type: 'GET_CONTRACTS_FAILURE', error };
}

// GetOffices API

export function getOfficesRequest(input) {
  return { type: 'OFFICES_REQUEST', input };
}

export function getOfficesSuccess(data) {
  return { type: 'OFFICES_SUCCESS', data };
}

export function getOfficesFailure(error) {
  return { type: 'OFFICES_FAILURE', error };
}
// GetListViewProfileSettings API

export function getListViewProfileSettingsRequest(input) {
  return { type: 'GET_LIST_VIEW_PROFILE_SETTINGS_REQUEST', input };
}

export function getListViewProfileSettingsSuccess(data) {
  return { type: 'GET_LIST_VIEW_PROFILE_SETTINGS_SUCCESS', data };
}

export function getListViewProfileSettingsFailure(error) {
  return { type: 'GET_LIST_VIEW_PROFILE_SETTINGS_FAILURE', error };
}

// GetUserListViewSettings API

export function getUserListViewSettingsRequest(input) {
  return { type: 'GET_USER_LIST_VIEW_SETTINGS_REQUEST', input };
}

export function getUserListViewSettingsSuccess(data) {
  return { type: 'GET_USER_LIST_VIEW_SETTINGS_SUCCESS', data };
}

export function getUserListViewSettingsFailure(error) {
  return { type: 'GET_USER_LIST_VIEW_SETTINGS_FAILURE', error };
}

// GetUserReports API

export function getUserReportsRequest(input) {
  return { type: 'GET_USER_REPORT_REQUEST', input };
}

export function getUserReportsSuccess(data) {
  return { type: 'GET_USER_REPORT_SUCCESS', data };
}

export function getUserReportsFailure(error) {
  return { type: 'GET_USER_REPORT_FAILURE', error };
}

// GetXMLStyleSheet API

export function getXMLStyleSheetRequest(input) {
  return { type: 'GET_XML_STYLESHEET_REQUEST', input };
}

export function getXMLStyleSheetSuccess(data) {
  return { type: 'GET_XML_STYLESHEET_SUCCESS', data };
}

export function getXMLStyleSheetFailure(error) {
  return { type: 'GET_XML_STYLESHEET_FAILURE', error };
}

// GetUserOptions API

export function getUserOptionsRequest(input, key) {
  return { type: 'GET_USER_OPTIONS_REQUEST', input, key };
}

export function getUserOptionsSuccess(data, key, formProps) {
  return { type: 'GET_USER_OPTIONS_SUCCESS', data, key, formProps };
}

export function getUserOptionsFailure(error, key) {
  return { type: 'GET_USER_OPTIONS_FAILURE', error, key };
}

// SetUserOptions API

export function setUserOptionsRequest(input) {
  return { type: 'SET_USER_OPTIONS_REQUEST', input };
}

export function setUserOptionsSuccess(data) {
  return { type: 'SET_USER_OPTIONS_SUCCESS', data };
}

export function setUserOptionsFailure(error) {
  return { type: 'SET_USER_OPTIONS_FAILURE', error };
}

// DisconnectUser API

export function getDisconnectUserRequest(input) {
  return { type: 'DISCONNECT_USER_REQUEST', input };
}

export function getDisconnectUserSuccess(data) {
  return { type: 'DISCONNECT_USER_SUCCESS', data };
}

export function getDisconnectUserFailure(error) {
  return { type: 'DISCONNECT_USER_FAILURE', error };
}

// GetBenefitStructures API

export function getBenefitStructuresRequest(input) {
  return { type: 'BENEFIT_STRUCTURE_REQUEST', input };
}

export function getBenefitStructuresSuccess(data) {
  return { type: 'BENEFIT_STRUCTURE_SUCCESS', data };
}

export function getBenefitStructuresFailure(error) {
  return { type: 'BENEFIT_STRUCTURE_FAILURE', error };
}

// AddUserListviewSetting API
export function addUserListviewSettingRequest(input) {
  return { type: 'ADD_USER_LISTVIEW_SETTING_REQUEST', input };
}

export function addUserListviewSettingSuccess(data) {
  return { type: 'ADD_USER_LISTVIEW_SETTING_SUCCESS', data };
}

export function addUserListviewSettingFailure(error) {
  return { type: 'ADD_USER_LISTVIEW_SETTING_FAILURE', error };
}

// UpdateUserListviewSetting API
export function updateUserListviewSettingRequest(input) {
  return { type: 'UPDATE_USER_LISTVIEW_SETTING_REQUEST', input };
}

export function updateUserListviewSettingSuccess(data) {
  return { type: 'UPDATE_USER_LISTVIEW_SETTING_SUCCESS', data };
}

export function updateUserListviewSettingFailure(error) {
  return { type: 'UPDATE_USER_LISTVIEW_SETTING_FAILURE', error };
}
