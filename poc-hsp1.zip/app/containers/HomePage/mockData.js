export const mockConnectUserRequestData = {
  username: 'C5110547',
  password: 'admin@12345',
  appName: 'Meditrac',
  version: '10.07.0.HSP.0.0.173',
  computerName: '',
  licenseMode: 'db',
  numberOfLicensedSeats: '1',
};

export const mockGetFindCommandsRequestParam = {
  sessionId: '124',
  usage: '|ByFindCommand|',
  findCommand: 'Contract',
};

// export const mockFindProfilesRequestData = {
//   sessionId: '124',
//   findCommandId: '85',
//   usage: '|ForFindCommand|',
// };

export const mockFindControlRequestData = {
  sessionId: '124',
  findCommand: 'Contract',
  findProfileId: '0',
  usage: '|ByFindCommand|',
};

export const mockGetDropDownValuesRequestParams = {
  spQuery: "exec ee_GetBenefitStructures @SessionID=124, @Usage='|USAGE2|', @Type='RBI'",
  staticColumnName: 'Name',
  dynamicColumnName: 'StructureID',
};

export const mockGetDropDownValuesRequestParams2 = {
  spQuery:
    "exec ee_GetReferenceCodes_V2 @SessionID=124, @AllowCheckout='N', @Type='REGION', @Usage='|USAGE2|'",
  staticColumnName: 'Name',
  dynamicColumnName: 'Code',
};

export const mockGetReferenceCodesRequestParams = {
  SessionId: '124',
  Type: 'RESULTCOUNT',
  SubType: 'RESULTCOUNT',
  Usage: '|USAGE2|',
  AllowCheckout: 'N',
};

export const mockGetReferenceCodesRequestParams2 = {
  SessionId: '124',
  Type: 'LANGUAGE',
  Usage: '|USAGE2|',
  AllowCheckout: 'N',
};

export const mockContractsRequestParam = {
  sessionID: '124',
  usage: '|USAGE2|',
  contractName: 'hsp',
};

export const mockOfficesRequestParam = {
  SessionId: '124',
  OfficeName: 'c',
  Usage: '|SEARCH|',
};

export const mockOfficesErrorRequestParam = {
  SessionId: '124',
  Usage: '|SEARCH|',
};

export const mockgetListViewProfileSettingsRequestData = {
  sessionId: '124',
  listviewName: 'Contract',
  listviewProfileId: '0',
  usage: '|ForListview|',
};

export const mockgetListViewProfileSettingsRequestData2 = {
  sessionId: '124',
  listviewName: 'Office',
  listviewProfileId: '0',
  usage: '|ForListview|',
};

export const mockgetUserListViewSettingsRequestData = {
  sessionId: '124',
  formName: 'FindForm',
  listView: 'lvwResult',
  storedProcedure: 'ee_GetContracts',
};

export const mockgetUserListViewSettingsRequestData2 = {
  sessionId: '124',
  formName: 'FindForm',
  listView: 'lvwResult',
  storedProcedure: 'ee_GetOffices_v2',
};

export const mockGetUserReportsRequestParam = {
  sessionID: '124',
  usage: '|BYCATEGORYCODE|',
  categoryCode: 'OP',
};

export const mockGetXMLStyleSheetRequestData = {
  SPName: 'ee_getcontractprofile_xml',
  XSLTPath: 'ContractProfile.xsl',
  sessionId: '124',
  contractid: '23',
};

export const mockGetUserOptionsRequestParam = {
  userID: '267',
  itemType: 'ContractHistory',
};

export const mockGetUserOptionsRequestParam2 = {
  userID: '267',
  itemType: 'ContractSearch',
};

export const mockGetUserOptionsRequestParam3 = {
  userID: '267',
  itemType: 'OfficeSearch',
};

// export const mockSetUserOptionsRequestParam = {
//   userID: '267',
//   itemType: 'OfficeSearch',
//   itemValue: '[{"EntityId":"29", "EntityName":"HSP Extended Contract"}]',
//   addedTime: '2020-04-09T11:47:30.085Z',
// };

export const mockSetUserOptionsRequestParam = {
  userID: '267',
  itemType: 'OfficeSearch',
  itemValue:
    '{"OfficeNumber":"hsp001Office","OfficeName":"hspOffice","Address1":"AddressOffice1","City":"CictyOffice1","Region":"MNY","Zip":"100036","Distance":"34","State":"NY","County":"ALBANY","Language":"Abkhazian","ContactPhone":"89888789","NPI":"123","AdditionalService":"ANE","WheelchairAccess":"Y","ResultCount":"50"}',
  addedTime: '2020-04-09T11:47:30.085Z',
};

// export const mockSetUserOptionsRequestParam = {
//   userID: '267',
//   itemType: 'ContractSearch',
//   itemValue:
//     '{"ContractName":"mckContact","ContractNumber":"mockCon001","AsOfDate":"","ReimbursementID":"2145","ResultCount":"1K"}',
//   addedTime: '2020-04-09T11:47:30.085Z',
// };

export const mockGetDisconnectUser = {
  sessionID: '4283',
};

export const mockCheckPermission = {
  SessionId: 124,
  EntityType: 'Contracts',
  Usage: 'USAGE1',
  PermissionName: 'View Template',
  ProductName: 'Meditrac',
};

export const mockCheckPermission2 = {
  SessionId: 124,
  EntityType: 'Offices',
  Usage: 'USAGE1',
  PermissionName: 'View Template',
  ProductName: 'Meditrac',
};

export const mockGetBenefitStructuresData = {
  sessionID: '124',
  type: 'RBI',
  usage: '|Usage2|',
};

export const mockAddUserListviewSettingRequestParam = {
  sessionId: '4431',
  FormName: 'FindForm',
  ListView: 'lvwResult',
  StoredProcedure: ' ee_GetOffices_v2',
  ColumnSettings:
    '<?xml version="1.0"?><Settings><Columns><Column><Name>#</Name><Location>0</Location><Width>31</Width></Column><Column><Name>OfficeNumber</Name><Location>1</Location><Width>83</Width></Column><Column><Name>OfficeName</Name><Location>2</Location><Width>92</Width></Column><Column><Name>Address1</Name><Location>3</Location><Width>108</Width></Column><Column><Name>Address2</Name><Location>4</Location><Width>116</Width></Column><Column><Name>City</Name><Location>5</Location><Width>80</Width></Column><Column><Name>PreferredCity</Name><Location>7</Location><Width>84</Width></Column><Column><Name>State</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Zip</Name><Location>6</Location><Width>94</Width></Column><Column><Name>County</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Region</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactPhone</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactExt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactFax</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NPI</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Distance</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WheelchairAccess</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AvailableAfterHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TotalOfficeHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NumberOfPhysicians</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FacilityOperatingNumber</Name><Location>6</Location><Width>94</Width></Column><Column><Name>PermanentFacilityID</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AccessCode</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContractingProviderName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ShowInWebDirectory</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedAt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedBy</Name><Location>6</Location><Width>94</Width></Column></Columns></Settings>',
};

export const mockUpdateUserListviewSettingRequestParam = {
  SessionId: '4431',
  UserListviewSettingId: '3033',
  ColumnSettings:
    '<?xml version="1.0"?><Settings><Columns><Column><Name>#</Name><Location>0</Location><Width>31</Width></Column><Column><Name>OfficeNumber</Name><Location>1</Location><Width>83</Width></Column><Column><Name>OfficeName</Name><Location>2</Location><Width>92</Width></Column><Column><Name>Address1</Name><Location>3</Location><Width>108</Width></Column><Column><Name>Address2</Name><Location>4</Location><Width>116</Width></Column><Column><Name>City</Name><Location>5</Location><Width>80</Width></Column><Column><Name>PreferredCity</Name><Location>7</Location><Width>84</Width></Column><Column><Name>State</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Zip</Name><Location>6</Location><Width>94</Width></Column><Column><Name>County</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Region</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactPhone</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactExt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContactFax</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NPI</Name><Location>6</Location><Width>94</Width></Column><Column><Name>Distance</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WheelchairAccess</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AvailableAfterHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TotalOfficeHours</Name><Location>6</Location><Width>94</Width></Column><Column><Name>NumberOfPhysicians</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FacilityOperatingNumber</Name><Location>6</Location><Width>94</Width></Column><Column><Name>PermanentFacilityID</Name><Location>6</Location><Width>94</Width></Column><Column><Name>AccessCode</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ContractingProviderName</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SundayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>MondayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>TuesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>WednesdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ThursdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>FridayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayStart</Name><Location>6</Location><Width>94</Width></Column><Column><Name>SaturdayEnd</Name><Location>6</Location><Width>94</Width></Column><Column><Name>ShowInWebDirectory</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedAt</Name><Location>6</Location><Width>94</Width></Column><Column><Name>LastUpdatedBy</Name><Location>6</Location><Width>94</Width></Column></Columns></Settings>',
};
