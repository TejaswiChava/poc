import * as yup from 'yup';
import _ from 'lodash';

export const createYupSchema = (schemas, config) => {
  const schema = schemas;
  const { id, validationType, validations = [] } = config;
  if (!yup[validationType]) {
    return schema;
  }
  let validator = yup[validationType]();
  validations.forEach(validation => {
    const { params, type } = validation;
    if (!validator[type]) {
      return;
    }

    validator = validator[type](...params);
  });
  schema[id] = validator;
  return schema;
};

export const getParamValueFromSQL = (sqlParams, paramName) => {
  if (!sqlParams) {
    return '';
  }
  const regex = new RegExp(`@${paramName}(.*)`);
  const value = sqlParams.match(regex);
  const paramObj = value && value.length > 0 ? value[0].split(',')[0].slice() : '';
  const paramValue = paramObj ? paramObj.split('=')[1].trim() : '';
  return paramValue.substring(1, paramValue.length - 1);
};

export const getApiNameFromSQL = sqlParams => {
  if (!sqlParams) {
    return '';
  }
  const value = sqlParams.match(/exec ee_(.*)/);
  const apiName = value && value.length >= 2 ? value[1] : '';
  return apiName ? apiName.split(' ')[0].slice() : '';
};

export const setDefaultValuesOfForm = (items, formProps) => {
  if (items) {
    const defaultData = JSON.parse(items);
    Object.keys(defaultData).map(key => {
      formProps.setFieldValue(key, defaultData[key]);
    });

    formProps.submitForm();
  }
};
