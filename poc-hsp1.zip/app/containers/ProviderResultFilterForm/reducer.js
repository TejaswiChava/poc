/*
 * HomeReducer
 *
 * The reducer takes care of our data. Using actions, we can
 * update our application state. To add a new action,
 * add it to the switch statement in the reducer function
 *
 */

import _ from 'lodash';
import { arrayToObject } from '../../utils/utils';

// GetFindProfiles API

export function getFindProfilesReducer(state = null, action) {
  switch (action.type) {
    case 'GET_FIND_PROFILES_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_FIND_PROFILES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_FIND_PROFILES_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetFindControl API

export function findControlReducer(state = null, action) {
  switch (action.type) {
    case 'FIND_CONTROL_REQUEST':
      return { ...state, isLoading: true };
    case 'FIND_CONTROL_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'FIND_CONTROL_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

// GetDropDownValues API

export function getDropDownValuesReducer(state = null, action) {
  switch (action.type) {
    case 'DROPDOWN_VALUES_REQUEST':
      return { ...state, isLoading: true };
    case 'DROPDOWN_VALUES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'DROPDOWN_VALUES_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export function getAllDropDownValuesReducer(state = [], action) {
  switch (action.type) {
    case 'DROPDOWN_VALUES_SUCCESS': {
      const obj = [];
      obj[action.key] = arrayToObject(_.get(action, 'data.getCustomValues', []), 'name');

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

export const getDropDownValues = state => _.get(state, 'data.getCustomValues', null);

// GetReferenceCodes API

export function getReferenceCodesReducer(state = null, action) {
  switch (action.type) {
    case 'REFERENCE_CODES_REQUEST':
      return { ...state, isLoading: true };
    case 'REFERENCE_CODES_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'REFERENCE_CODES_FAILURE':
      return { ...state, isLoading: false, isError: true, errorMessage: action.error };
    default:
      return state;
  }
}

export function getAllReferenceCodesReducer(state = [], action) {
  switch (action.type) {
    case 'REFERENCE_CODES_SUCCESS': {
      const obj = [];
      obj[action.refType] = _.get(action, 'data.referenceCodes_V2DTOs', []);

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}

// GetUserOptions API

export function getUserOptionsReducer(state = null, action) {
  switch (action.type) {
    case 'GET_USER_OPTIONS_REQUEST':
      return { ...state, isLoading: true };
    case 'GET_USER_OPTIONS_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isError: false,
        dateFetched: new Date(),
        data: action.data,
      };
    case 'GET_USER_OPTIONS_FAILURE':
      return {
        ...state,
        isLoading: false,
        isError: true,
        errorMessage: action.error,
      };
    default:
      return state;
  }
}

export function allUserOptionsReducer(state = [], action) {
  switch (action.type) {
    case 'GET_USER_OPTIONS_SUCCESS': {
      const obj = [];
      obj[action.key] = _.get(action, 'data.itemValue', []);

      return {
        ...state,
        ...obj,
      };
    }
    default:
      return state;
  }
}
