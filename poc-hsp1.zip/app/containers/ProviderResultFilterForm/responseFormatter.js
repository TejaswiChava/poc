export const fetchInputType = (controlType, referenceCodeType) => {
  const typeMapper = {
    ToolkitTextbox: 'text',
    ToolkitDateTimePicker: 'date',
    ToolkitCombobox: !referenceCodeType ? 'select' : 'result',
    ToolkitMultiColumnCombobox: 'select',
  };

  return typeMapper[`${controlType}`] || '';
};

export const getFormattedInput = input => {
  let formattedObject = {};

  const formattedOutput = [];
  input.map(data => {
    const type = fetchInputType(data.controlType, data.referenceCodeType);
    formattedObject = {
      ...data,
      id: data.name,
      type,
      validationType: 'string',
      value: data.defaultValue === null ? '' : data.defaultValue,
      validations: [
        {
          type: 'min',
          params: [data.minLength, `${data.label} cannot be less than ${data.minLength} characters`],
        },
        {
          type:
            ['ToolkitCombobox', 'ToolkitMultiColumnCombobox'].indexOf(data.controlType) > -1 ||
            data.maxLength === 0
              ? ''
              : 'max',
          params: [data.maxLength, `${data.label} cannot be more than ${data.maxLength} characters`],
        },
        {
          type: data.required === 'Y' ? 'required' : '',
          params: [`${data.label} is required`],
        },
      ],
    };
    return formattedOutput.push(formattedObject);
  });

  return formattedOutput || [];
};
