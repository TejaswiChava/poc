import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import styled from 'styled-components';
import { withRouter } from 'react-router';

import cross from '../../images/delete-red.png';
import tick from '../../images/check-greeen.png';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import editimage from '../../images/edit-black.png';
import { getReferenceCode, getAllDropDownValues, getDropDownData } from '../ProviderResultFilterForm/selectors';

import { getUsage, getSessionId } from '../../components/Header/selectors';
import { getReferenceCodesRequest, getLinkedDropDownValuesRequest } from '../ContractsDetails/Action';


const Title = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: grey;
  margin-bottom: 0.75em;
`;
const Detail = styled.h5`
  text-align: left;
  font-size: 0.9em;
  color: black;
  margin-bottom: 2em;
`;
const Heading = styled.h5`
  text-align: left;
  margin-bottom: 0.75em;
  /* font-size: 0.70em;  */
  color: black;
`;

const HoursImage = styled.img`
  width: 20px;
  height: 20px;
  /* margin: 5px; */
`;

class OfficesAdditionalDetails extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const post = this.props.NavDetails;

    return (
      <div>
        <Container fluid="lg">
          <div className="form-group">
            <button className="editbtn btn-pr btn-sm float-right" type="submit">
              <img src={editimage} alt="edit" />
              Edit
            </button>
          </div>
          <Heading>Additional Office Details</Heading>
          <Row>
            <Col md={3}>
              <Title> Facility Operating Number</Title>
              <Detail>{post.facilityOperatingNumber}</Detail>
            </Col>
            <Col md={3}>
              <Title> Permanent Facility Identifier</Title>
              <Detail>{post.permanentFacilityID}</Detail>
            </Col>
            <Col md={3}>
              <Title> National Provider Identifier</Title>
              <Detail>{post.allowInvalidNPI}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title> Number of Physicians</Title>
              <Detail>{post.numberOfPhysicians}</Detail>
            </Col>
            <Col md={3}>
              <Title>Contacting Provider</Title>
              <Detail>{post.contractingProviderName}</Detail>
            </Col>
            <Col md={3}>
              <Title>Access Code</Title>
              <Detail>{post.accessCode}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Total Office Hours</Title>
              <Detail>{post.totalOfficeHours}</Detail>
            </Col>
            <Col md={3}>
              <Title>After Hours Contact Method</Title>
              {/* <Detail>{post.afterHoursContactMethod}</Detail> */}
              {this.props.getAllDropDownValues.AfterHoursContactMethod.map((item) => {
                debugger;
                if (post.afterHoursContactMethod === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title>Wheelchair Access</Title>
              {/* <Detail>{post.wheelchairAccess}</Detail> */}
              {this.props.getAllDropDownValues.wheelchairAccess.map((item) => {
                if (post.wheelchairAccess === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Allow RA Access on Web</Title>
              {/* <Detail>{post.allowRAAccessOnWeb}</Detail> */}
              {this.props.getAllDropDownValues.AllowRAAccessOnWebOffice.map((item) => {
                if (post.allowRAAccessOnWeb === item.value) {
                  return <Detail>{item.name}</Detail>
                }
              })}
            </Col>
            <Col md={3}>
              <Title>Show in Web Directory</Title>
              <Detail>{post.showInWebDirectory}</Detail>
            </Col>
            <Col md={3}>
              <Title>Allow Invalid NPI Format</Title>
              <Detail>{post.allowInvalidNPI}</Detail>
            </Col>
          </Row>
          <Row>
            <Col md={3}>
              <Title>Available After Hours</Title>
              <Detail>{post.availableAfterHours}</Detail>
            </Col>
            <Col md={3}>
              <Title>Override Duplicate Address</Title>
              <Detail>{post.overrideDuplicateAddress}</Detail>
            </Col>
          </Row>
          <Heading>Office Hours</Heading>
          <Row>
            <Row>
              {' '}
              {(post.mondayStart !== null && post.mondayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
             
            </Row>
            <Col md={2}>
              <Title>Monday</Title>
              {(post.mondayStart !== null && post.mondayEnd !== null) ? <Detail> {post.mondayStart}-{post.mondayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
            <Row>
              {' '}
              {(post.tuesdayStart !== null && post.tuesdayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Tuesday</Title>
              {(post.tuesdayStart !== null && post.tuesdayEnd !== null) ? <Detail> {post.tuesdayStart}-{post.tuesdayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
            <Row>
              {' '}
              {(post.wednesdayStart !== null && post.wednesdayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Wednesday</Title>
              {(post.wednesdayStart !== null && post.wednesdayEnd !== null) ? <Detail> {post.wednesdayStart}-{post.wednesdayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
            <Row>
              {' '}
              {(post.thursdayStart !== null && post.thursdayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Thursday</Title>
              {(post.thursdayStart !== null && post.thursdayEnd !== null) ? <Detail> {post.thursdayStart}-{post.thursdayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
            <Row>
              {' '}
              {(post.fridayStart !== null && post.fridayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Friday</Title>
              {(post.fridayStart !== null && post.fridayEnd !== null) ? <Detail> {post.fridayStart}-{post.fridayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
          </Row>
          <Row>
            <Row>
              {' '}
              {(post.saturdayStart !== null && post.saturdayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Saturday</Title>
              {(post.saturdayStart !== null && post.saturdayEnd !== null) ? <Detail> {post.saturdayStart}-{post.saturdayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
            <Row>
              {' '}
              {(post.sundayStart !== null && post.sundayEnd !== null) ?  <HoursImage src={tick} /> : <HoursImage src={cross} />}
            </Row>
            <Col md={2}>
              <Title>Sunday</Title>
              {(post.sundayStart !== null && post.sundayEnd !== null) ? <Detail> {post.sundayStart}-{post.sundayEnd}</Detail> : <Detail>-</Detail>}
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

OfficesAdditionalDetails.propTypes = {
  getReferenceCodes: PropTypes.func,
  sessionId: PropTypes.string,
  getLinkedDropDownValues: PropTypes.func,
  getAllDropDownValues: PropTypes.object,
  // getDropDownData: PropTypes.array,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  referenceCode: getReferenceCode(state),
  getUsage: getUsage(state),
  getAllDropDownValues: getAllDropDownValues(state),
  // getDropDownData: getDropDownData(state),
});


export default withRouter(
  connect(
    mapStateToProps,
  )(OfficesAdditionalDetails)
);