/* eslint-disable react/prop-types */
import React from 'react';
import _ from 'lodash';

const getNoResultFoundStyle = name => {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: window.innerHeight - 162,
        fontSize: 18,
      }}
    >
      {name}
    </div>
  );
};
const getTableHeaderDesign = name => <h5>{name}</h5>;

const ListTitle = props => {
  const name = _.get(props, 'title.name', '');
  const render = name.toLocaleLowerCase().includes('no results found')
    ? getNoResultFoundStyle(name)
    : getTableHeaderDesign(name);

  return render;
};
export default ListTitle;
