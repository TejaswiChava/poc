import React from 'react';
import Wrapper from './Wrapper';

function Footer() {
  return (
    <Wrapper style={{ justifyContent: 'center' }}>
      <section> CopyRight Conduent 2020-2021 </section>
    </Wrapper>
  );
}

export default Footer;
