import _ from 'lodash';

const getCommandType = state => _.get(state, 'commandType', '');
const getPost = state => _.get(state, 'clickedRowItem', null);
const getIsAllow = state => _.get(state, 'isAllow', true);
const getRouterHistory = state => _.get(state, 'router.location.pathname', null);
const getSessionId = state => _.get(state, 'connectUser.data.status.sessionId', null);
const getUserId = state => _.get(state, 'connectUser.data.status.userId', null);
const getCommandData = state => _.get(state, 'getFindCommands.data.findCommands[0]', null);
const getCommandId = state => _.get(state, 'getFindCommands.data.findCommands[0].findCommandId', null);
const getUsage = state => _.get(state, 'getFindCommands.data.findCommands[0].findUsage', null);

export {
  getCommandType,
  getSessionId,
  getCommandData,
  getPost,
  getIsAllow,
  getRouterHistory,
  getCommandId,
  getUserId,
  getUsage,
};
