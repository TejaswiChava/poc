export function saveCommandType(commandType) {
  return { type: 'SAVE_COMMAND_TYPE', commandType };
}

export function checkIsAllow(isAllow) {
  return { type: 'CHECK_IS_ALLOW', isAllow };
}

export default { saveCommandType, checkIsAllow };
