import React, { Component } from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { Navbar, NavDropdown, Nav, Button } from 'react-bootstrap';
import './Navbar.scss';
import logo from '../../../images/logo_blue_hsp.png';
import history from '../../../utils/history';

import { saveCommandType, checkIsAllow } from '../action';
import { getConnectUserRequest, getFindCommandsRequest } from '../../../containers/HomePage/actions';
import { getReferenceCodesRequest, getLinkedDropDownValuesRequest } from '../../../containers/ContractsDetails/Action';
import { mockConnectUserRequestData } from '../../../containers/HomePage/mockData';

import { getSessionId, getCommandType, getCommandData } from '../selectors';

const navlist = [
  { id: 1, name: 'Claims' },
  { id: 2, name: 'Enrollment' },
  { id: 3, name: 'Benefits' },
  {
    id: 4,
    name: 'Provider',
    subTitle: [
      { sid: 1, text: 'Contracts', url: '/results/contracts' },
      { sid: 2, text: 'Offices', url: '/results/office' },
    ],
  },
  { id: 5, name: 'Finance' },
  { id: 6, name: 'UM' },
  { id: 7, name: 'WorkFlow' },
  { id: 8, name: 'Tools' },
  { id: 9, name: 'Help' },
];
class NavbarHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      navlistItems: [],
      isClickedProvider: true,
    };
    this.showHeader = true;
  }

  componentDidMount() {
    if (window.performance && performance.navigation.type === 1) {
      if (history) {
        history.push('/');
      }
    }

    if (window.location.href.indexOf('ContentView') > -1) {
      this.showHeader = false;
    }
    const sessionId = _.get(this.props, 'sessionId', null);
    if (sessionId === null || sessionId === '') {
      setTimeout(() => {
        this.props.getConnectUser(mockConnectUserRequestData);
      }, 500);
    }
    this.setState({
      navlistItems: navlist,
    });
  }

  navItemClicked = (event, listItem) => {
    event.preventDefault();
    if (listItem === event && listItem.id !== 4) {
      this.setState({
        isClickedProvider: false,
      });
    }
  };

  loadDataFromAPI = commandType => {
    const sessionId = _.get(this.props, 'sessionId', null);

    if (sessionId !== null) {
      const requestParams = {
        sessionId,
        usage: '|ByFindCommand|',
        findCommand: commandType,
      };
      this.props.getFindCommands(requestParams);
    }
  };

  getRefCodeForWheelChairAccess = getUsage => {
    const post = this.props.NavDetails;
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='wheelchairAccess', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'wheelchairAccess');
    // console.log('getAllDropDownValues', this.props.getAllDropDownValues);
    console.log('wheelchairAccess', this.props.getAllDropDownValues);
    // this.props.getAllDropDownValues.wheelchairAccess.map(item => (
    //   console.log();
    // ))
  };

  getRefCodeForContractType = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='ContractType', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'ContractType');
    const getDropDownValues = state => _.get(state, 'data.getCustomValues', null);
  };

  getRefCodeForPricingMode = getUsage => {
    const post = this.props.NavDetails;
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='PRICINGMODE', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PRICINGMODE');
    // console.log('getAllDropDownValues', this.props.getAllDropDownValues);
    console.log('pricingmode', this.props.getAllDropDownValues);
  };

  // console.log(
  //   this.props.getAllDropDownValues.PRICINGMODE.map(item => {
  //     return <p>{item.value}</p>;

  //   }),
  // );
  getRefCodeForFeeScheduleCriteria = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='FeeScheduleSearchCriteria', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'FeeScheduleSearchCriteria');
    const getDropDownValues = state => _.get(state, 'data.getCustomValues', null);
  };

  getRefCodeForPaymentClass = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='PaymentClass', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PaymentClass');
    const getDropDownValues = state => _.get(state, 'data.getCustomValues', null);
  };

  getRefCodeForSuppressPayment = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='SuppressPayment', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'SuppressPayment');
  };

  getRefCodeForProviderInheritsMemberPayment = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='ProviderInheritsMemberPayment', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'ProviderInheritsMemberPayment');
  };

  getRefCodeForToPay = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='ToPay', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'ToPay');
  };

  getRefCodeForApplyCopayPerSchedule = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='ApplyCopayPerSchedule', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'ApplyCopayPerSchedule');
  };

  getRefCodeForNegotiated = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='Negotiated', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'Negotiated');
  };

  getRefCodeForMoneyLimitProcessingOrder = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='MoneyLimitProcessingOrder', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'MoneyLimitProcessingOrder');
  };

  getRefCodePreEstimateExpiration = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='UnitType', @SubType='PreEstimateExpiration' @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PreEstimateExpiration');
  };

  getRefCodePanelSizeEnforcement = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='PanelSizeEnforcement', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PanelSizeEnforcement');
  };
  getRefCodeForPanelSizeCalculationMethod = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='PanelSizeCalculationMethod', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PanelSizeCalculationMethod');
  };
  getRefCodeForPanelOverrideAllowance = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='PanelOverrideAllowance', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'PanelOverrideAllowance');
  };

  getRefCodeForState = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='State', @SubType='US', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'State');
  };
  getRefCodeForAfterHoursContactMethod = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='AfterHoursContactMethod', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'AfterHoursContactMethod');
  };

  getRefCodeForAllowRAAccessOnWebOffice = getUsage => {
    const sessionId = _.get(this.props, 'sessionId', null);
    const comboBoxSql =
      "exec ee_GetReferenceCodes_V2 @SessionID={0}, @AllowCheckout='N', @Type='AllowRAAccessOnWebOffice', @Usage='|USAGE2|'";
    const apiParams = {
      spQuery: comboBoxSql.replace('{0}', sessionId),
      staticColumnName: 'Name',
      dynamicColumnName: 'Code',
    };
    this.props.getLinkedDropDownValues(apiParams, 'AllowRAAccessOnWebOffice');
  };

loadReferenceCodeForContractsAndOffices = () =>{
  this.getRefCodeForWheelChairAccess();
  this.getRefCodeForPricingMode();
  this.getRefCodeForFeeScheduleCriteria();
  this.getRefCodeForPaymentClass();
  this.getRefCodeForSuppressPayment();
  this.getRefCodeForProviderInheritsMemberPayment();
  this.getRefCodeForToPay();
  this.getRefCodeForApplyCopayPerSchedule();
  this.getRefCodeForNegotiated();
  this.getRefCodeForMoneyLimitProcessingOrder();
  this.getRefCodePreEstimateExpiration();
  this.getRefCodePanelSizeEnforcement();
  this.getRefCodeForPanelSizeCalculationMethod();
  this.getRefCodeForPanelOverrideAllowance();
  this.getRefCodeForState();
  this.getRefCodeForAfterHoursContactMethod();
  this.getRefCodeForAllowRAAccessOnWebOffice();
}

  render() {
    const { navlistItems, isClickedProvider } = this.state;
    const commandData = _.get(this.props, 'commandData', {});
    this.loadReferenceCodeForContractsAndOffices();
    return (
      <div className={this.showHeader ? 'Nav-container' : 'HideNav-Container'}>
        <Navbar bg="light" expand="lg">
          <Navbar.Brand href="/">
            <img src={logo} alt="logo" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              {navlistItems.map(listItem => {
                if (listItem.id === 4) {
                  return (
                    <NavDropdown
                      title={listItem.name}
                      key={listItem.id}
                      className={window.location.pathname === '/' ? null : 'activeOrange'}
                    >
                      {listItem.subTitle.map(subItem => (
                        <NavDropdown.Item
                          key={subItem.sid}
                          className={window.location.pathname === subItem.url ? 'activeClass' : null}
                          onClick={event => {
                            event.preventDefault();
                            this.setState({
                              isClickedProvider: true,
                            });
                            // this.props.saveCommandType(subItem.text);
                            this.props.checkIsAllow(false);
                            this.props.saveCommandType(subItem.text === 'Contracts' ? 'Contract' : 'Office');
                            if (history) {
                              history.push(subItem.url);
                            }
                            this.loadDataFromAPI(subItem.text === 'Contracts' ? 'Contract' : 'Office');
                          }}
                        >
                          {subItem.text}
                        </NavDropdown.Item>
                      ))}
                    </NavDropdown>
                  );
                }
                return <Nav.Link key={listItem.id}>{listItem.name}</Nav.Link>;
              })}
            </Nav>
            <Button>Log Out</Button>
          </Navbar.Collapse>
        </Navbar>
      </div>
    );
  }
}

NavbarHeader.propTypes = {
  saveCommandType: PropTypes.func,
  checkIsAllow: PropTypes.func,
  getConnectUser: PropTypes.func,
  getFindCommands: PropTypes.func,
  sessionId: PropTypes.string,
  commandData: PropTypes.object,
  getCommandType: PropTypes.string,
};

const mapStateToProps = state => ({
  sessionId: getSessionId(state),
  commandData: getCommandData(state),
  getCommandType: getCommandType(state),
});
export function mapDispatchToProps(dispatch) {
  return {
    saveCommandType: commandType => dispatch(saveCommandType(commandType)),
    checkIsAllow: isAllow => dispatch(checkIsAllow(isAllow)),
    getConnectUser: requestParams => dispatch(getConnectUserRequest(requestParams)),
    getFindCommands: requestParams => dispatch(getFindCommandsRequest(requestParams)),
    getReferenceCodes: (requestParams, key) => dispatch(getReferenceCodesRequest(requestParams, key)),
    getLinkedDropDownValues: (requestParams, key) =>
      dispatch(getLinkedDropDownValuesRequest(requestParams, key)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(NavbarHeader);
