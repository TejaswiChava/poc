import _ from 'lodash';

const getXMLStyleSheet = state => _.get(state, 'getXMLStyleSheet', {});
const getUserReports = state => _.get(state, 'getUserReports.data.userReportsDTO', []);
const getCommandData = state => _.get(state, 'getFindCommands.data.findCommands[0]', null);

export { getUserReports, getXMLStyleSheet, getCommandData };
