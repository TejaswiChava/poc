import _ from 'lodash';

const getRouterHistory = state => _.get(state, 'router.location.pathname', null);

export { getRouterHistory }