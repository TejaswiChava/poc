const _ = require('lodash');
const axios = require('axios');

function GenericPutController() {}

GenericPutController.prototype.getResponseForRequest = (request, response) => {
  const path = _.get(request, 'route.path', '');

  axios
    .put(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net${path}`, request.body)
    .then(res => {
      const data = _.get(res, 'data', '');
      const statusText = _.get(res, 'statusText', '');
      const status = _.get(res, 'status', '');

      response.json({ data, ok: statusText, status });
    })
    .catch(res => {
      const data = _.get(res, 'response.data', '');
      const statusText = _.get(res, 'response.statusText', '');
      const status = _.get(res, 'response.status', '');
      response.json({ data, ok: statusText, status });
    });
};

module.exports = GenericPutController;

// Without tunnel

// GenericPutController.prototype.getResponseForRequest = (request, response) => {
//   const path = _.get(request, 'route.path', '');

//   axios
//     .put(`https://ghs-hsp-dotnet-w-service01.azurewebsites.net${path}`, request.body)
//     .then(res => {
//       const data = _.get(res, 'data', '');
//       const statusText = _.get(res, 'statusText', '');
//       const status = _.get(res, 'status', '');

//       response.json({ data, ok: statusText, status });
//     })
//     .catch(res => {
//       const data = _.get(res, 'response.data', '');
//       const statusText = _.get(res, 'response.statusText', '');
//       const status = _.get(res, 'response.status', '');
//       response.json({ data, ok: statusText, status });
//     });
// };

// With tunnel for conduent VDI only
// GenericController.prototype.getResponseForRequest = (request, response) => {
//   const path = _.get(request, 'route.path', '');
//   const agent = tunnel.httpsOverHttp({
//     proxy: {
//       host: '10.232.84.254',
//       port: 9191,
//     },
//     rejectUnauthorized: false,
//   });
//   const instance = axios.create({
//     baseURL: `https://ghs-hsp-dotnet-w-service01.azurewebsites.net:443`,
//     httpsAgent: agent,
//     proxy: false,
//   });

//   instance
//     .post(`${path}`, request.body)
//     .then(res => {
//       const data = _.get(res, 'data', '');
//       const statusText = _.get(res, 'statusText', '');
//       const status = _.get(res, 'status', '');

//       response.json({ data, ok: statusText, status });
//     })
//     .catch(res => {
//       console.log(res);
//       const data = _.get(res, 'response.data', '');
//       const statusText = _.get(res, 'response.statusText', '');
//       const status = _.get(res, 'response.status', '');
//       response.json({ data, ok: statusText, status });
//     });
// };
