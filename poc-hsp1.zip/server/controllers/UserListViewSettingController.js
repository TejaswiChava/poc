const axios = require('axios');
const _ = require('lodash');
const js2xmlparser = require('js2xmlparser');

function UserListViewController() {}

UserListViewController.prototype.listViewSetting = (request, response) => {
  var payload = request.body;
  payload.ColumnSettings = js2xmlparser
    .parse('Settings', payload.ColumnSettings)
    .replace(/(\r\n|\n|\r)/gm, '');
  axios
    .post(
      `https://ghs-hsp-dotnet-w-service01.azurewebsites.net/Workflow/EventViewer/AddUserListviewSetting`,
      payload,
    )
    .then(res => {
      const status = _.get(res, 'status', '');
    })
    .catch(res => {
      const status = _.get(res, 'response.status', '');
      response.json({ data: res.data, ok: false, status });
    });
};

UserListViewController.prototype.listViewSettingUpdate = (request, response) => {
  var payload = request.body;
  payload.ColumnSettings = js2xmlparser
    .parse('Settings', payload.ColumnSettings)
    .replace(/(\r\n|\n|\r)/gm, '');
  axios
    .put(
      `https://ghs-hsp-dotnet-w-service01.azurewebsites.net/tools/MemberLoadWizard/UpdateUserListviewSetting`,
      { headers: { 'Content-Type': 'application/json' } },
      payload,
    )
    .then(res => {
      const status = _.get(res, 'status', '');
      response.json({ data: res, ok: true, status });
    })
    .catch(res => {
      const status = _.get(res, 'response.status', '');
      response.json({ data: res, ok: false, status });
    });
};

module.exports = UserListViewController;
