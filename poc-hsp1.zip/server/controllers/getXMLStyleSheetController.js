const axios = require('axios');
const _ = require('lodash');
const cheerio = require('cheerio');
function GetXMLStyleSheetController() {}
GetXMLStyleSheetController.prototype.getXMLStyleSheet = (request, response) => {
  axios
    .post(
      `https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetXMLStyleSheet`,
      request.body,
    )
    .then(res => {
      let htmlResponse = res.data.htmlResult;
      htmlResponse = htmlResponse.toString().replace(/[^\x20-\x7E]/gim, '');
      const $ = cheerio.load(htmlResponse);
      $('base').attr('href', '/static/');
      response.json({ data: $.html(), ok: true });
    })
    .catch(res => {
      const data = _.get(res, 'response.data', '');
      const statusText = _.get(res, 'response.statusText', '');
      const status = _.get(res, 'response.status', '');
      response.json({ data, ok: statusText, status });
    });
};
module.exports = GetXMLStyleSheetController;

// GetXMLStyleSheetController.prototype.getXMLStyleSheet = (request, response) => {
//   const agent = tunnel.httpsOverHttp({
//     proxy: {
//       host: '10.232.84.254',
//       port: 9191,
//     },
//     rejectUnauthorized: false,
//   });
//   const instance = axios.create({
//     httpsAgent: agent,
//     proxy: false,
//   });
//   instance
//     .post(
//       `https://ghs-hsp-dotnet-w-service01.azurewebsites.net/common/api/Common/GetXMLStyleSheet`,
//       request.body,
//     )
//     .then(res => {
//       let htmlResponse = res.data.htmlResult;
//       htmlResponse = htmlResponse.toString().replace(/[^\x20-\x7E]/gim, '');
//       const $ = cheerio.load(htmlResponse);
//       $('base').attr('href', '/static/');
//       response.json({ data: $.html(), ok: true });
//     })
//     .catch(res => {
//       const data = _.get(res, 'response.data', '');
//       const statusText = _.get(res, 'response.statusText', '');
//       const status = _.get(res, 'response.status', '');
//       response.json({ data, ok: statusText, status });
//     });
// };
